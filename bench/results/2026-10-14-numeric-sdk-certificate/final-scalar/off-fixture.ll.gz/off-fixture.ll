; DartForge contract provenance 3155f4cc107a33e5f6c8f3404f5d9e7bb1270c7892764f9bbf6d5ed25d929c69
; df.cone-class 0
; df.cone-class 1024
; df.cone-class 1025
; df.cone-parent 1024 0
; df.cone-parent 1024 602
; df.cone-parent 1025 0
; df.cone-parent 1025 602
; df.cone-parent 1073741569 621
; df.class 1024 scalar_nullable_count$2edart Node
; df.class 1025 scalar_nullable_count$2edart NumberSource
; df.fields 1024 0 left:a:Node$3f:scalar_nullable_count$242edart$3aNode:type$2dv1$3aI36$3aC26$3ascalar_nullable_count$2edart4$3aNode$3a1$3a0$5b$5d,right:a:Node$3f:scalar_nullable_count$242edart$3aNode:type$2dv1$3aI36$3aC26$3ascalar_nullable_count$2edart4$3aNode$3a1$3a0$5b$5d
; df.fields 1025 0 value::int:scalar_nullable_count$242edart$3aNumberSource:type$2dv1$3aI17$3aC9$3adart$3acore3$3aint$3a0$3a0$5b$5d,fails::bool:scalar_nullable_count$242edart$3aNumberSource:type$2dv1$3aI18$3aC9$3adart$3acore4$3abool$3a0$3a0$5b$5d
; Declarations of the native Rust runtime (table in llvm/externs.rs)
declare i64 @dartforge_arc_closure_owned_v1(i64, i64, i64, i64)
declare i64 @dartforge_string_new(ptr, i64)
declare i64 @dartforge_string_concat(i64, i64)
declare i8 @dartforge_equal(i64, i64)
declare void @dartforge_register_class_name(i64, ptr, i64)
declare i64 @dartforge_object_new(i64, i64)
declare i64 @dartforge_object_get(i64, i64)
declare i64 @dartforge_stack_trace_string(i64)
declare void @dartforge_register_stack_trace(ptr, ptr)
declare void @dartforge_register_stack_trace_field(i64, ptr, i64, i64)
declare void @dartforge_register_stack_trace_tearoff(ptr, i64)
declare i64 @dartforge_stack_trace_enter(i64, i64)
declare void @dartforge_stack_trace_exit(i64)
declare void @dartforge_remember(i64) nounwind
declare void @dartforge_memory_arc_v1()
declare void @dartforge_arc_write_ref(i64, i64, i64) nounwind
declare void @dartforge_arc_initial(i64) nounwind
declare void @dartforge_arc_global_receive_v1(i64, i64) nounwind
declare i64 @dartforge_arc_box_double_owned_v1(double) nounwind
declare i64 @dartforge_arc_read_field_scalar_v1(i64, i64) nounwind
declare i64 @dartforge_arc_register_return_owned_v1(i64, i64) nounwind
declare i64 @dartforge_arc_register_uniform_owned_v1(i64) nounwind
declare i64 @dartforge_arc_register_typed_v1(i64, i64) nounwind
declare void @dartforge_arc_take_typed_v1(i64, i64, i64) nounwind
declare i64 @dartforge_arc_typed_target_v1(i64, i64) nounwind
declare i64 @dartforge_arc_invoke_uniform_v1(i64, i64, i64, i64) nounwind
declare i64 @dartforge_arc_invoke_uniform_closure_v1(i64, i64, i64) nounwind
declare void @dartforge_arc_take_return_owned_v1(i64, i64) nounwind
declare i64 @dartforge_arc_native_scope_open_v1() nounwind
declare void @dartforge_arc_native_scope_close_v1(i64) nounwind
declare i64 @dartforge_arc_env_ref_v1(i64, i64) nounwind
declare i64 @dartforge_arc_scalar_env_v1(i64, i64) nounwind
declare i64 @dartforge_arc_closure_context_v1(i64) nounwind
declare i64 @dartforge_arc_socket_recvfrom_owned_v1(i64)
declare i64 @dartforge_arc_read_field_ref_v1(i64, i64) nounwind
declare i64 @dartforge_arc_read_field_late_ref_v1(i64, i64) nounwind
declare i64 @dartforge_arc_list_storage_ref_v1(i64) nounwind
declare i64 @dartforge_arc_list_shape_v1(i64) nounwind
declare i64 @dartforge_arc_list_capacity_v1(i64) nounwind
declare void @dartforge_arc_list_write_len_v1(i64, i64) nounwind
declare void @dartforge_arc_list_write_bits_v1(i64, i64, i64, i64) nounwind
declare void @dartforge_arc_list_write_ref_v1(i64, i64, i64) nounwind
declare i64 @dartforge_arc_list_write_data_v1(i64, i64) nounwind
declare i64 @dartforge_arc_list_len_v1(i64) nounwind
declare i64 @dartforge_arc_list_read_bits_v1(i64, i64) nounwind
declare i64 @dartforge_arc_list_ref_owned_v1(i64, i64) nounwind
declare i64 @dartforge_arc_list_ref_v1(i64, i64) nounwind
declare i64 @dartforge_arc_argument_owned_v1(ptr, ptr, i64) nounwind
declare i64 @dartforge_arc_box_int_owned_v1(i64) nounwind
declare i64 @dartforge_arc_box_simd_owned_v1(i64, i64, i64) nounwind
declare i64 @dartforge_arc_object_owned_v1(i64, i64) nounwind
declare i64 @dartforge_arc_object_owned_t_v1(i64, i64, ptr) nounwind
declare void @dartforge_arc_write_field_scalar_v1(i64, i64, i64) nounwind
declare void @dartforge_arc_write_field_scalar_checked_v1(i64, i64, i64, ptr, i64, i64) nounwind
declare i64 @dartforge_arc_read_field_scalar_checked_v1(i64, i64, ptr, i64, i64) nounwind
declare void @dartforge_arc_write_field_ref_checked_v1(i64, i64, i64, ptr, i64) nounwind
declare void @dartforge_arc_write_field_ref_v1(i64, i64, i64) nounwind
declare i64 @dartforge_arc_exception_owned_v1() nounwind
declare i64 @dartforge_arc_stack_trace_owned_v1() nounwind
declare void @dartforge_arc_throw_with_stack_trace_ref_v1(i64, i64)
declare void @dartforge_arc_throw_ref_v1(i64)
declare i8 @dartforge_arc_observe_heap_v1(i64) nounwind
declare i64 @dartforge_arc_frame_open_v1(i64) nounwind
declare i64 @dartforge_arc_frame_load_v1(i64, i64) nounwind
declare void @dartforge_arc_frame_receive_v1(i64, i64, i64) nounwind
declare void @dartforge_arc_frame_copy_v1(i64, i64, i64) nounwind
declare void @dartforge_arc_frame_move_v1(i64, i64, i64, i64) nounwind
declare void @dartforge_arc_frame_close_v1(i64) nounwind
declare void @dartforge_arc_retain(i64) nounwind
declare void @dartforge_arc_release(i64) nounwind
declare void @dartforge_arc_collect() nounwind
declare i8 @dartforge_arc_verify_abi(i64) nounwind
declare void @dartforge_object_set(i64, i64, i64, i8)
declare i8 @dartforge_late_field_initialized(i64, i64)
declare void @dartforge_late_field_mark_initialized(i64, i64)
declare i64 @dartforge_tearoff(i64)
declare void @dartforge_gc_global_root(i64, i64)
declare void @dartforge_mark_constant(i64, i64)
declare i8 @dartforge_exception_catchable()
declare void @dartforge_register_isolates(ptr, ptr)
declare void @dartforge_ffi_register_type(i64, i64)
declare void @dartforge_ffi_register_trampoline(ptr, i64, ptr)
declare i64 @dartforge_ffi_closure_address(i64)
declare i64 @dartforge_ffi_pointer_address(i64)
declare i64 @dartforge_ffi_return_pointer(i64, i64)
declare i64 @dartforge_arc_ffi_return_pointer_owned_v1(i64, i64)
declare i64 @dartforge_typed_new(i64, i64, i64)
declare i64 @dartforge_typed_new_t(i64, i64, i64, ptr)
declare ptr @dartforge_context() memory(none) nounwind willreturn speculatable
declare i64 @dartforge_typed_len(i64, i64, i64) memory(none) nounwind willreturn speculatable
declare i64 @dartforge_typed_fill_int(i64, i64, i64, i64, i64) nounwind
declare i64 @dartforge_typed_fill_double(i64, i64, i64, i64, double) nounwind
declare i64 @dartforge_string_join_typed(ptr, i64) nounwind
declare i64 @dartforge_arc_string_join_owned_v1(ptr, i64) nounwind
declare i64 @dartforge_closure_typed(i64, i64) memory(inaccessiblemem: read) nounwind willreturn
declare i64 @dartforge_object_fields(i64) memory(inaccessiblemem: read) nounwind willreturn speculatable
declare i64 @dartforge_view_new(i64, i64, i64, i64, i64)
declare i64 @dartforge_view_new_t(i64, i64, i64, i64, i64, ptr)
declare i64 @dartforge_unbox_int(i64)
declare double @dartforge_unbox_double(i64)
declare i8 @dartforge_unbox_bool(i64)
declare i64 @dartforge_exception_peek_ref()
declare void @dartforge_exception_throw(i64, i8)
declare i8 @dartforge_pending_interrupt()
declare void @dartforge_safepoint()
declare i8 @dartforge_exception_pending()
declare void @dartforge_exception_clear()
declare void @dartforge_register_subclass(i64, i64)
declare i8 @dartforge_is_subclass(i64, i64) memory(read) nounwind willreturn
declare i64 @dartforge_stack_trace_get()
declare void @dartforge_throw_with_stack_trace(i64, i8, i64)
declare i64 @dartforge_value_class(i64)
declare i64 @dartforge_to_string_i64(i64)
declare i64 @dartforge_to_string_f64(double)
declare i64 @dartforge_to_string_bool(i8)
declare i64 @dartforge_to_string_handle(i64)
declare i64 @dartforge_record_new(ptr, i64)
declare i64 @dartforge_collection_mark_unmodifiable(i64)
declare i64 @dartforge_exception_new(i64, i8)
declare i64 @dartforge_state_error_new(i64)
declare i64 @dartforge_argument_error_new(i64, i64)
declare i64 @dartforge_argument_error_value(i64, i8, i64, i64)
declare i64 @dartforge_argument_error_not_null(i64)
declare i64 @dartforge_range_error_range(i64, i64, i64, i64, i64)
declare i64 @dartforge_unsupported_error_new(i64)
declare i64 @dartforge_unimplemented_error_new(i64)
declare i64 @dartforge_assertion_error_new(i64, i8)
declare i64 @dartforge_arc_exception_new_owned_v1(i64)
declare i64 @dartforge_arc_assertion_error_new_owned_v1(i64)
declare i64 @dartforge_arc_state_error_new_owned_v1(i64)
declare i64 @dartforge_arc_unsupported_error_new_owned_v1(i64)
declare i64 @dartforge_arc_unimplemented_error_new_owned_v1(i64)
declare i64 @dartforge_arc_argument_error_new_owned_v1(i64, i64)
declare i64 @dartforge_arc_argument_error_value_owned_v1(i64, i64, i64)
declare i64 @dartforge_arc_argument_error_not_null_owned_v1(i64)
declare i64 @dartforge_arc_range_error_range_owned_v1(i64, i64, i64, i64, i64)
declare i64 @dartforge_arc_type_error_new_owned_v1()
declare i64 @dartforge_arc_null_check_error_new_owned_v1()
declare i64 @dartforge_arc_late_error_new_owned_v1(i64, i64)
declare i64 @dartforge_arc_stack_overflow_error_new_owned_v1()
declare i64 @dartforge_arc_no_such_method_error_new_owned_v1(i64)
declare i64 @dartforge_type_error_new()
declare i64 @dartforge_null_check_error_new()
declare i64 @dartforge_late_error_new(i64, i64)
declare i64 @dartforge_stack_overflow_error_new()
declare void @dartforge_stack_overflow()
declare i8 @dartforge_late_field_initializing(i64, i64)
declare void @dartforge_late_field_set_initializing(i64, i64, i8)
declare i64 @dartforge_no_such_method_error_new(i64)
declare i64 @dartforge_closure_entry(i64)
declare i8 @dartforge_args_match(ptr, ptr)
declare i64 @dartforge_arg_index(ptr, i64)
declare void @dartforge_nsm_call()
declare i64 @dartforge_dyn_op(i64, i64, i64)
declare i64 @dartforge_iteravel_get_ref(i64, i64)
declare i64 @dartforge_iteravel_get_bits(i64, i64)
declare ptr @dartforge_selector(ptr, i64, i64, ptr, i64)
declare void @dartforge_register_methods(i64, ptr, i64)
declare void @dartforge_member_rejected(i64)
declare void @dartforge_register_cids(ptr, i64)
declare void @dartforge_register_helper(ptr, i64, ptr)
declare void @dartforge_register_argument_name(ptr, i64)
declare i64 @dartforge_forward_nsm(i64, i64, i64, i64, i64, i64, i64)
declare void @dartforge_register_sdk_version(ptr, i64)
declare void @dartforge_prepare_embedder()
declare i64 @dartforge_main_arguments()
declare ptr @dartforge_globals_area(ptr)
declare ptr @dartforge_globals_area_id(ptr, ptr)
declare i32 @dartforge_init(ptr, ptr)
declare void @dartforge_call_trace_entry(ptr, i64)
declare void @dartforge_call_trace_exit()
declare i64 @dartforge_object_new_t(i64, i64, ptr)
declare void @dartforge_register_table(i64, ptr)
declare void @dartforge_event_loop(ptr)
declare void @dartforge_native_DartForge_scheduleImmediate(i64)
declare i64 @dartforge_native_DartForge_Timer_new(i64, i64, i8)
declare void @dartforge_native_DartForge_Timer_cancel(i64)
declare i64 @dartforge_native_DartForge_Timer_tick(i64)
declare i8 @dartforge_native_DartForge_native_pump_supported()
declare i64 @dartforge_native_DartForge_native_pump_enable()
declare i64 @dartforge_native_DartForge_native_pump_disable()
declare i8 @dartforge_native_DartForge_native_pump_dispatcher_supported()
declare i64 @dartforge_native_DartForge_native_pump_set_dispatcher(i64)
declare i64 @dartforge_native_DartForge_native_pump_clear_dispatcher()
declare i64 @dartforge_native_Error_throwWithStackTrace(i64, i64)
declare void @dartforge_native_Error_trySetStackTrace(i64, i64)
declare void @dartforge_rti_init_table(ptr, i64)
declare i64 @dartforge_list_from_table(ptr, i64)
declare i64 @dartforge_list_from_table_g(ptr, i64, ptr)
declare void @dartforge_ffi_register_compound(i64, i64, i64, i64, i64, i64, i64)
declare i64 @dartforge_ffi_compound(i64, i64, i64)
declare i64 @dartforge_ffi_pointer_new(i64)
declare i64 @dartforge_ffi_compound_address(i64)
declare i64 @dartforge_ffi_compound_new(i64)
declare i64 @dartforge_ffi_handles_open()
declare void @dartforge_ffi_handles_close(i64)
declare i64 @dartforge_ffi_handle_new(i64)
declare i64 @dartforge_ffi_handle_object(i64)
declare i64 @dartforge_ffi_handles_close_with_object(i64, i64)
declare i64 @dartforge_arc_ffi_handles_close_with_object_owned_v1(i64, i64)
declare i64 @dartforge_arc_ffi_handle_object_owned_v1(i64)
declare i64 @dartforge_ffi_compound_copy(i64, i64)
declare void @dartforge_ffi_copy_compound(ptr, i64, i64)
declare void @dartforge_ffi_register_callback(ptr, i64, ptr)
declare i64 @dartforge_ffi_callback_enter(ptr)
declare i64 @dartforge_ffi_callback_late_return(ptr) nounwind
declare i64 @dartforge_ffi_callback_late_calls() nounwind
declare i8 @dartforge_ffi_callback_exit(ptr, ptr)
declare void @dartforge_ffi_callback_post(ptr, ptr, i64)
declare i64 @dartforge_ffi_callback_sync(ptr, ptr, i64)
declare i64 @dartforge_ffi_callback_closure(i64)
declare i64 @dartforge_ffi_callback_pointer(i64, i64, i64)
declare i64 @dartforge_arc_ffi_callback_closure_owned_v1(i64) nounwind
declare i64 @dartforge_arc_ffi_callback_pointer_owned_v1(i64, i64, i64)
declare i64 @dartforge_ffi_native_symbol(ptr, i64)
declare i64 @dartforge_typed_external(i64, i64, i64, i64)
declare i64 @dartforge_typed_external_t(i64, i64, i64, i64, ptr)
declare i64 @dartforge_rti_recipe(i64)
declare i64 @dartforge_rti_eval(i64, i64, i64, i64)
declare i64 @dartforge_rti_eval_cache(ptr, i64, i64, i64)
declare i64 @dartforge_rti_tuple_join(i64, i64, i64, i64)
declare void @dartforge_rti_set(i64, i64)
declare void @dartforge_rti_named_record(i64, i64, i64)
declare i8 @dartforge_rti_e(i64, i64)
declare i8 @dartforge_rti_e_cache(ptr, i64, i64)
declare void @dartforge_rti_as_with_context(i64, i64, i64, i64)
declare i64 @dartforge_rti_string(i64)
declare i64 @dartforge_arc_rti_string_owned_v1(i64) nounwind
declare i64 @dartforge_arc_rti_object_type_owned_v1(i64) nounwind
declare i64 @dartforge_rti_object_type(i64)
declare i64 @dartforge_allocate(i64, i64, i64) nounwind
declare i64 @dartforge_string_allocate(i64, i64) nounwind
declare i64 @dartforge_arc_string_allocate_owned_v1(i64, i64) nounwind
declare i64 @dartforge_arc_tearoff_owned_v1(i64) nounwind
declare i64 @dartforge_canonical_constant(i64) nounwind
declare i64 @dartforge_string_hash(i64) nounwind willreturn
declare i8 @dartforge_string_equals(i64, i64) memory(read) nounwind willreturn
declare i64 @dartforge_list_new(ptr, i64, i64, i64) nounwind
declare i64 @dartforge_arc_list_new_owned_v1(ptr, i64, i64, i64) nounwind
declare i64 @dartforge_arc_record_from_refs_owned_v1(ptr, i64) nounwind
declare i64 @dartforge_list_append(i64, i64) nounwind
declare void @dartforge_register_image(ptr, ptr) nounwind
declare i64 @dartforge_record_from_refs(ptr, i64) nounwind
declare <4 x float> @llvm.fabs.v4f32(<4 x float>)
declare <2 x double> @llvm.fabs.v2f64(<2 x double>)
declare <4 x float> @llvm.sqrt.v4f32(<4 x float>)
declare <2 x double> @llvm.sqrt.v2f64(<2 x double>)
declare <4 x i32> @llvm.abs.v4i32(<4 x i32>, i1)
declare i8 @llvm.expect.i8(i8, i8)
declare i1 @llvm.expect.i1(i1, i1)
define internal i64 @df.box_int(i64 %v) alwaysinline nounwind {
%a = add i64 %v, 4611686018427387904
%ok = icmp ult i64 %a, -9223372036854775808
br i1 %ok, label %smi, label %heap
smi:
%s = shl i64 %v, 1
%r = or i64 %s, 1
ret i64 %r
heap:
%h = call i64 @df.allocate(i64 12884967937, i64 1)
%p = inttoptr i64 %h to ptr
%q = getelementptr inbounds i8, ptr %p, i64 14
store i64 %v, ptr %q, align 8
ret i64 %h
}
define internal i64 @df.unbox_int(i64 %r) alwaysinline nounwind {
%b = and i64 %r, 1
%e = icmp ne i64 %b, 0
br i1 %e, label %smi, label %obj
smi:
%v = ashr i64 %r, 1
ret i64 %v
obj:
%m = and i64 %r, -9223372036854775801
%o = icmp eq i64 %m, 2
br i1 %o, label %cls, label %lento
cls:
%p = inttoptr i64 %r to ptr
%cp = getelementptr inbounds i8, ptr %p, i64 2
%c = load i32, ptr %cp, align 4, !invariant.load !{}
%mint = icmp eq i32 %c, 3
br i1 %mint, label %ler, label %lento
ler:
%vp = getelementptr inbounds i8, ptr %p, i64 14
%x = load i64, ptr %vp, align 8
ret i64 %x
lento:
%h = call i64 @dartforge_unbox_int(i64 %r)
ret i64 %h
}
define internal i64 @df.box_bool(i1 %b) alwaysinline nounwind {
%ctx = call ptr @df.context()
%o = select i1 %b, i64 360, i64 368
%p = getelementptr inbounds i8, ptr %ctx, i64 %o
%r = load i64, ptr %p, align 8, !invariant.load !{}
ret i64 %r
}
define internal i1 @df.unbox_bool(i64 %r) alwaysinline nounwind {
%ctx = call ptr @df.context()
%vp = getelementptr inbounds i8, ptr %ctx, i64 360
%vh = load i64, ptr %vp, align 8, !invariant.load !{}
%v = icmp eq i64 %r, %vh
br i1 %v, label %sim, label %t
sim:
ret i1 true
t:
%fp = getelementptr inbounds i8, ptr %ctx, i64 368
%fh = load i64, ptr %fp, align 8, !invariant.load !{}
%f = icmp eq i64 %r, %fh
br i1 %f, label %nao, label %lento
nao:
ret i1 false
lento:
%u = call i8 @dartforge_unbox_bool(i64 %r)
%x = icmp ne i8 %u, 0
ret i1 %x
}
define internal i64 @df.list_len(i64 %l) alwaysinline nounwind {
%p = inttoptr i64 %l to ptr
%q = getelementptr inbounds i8, ptr %p, i64 14
%n = load i64, ptr %q, align 8
ret i64 %n
}
define internal i64 @df.core_storage(i64 %l) alwaysinline nounwind {
entrada:
  %c = call i64 @df.class(i64 %l)
  %e = icmp eq i64 %c, 10
  br i1 %e, label %expansivel, label %fim
expansivel:
  %a = add i64 %l, 22
  %p = inttoptr i64 %a to ptr
  %s = load i64, ptr %p, align 8
  br label %fim
fim:
  %r = phi i64 [ %s, %expansivel ], [ %l, %entrada ]
  ret i64 %r
}
define internal i64 @df.core_shape(i64 %a) alwaysinline nounwind {
  %f = add i64 %a, -1
  %p = inttoptr i64 %f to ptr
  %b = load i8, ptr %p, align 1
  %m = and i8 %b, 102
  %r = zext i8 %m to i64
  ret i64 %r
}
define internal i64 @df.word_ref(i64 %e, i64 %i) alwaysinline nounwind {
  %o = shl i64 %i, 3
  %a = add i64 %e, %o
  %p = inttoptr i64 %a to ptr
  %r = load i64, ptr %p, align 8
  ret i64 %r
}
define internal i64 @df.class(i64 %h) alwaysinline nounwind {
  %z = icmp eq i64 %h, 0
br i1 %z, label %nulo, label %s0
nulo:
ret i64 1
s0:
%b = and i64 %h, 1
%i = icmp ne i64 %b, 0
br i1 %i, label %smi, label %s1
smi:
ret i64 2
s1:
  %m = and i64 %h, -9223372036854775801
%o = icmp eq i64 %m, 2
br i1 %o, label %obj, label %rt
obj:
%p = inttoptr i64 %h to ptr
%cp = getelementptr inbounds i8, ptr %p, i64 2
%c = load i32, ptr %cp, align 4, !invariant.load !{}
%r = sext i32 %c to i64
ret i64 %r
rt:
%x = call i64 @dartforge_value_class(i64 %h)
ret i64 %x
}
define internal ptr @df.selector(ptr %c, i64 %r, i64 %h, ptr %n, i64 %l) alwaysinline nounwind {
%cid = call i64 @df.class(i64 %r)
%k = add i64 %cid, 1
%c0 = load i64, ptr %c, align 8
%sim = icmp eq i64 %c0, %k
br i1 %sim, label %acerto, label %falha
acerto:
%ep = getelementptr inbounds i64, ptr %c, i64 1
%e = load ptr, ptr %ep, align 8
ret ptr %e
falha:
%f = call ptr @dartforge_selector(ptr %c, i64 %r, i64 %h, ptr %n, i64 %l)
ret ptr %f
}
define internal i64 @df.allocate(i64 %cab, i64 %w) alwaysinline nounwind {
%pequeno = icmp ule i64 %w, 16
br i1 %pequeno, label %tlab, label %lento
tlab:
%ctx = call ptr @df.context()
%o16 = shl i64 %w, 4
%oc = add i64 %o16, 64
%ta = getelementptr inbounds i8, ptr %ctx, i64 %oc
%tb = load ptr, ptr %ta, align 8
%of = add i64 %oc, 8
%tfa = getelementptr inbounds i8, ptr %ctx, i64 %of
%tf = load ptr, ptr %tfa, align 8
%w8 = shl i64 %w, 3
%tam = add i64 %w8, 16
%tnx = getelementptr i8, ptr %tb, i64 %tam
%esgotada = icmp ugt ptr %tnx, %tf
%x = call i1 @llvm.expect.i1(i1 %esgotada, i1 false)
br i1 %x, label %lento, label %rapido
rapido:
store ptr %tnx, ptr %ta, align 8
store i64 %cab, ptr %tb, align 8
%hb = ptrtoint ptr %tb to i64
%h = add i64 %hb, 2
ret i64 %h
lento:
%cid = lshr i64 %cab, 32
%fl = lshr i64 %cab, 8
%fn = and i64 %fl, 16777215
%r = call i64 @dartforge_allocate(i64 %cid, i64 %w, i64 %fn)
ret i64 %r
}
declare void @dartforge_effects_before(ptr, i64, i64)
declare void @dartforge_effects_after()
declare i64 @dartforge_effects_level() nounwind "gc-leaf-function"
declare void @dartforge_effects_restore(i64) nounwind "gc-leaf-function"

; Constantes de string WTF-8
@.str.3 = private unnamed_addr constant [6 x i8] c"Object"
@.str.4 = private unnamed_addr constant [4 x i8] c"Node"
@.str.5 = private unnamed_addr constant [12 x i8] c"NumberSource"
@.str.6 = private unnamed_addr constant [5 x i8] c"_Type"

; VTable of class Object (id 0)
; VTable of class Node (id 1024)
; VTable of class NumberSource (id 1025)
; VTable of class _Type (id 1073741569)
; Closures: invalid entry and constant vectors
@df.const.i64.2.c314eb35009b14025e5ef5c352349ffcb0ff36f19602db3b02250d0153c9f892 = linkonce_odr hidden unnamed_addr constant [2 x i64] [i64 0, i64 0], align 8
@df.const.i64.2.5add879d03074d0745fe088492026a7fe5e24eae5505fb5feeaa2dea820028da = linkonce_odr hidden unnamed_addr constant [2 x i64] [i64 1, i64 0], align 8
@df.const.i64.2286.e28bda741dcd35c90d584a41a9adeb7d34119bfe232997dce14f5a0ac2ed187b = linkonce_odr hidden unnamed_addr constant [2286 x i64] [i64 309836160320512, i64 3971211002259036792, i64 -2296939851532328786, i64 -4361129636017526952, i64 7664402601518935446, i64 -7859092386197990458, i64 6410158756426798941, i64 3461317580474466106, i64 1315238418186611379, i64 8991737927071301892, i64 8682516214188957293, i64 4212975523996625656, i64 7682199459981019135, i64 -7082496464147006114, i64 194708871620529777, i64 -4695750539154163995, i64 748635064617803130, i64 -210560908949022665, i64 2836616131798556455, i64 4988487693871686884, i64 -7886521677313854007, i64 -218144303955012501, i64 -710235103648889893, i64 1028784205231187261, i64 -7840598502644411394, i64 613069703245000185, i64 -4913933451376143130, i64 5034839648148449779, i64 -6971871309404842791, i64 3983894423085559287, i64 5314199044096443032, i64 -7304676214292275212, i64 -7830470617622129372, i64 5090942060850748066, i64 -579423292001471179, i64 -5997437520770706493, i64 -5201663712645259366, i64 4038277548415716819, i64 -4260085809249653712, i64 222824204675068464, i64 -425270612368458799, i64 2890870004658979825, i64 625121335064440034, i64 897796901408115406, i64 -6514733553785923789, i64 2767866890184579441, i64 8427360386189521766, i64 -4253549592989045764, i64 -7483850306748913852, i64 -4602524332862453235, i64 8966945574563267501, i64 -3997568256334545286, i64 8071041011311080921, i64 2539878146238847586, i64 -3046283951450239010, i64 -3692551900629490188, i64 4358217511984397755, i64 1121007208787460225, i64 1992793722502181819, i64 -7879494121487284992, i64 -8680846758401677423, i64 4932584153346734531, i64 6815072138777408865, i64 -7071653123884633445, i64 -7170172701046932067, i64 -3535362129347707073, i64 611703885110138811, i64 -4568436315587008511, i64 8923274209634652047, i64 -3690374431206689439, i64 -5875420727667110507, i64 5664074525851266670, i64 -744958545251057472, i64 -5428554104005282996, i64 -5414024665239083570, i64 5371569577957473508, i64 -7991271205327562458, i64 2670698420007030879, i64 -30345247879030398, i64 -5606907159185020397, i64 7955761639363744790, i64 -7267293677866526163, i64 8481073711724212947, i64 -7164816006416658643, i64 8314999582821058838, i64 8422216955962039084, i64 2283163090386817257, i64 -9007612007651336330, i64 -5813502423696993656, i64 1147614914980541733, i64 -5338371126118317024, i64 -3507656492745715548, i64 -6497701498552190318, i64 1396795355297294403, i64 7126766463268842545, i64 -3433100788441785563, i64 6342672258173928882, i64 451152041276974379, i64 7317053626142174614, i64 4979682498244848065, i64 -5397763029457818090, i64 5427247347086872948, i64 1685165431308165079, i64 -3285366474127873494, i64 8132709189239608901, i64 3868413184407270586, i64 6506404960392303329, i64 7324179392939533494, i64 -475099932120974613, i64 2775424773614761268, i64 -2254936570792943013, i64 800670661296066196, i64 -5018474922833889385, i64 -1466576187252038228, i64 -7706862426400285489, i64 3668520566687027381, i64 5451341210899158859, i64 1404304099020263559, i64 7545409726965509294, i64 -7599022377622140199, i64 -3188070448654041171, i64 4945523320895048721, i64 -5065937506779418008, i64 1969044335566825221, i64 5453375048412573369, i64 7959149837547808487, i64 -866125676359855534, i64 621836734871260634, i64 2897453107883489928, i64 3905551182245037105, i64 3343792587475937098, i64 -6971023827815029862, i64 -7863523775677689247, i64 -1752016691840601524, i64 3185457809656174999, i64 4616483396080902952, i64 2101519789431387725, i64 -1373258217199701694, i64 6230929540762794821, i64 5609105064421844875, i64 -2826958329879369962, i64 -3524228399259249664, i64 5370058006484869678, i64 -6906611645318147961, i64 3667543154163081915, i64 -6751877047423364197, i64 -7571601477972970872, i64 2333498374002545355, i64 8768651857839162410, i64 5042959794275810530, i64 -5991596691444615501, i64 -8924846374646093379, i64 -5597488210334112184, i64 2670698420421040100, i64 -6554860991061177150, i64 -708326889362107896, i64 -3340614907280977035, i64 2644109327527190021, i64 -1755410441010262893, i64 1017255593093339287, i64 1863091832305821766, i64 -7116320853623772146, i64 2709759515925913462, i64 3935392371962207113, i64 -7190218235504583625, i64 3978539081794336566, i64 -3204461854958654372, i64 -2181517091471653002, i64 3763375652002543266, i64 -6523828815224991429, i64 -7578215479022261868, i64 -3204426774593743993, i64 -8676515052776618090, i64 -4528924649374415125, i64 6646387503763585010, i64 3558518996011554514, i64 -4725074827715966157, i64 -5412691553794916498, i64 -2143233063793663423, i64 4736346729968976314, i64 2018299044035671266, i64 1420207361297884187, i64 2797553790134989536, i64 -8064326858703730256, i64 7621457716738484834, i64 -4261683134020860709, i64 7978144222916434793, i64 2039486560510752923, i64 1591389696794961627, i64 -3938741106494049101, i64 7769853404939790313, i64 -4236924329710074573, i64 3705271943285781355, i64 -7888842634306553915, i64 2874028509851943049, i64 290610391190870765, i64 836106667744324917, i64 3250018733676628175, i64 6248575351902097830, i64 7996182810759188924, i64 7036360077810563245, i64 950648456751779121, i64 2732903678342818187, i64 -2396941156789632673, i64 1634221474023403882, i64 3998170314161188319, i64 -6906722334231577513, i64 -4501511800057247223, i64 7461812162841024091, i64 7102297290061009652, i64 -2396938133047910934, i64 -4189623336730693259, i64 -4908660145118552597, i64 1683756424036213485, i64 4305968364535069647, i64 -7590940598141332714, i64 -3208075157760221229, i64 -4873677996595221563, i64 6717030796268500190, i64 7251205375035914108, i64 7772701253532491809, i64 6962762747406434871, i64 1886474200440599801, i64 -7773373156423347549, i64 2760844805948042697, i64 -656177477499555913, i64 2899825697970485665, i64 -6733083608211055725, i64 5085338938781426597, i64 5325340242823042198, i64 -7592143826318875831, i64 -7591973300972459468, i64 5172669459917649460, i64 -5450220561656682195, i64 5733635149305801844, i64 1663468017280830562, i64 -967181419445269949, i64 -3473876723499369421, i64 -8063139561836978704, i64 -1934355948445155516, i64 -8014490832183599001, i64 -8545423619377306777, i64 -3776950215556250126, i64 -8705925938120838175, i64 6481248165015440079, i64 6590951633914305721, i64 1035226449002719176, i64 3537515124636944079, i64 2177682111298354973, i64 -606755528594249646, i64 -8656391839685637151, i64 -6489410217241016593, i64 -1213510934203588743, i64 4353492618431206147, i64 -4102841268378192549, i64 -7057912352926350341, i64 1862135291267176520, i64 -6857741571448048003, i64 -7048801240534180307, i64 3832737201697730000, i64 2869751907825755375, i64 -679188248910379600, i64 6962052107047993934, i64 -599435506302300474, i64 4886322001888012482, i64 5022661774031958783, i64 -5470670981841964012, i64 -8925654987913423803, i64 3278977161374920777, i64 730383665564246178, i64 5722682980301082988, i64 3699625239998617638, i64 -6729055167616017577, i64 -6364254056371673171, i64 -5922049145825677872, i64 1402733072544014503, i64 -4779720818159879464, i64 -5176347497729703781, i64 6656004140677858701, i64 -8529984881879823839, i64 -1483888886664436226, i64 7506070613135157290, i64 6732464718997891819, i64 6557996104202153221, i64 1546335732638531927, i64 9144680451330980568, i64 5310608026666741744, i64 -5787792797625341981, i64 -5922040349732131424, i64 -6868079794904522577, i64 -5744523834408947795, i64 6871088469531956725, i64 -5583365993126711935, i64 7821389426515788483, i64 -6855155957010423866, i64 8429061872808019791, i64 1202975569622037548, i64 -1588620142385498214, i64 2405951072004989016, i64 3807818128124669800, i64 3425127052560003339, i64 3306831467658414031, i64 -1206582912698364931, i64 1648803540966901100, i64 2004201850686328564, i64 -7070494511145905062, i64 824959268476489901, i64 -5362626957948896916, i64 3723871344187396634, i64 -4825909642079769346, i64 6862307532781917683, i64 -3132960598729139295, i64 -4559999376196325444, i64 5263293846505975554, i64 6829357805309353851, i64 8754509454897273800, i64 -7495642548848891842, i64 796537362320957725, i64 -2456660461741131910, i64 2937322914278396080, i64 2405410114088994905, i64 5248972379705372523, i64 -3884733230432361204, i64 -8078893211816780043, i64 -3178111805930341118, i64 1391493883790926468, i64 7584741212865233338, i64 -6356223514002301986, i64 -1627070698349501247, i64 -5412432617051250216, i64 8794379726709461977, i64 -103213144925909694, i64 6096823815848087365, i64 7351823222646096975, i64 -2829460054786222948, i64 -854346241617114099, i64 4877911694287084612, i64 -3733931815970204720, i64 4806262138473014537, i64 1781192170870622585, i64 3773979454968099469, i64 -2616169749674198070, i64 -151264006803762791, i64 5494317479862759109, i64 5506931032472418178, i64 3448370644058225478, i64 7479559134248587896, i64 -8341851008688842758, i64 8516569862540589398, i64 -4838196280463576557, i64 1763042056427395267, i64 977714443273041773, i64 5055824357242104005, i64 -7101176635024259593, i64 -6393354582287386663, i64 -964587293553145924, i64 7196281214535688990, i64 5660005336358833524, i64 3685903469175672697, i64 -206030600487729829, i64 3028215243590637182, i64 -6446550993638581620, i64 4671875858072932353, i64 2417316344553473532, i64 -1843067564084560161, i64 -8140122547042423856, i64 4341329092557028895, i64 4500500093350164990, i64 8547708852670036094, i64 -1193815375601327841, i64 -7684573930472412408, i64 5300198987542442090, i64 1757559961893851817, i64 -1441331330830234446, i64 5267396128333342391, i64 -8872078868671724441, i64 8089550969006446832, i64 5377598271963369318, i64 -4298588500204971979, i64 -8824609195206237502, i64 -931402199896423355, i64 3654597044558128490, i64 4805090870760958629, i64 -1511213980390903408, i64 -7043665291493740122, i64 -7802214118792894705, i64 4405372189158808875, i64 3515095031798043568, i64 -8591594557996394140, i64 4844264383508408763, i64 -2075990544062908275, i64 -3896603459709940856, i64 2602748045221726743, i64 4924801138958623138, i64 -1219973223696162109, i64 7325401815688818065, i64 3588844633178059204, i64 -8139191640436702162, i64 -2020275964231311944, i64 -1015069940574945415, i64 5257061446584089129, i64 -4463705774469921132, i64 7019193962310038812, i64 4129071918853476777, i64 7505125209810127470, i64 7008540140605325249, i64 1183382705288753433, i64 1209569894950253142, i64 -7220691275895188652, i64 1696505603452452395, i64 2774362713941096264, i64 -7042008616990546852, i64 -4219236222767658896, i64 2448515939781669316, i64 -2090029891977403672, i64 7444354088631991992, i64 3129163463455332913, i64 7506459365098959147, i64 -8912526243932192414, i64 -8425567830689829190, i64 -5393626377178820472, i64 -6575346399756774658, i64 -4635131850048198682, i64 -4024035610269329756, i64 -1300149446709346545, i64 -7170918252923044381, i64 -4131960099558426271, i64 1207684141279417329, i64 664121366574778678, i64 -2600650683005907305, i64 -4938237975469318433, i64 -3716862639731204057, i64 2924896893738368106, i64 6725320047049989308, i64 1926401375119284901, i64 -7963669009347532684, i64 4194517067311032174, i64 9062365632395478578, i64 -4491548589856725593, i64 -5983598375325247197, i64 6051427131657349319, i64 -2245826794845377625, i64 -6843424360299943951, i64 -6132067123047254396, i64 -1447782158959443161, i64 3060839108000527308, i64 -8025656798333702690, i64 6248030476573455981, i64 1432757554495462965, i64 -7236374123634406488, i64 6490216838160708025, i64 6477114331575899867, i64 7461749479991310551, i64 1198236329361556317, i64 7883100957447032244, i64 6137154932713045190, i64 1962890173346314723, i64 8731169628250545867, i64 -2075317258387073287, i64 7064184978890120165, i64 214311710595958157, i64 -4943585852990308515, i64 3925756157425932707, i64 -2484176096054264442, i64 -842621324778899858, i64 -2874983555824132003, i64 -1663796927085671188, i64 251424289200675857, i64 -8132550615763944549, i64 6634251026219192096, i64 5822752114173269123, i64 9125505112100360655, i64 -4911197199093315335, i64 -4400947960487877689, i64 7629332765803782838, i64 6232364577939097871, i64 978506850973214165, i64 -8159607309852971463, i64 -4592887626558569268, i64 -3809886084063950797, i64 484499853256224656, i64 -1897936622265799891, i64 8952972858542886793, i64 -1621513433074613536, i64 1671911203288655851, i64 7704618716711626795, i64 1715361973123971312, i64 8233224841778548822, i64 -6185294322920340187, i64 -6292115119779706146, i64 5854632532925097978, i64 8695562702216859636, i64 -4521685009056534790, i64 5598976060373685179, i64 -5839245633005045507, i64 4214168805033094047, i64 -3083936637300504881, i64 -5340423283353492721, i64 1581167917372929923, i64 7444815373208177164, i64 255449568571897524, i64 352278660772510053, i64 7454247959465406216, i64 3943528823786678897, i64 -4136759321971384394, i64 -3813683822465670702, i64 -1580359754436355955, i64 -8076905733742549777, i64 930770892360338958, i64 792275378496808316, i64 7338049808367265587, i64 7817480058215420803, i64 -4201342687321728517, i64 3289099134875730003, i64 564822492544342277, i64 8046461499204685823, i64 5683381489501367221, i64 -4804616248149451225, i64 -7614294018818540672, i64 4554244489755924309, i64 7984309081613791654, i64 1996000474568461773, i64 -5384564476274498807, i64 -1968038132921094201, i64 8283164865745644227, i64 -3910499415320171202, i64 -6954422598468430578, i64 -6839591080178778776, i64 2237899638399029111, i64 -8532222256848074801, i64 7954556456106906666, i64 -46547941332076771, i64 2256056979348712760, i64 -5997459237275975312, i64 -3342453340954449536, i64 -1590118157175290726, i64 7590453859071281129, i64 7146105462004831589, i64 -9043666817230452616, i64 -771780584492143766, i64 -6037461698365648213, i64 -5419566061201731047, i64 -4793674178786838150, i64 5667643296861330770, i64 -8655342866759927369, i64 4670990687203357639, i64 -3242381765248331753, i64 -2772116135289059336, i64 2302456453253562316, i64 -579064640398455185, i64 -3254785092956553761, i64 -7760794682410748469, i64 685656862022258378, i64 -4051005015920112301, i64 -4850688243975848453, i64 -5952609431490863680, i64 4030715580485924706, i64 8447402060289883447, i64 -7101875316409312522, i64 1365949091156987302, i64 -6232808855993119813, i64 8767622962441880790, i64 -8753161601625970113, i64 4509394590660957466, i64 -839696610629167933, i64 -32829689256222119, i64 -9115960980956524562, i64 7252146008390337843, i64 -8554391110909043483, i64 9199053986114396942, i64 5479715978421796588, i64 -7446937747630392279, i64 6387803329038724354, i64 -1013036688992098713, i64 5876435454892103468, i64 3845725905623597825, i64 3285680308291287749, i64 -638219304500831191, i64 -4326400676506291897, i64 -6172498620311695449, i64 6560943261289627764, i64 -8830220155844220587, i64 6590324633685255008, i64 -6938550323635081086, i64 617866941785186167, i64 3522816273609789461, i64 1922371284113431831, i64 -8279856316698452792, i64 8427262596161510976, i64 -8756942051069181295, i64 -229275277661335117, i64 -3559306526626663677, i64 -1542436037400023270, i64 -5639024533303932937, i64 -2748243838319766779, i64 -5280732551282513534, i64 -3889263762123291444, i64 -3248150752490949714, i64 4816007278469417667, i64 -5822333303432381219, i64 -43423659027075910, i64 6939939657813221634, i64 -161082893567389270, i64 970268072393749246, i64 459322638561313471, i64 -1767724478345779669, i64 8888624179014400477, i64 -4290229846388066142, i64 -3099200798201339398, i64 -1886593076056331828, i64 7985356694516322364, i64 2503115492792310429, i64 7053192926161460787, i64 7649168390114664959, i64 3900164630243226976, i64 9072351777912128882, i64 5813348269167104423, i64 -2251159207084279046, i64 6200906885447567661, i64 6459030653094875851, i64 5014147005532441080, i64 -4793992272768559183, i64 -2568596522301204716, i64 1551061861157470874, i64 4566110150840749301, i64 -2828388640159773755, i64 -7282137617600148208, i64 -7202925491574955735, i64 4126067730070482048, i64 -2257160084831496454, i64 1045926213715319127, i64 3175266785084673369, i64 8670684376699703974, i64 -5571396197073545955, i64 646588338952423002, i64 -3505202566558860244, i64 646661130995117030, i64 -4835878220494357460, i64 4153534752135371560, i64 -1155396294706689448, i64 6352017581312971410, i64 7881789614642380645, i64 387915144398193089, i64 -2952799102707020092, i64 -7738593454788362767, i64 3840558711139510854, i64 6191603028939011746, i64 -6229189072516913246, i64 2207854755498284102, i64 191686457201214186, i64 8952062680967442, i64 -155997695804421151, i64 6832832124229250798, i64 -2571929198260796883, i64 -297238764933040333, i64 8450279711744512979, i64 -7698820400041250557, i64 154356392219987075, i64 -2030127540507016781, i64 -4632458250370424322, i64 -9212317535622755494, i64 7701912853805926583, i64 2162113279508959785, i64 -964137847030687144, i64 -7973454229090009018, i64 699616049710291652, i64 -1128288501867686828, i64 3965485687389548033, i64 5668561482425145797, i64 6224855046164036061, i64 7936912295510247780, i64 -1748277167491525911, i64 3719550497636346608, i64 2116157277621941675, i64 -6231046848039660026, i64 2558231249295201894, i64 3238451161230055782, i64 -188651028941025741, i64 1361978487480318908, i64 6892936613259338578, i64 -959245227052235957, i64 -6043759892805748269, i64 7795413069507686409, i64 -2681182253876286471, i64 -7821399036060760887, i64 3940969535266795812, i64 1986934811755628922, i64 8311134021821978033, i64 1555080989683199309, i64 -6092888371621214503, i64 -259694331749628330, i64 8463660354437116899, i64 7464282493768788687, i64 8581134715910194622, i64 -9174882612452927030, i64 -529713784577628632, i64 -6509525277783339498, i64 5234976193546333323, i64 -992857496162404528, i64 -730584589814368815, i64 3751294931358311869, i64 -6708462307718345457, i64 -6138358645343737031, i64 5642256464189839157, i64 4562124402053145767, i64 8660509068846134966, i64 -8234297918053674120, i64 -579312775274848935, i64 -7072209439062798357, i64 2885105301993684798, i64 -5339688805431167611, i64 5331575777629397354, i64 4225250202962560686, i64 2491452485779805867, i64 389812931094686535, i64 4295123079519974744, i64 5929477932579395641, i64 6622795567777404257, i64 6680214023037243783, i64 8859378623723395879, i64 8332242006412798917, i64 -3306834365628332629, i64 -1008558354591617150, i64 7764305501225856740, i64 -6949488867726792020, i64 -4956168222505775522, i64 2546829013597835849, i64 -8936697291205933721, i64 -6605852421145199591, i64 9095209339718027410, i64 -4043128633690326925, i64 -7373004214294481969, i64 6819282643128697053, i64 698337359722317797, i64 -6069817263772414047, i64 -5798893905042494955, i64 -473064990638112649, i64 1502616916856715185, i64 -3045961245108159998, i64 4214389924247559930, i64 4549222468454512910, i64 8174244236484288478, i64 -6076778963045517693, i64 -949512852917735695, i64 -3094126373991735066, i64 -3263125609320423973, i64 -1224580219752895211, i64 9177742252392774260, i64 -6716445815240330166, i64 3474530909908037866, i64 -3224664196794893871, i64 -8710715587850786124, i64 9151172589694761503, i64 -9609192645248385, i64 1107065336536951280, i64 4459079683681690689, i64 -736473153412974270, i64 -20990949767315697, i64 -4083475456395009015, i64 -2034074545244016105, i64 4428887189928273030, i64 -7766199254981635906, i64 4463208792456657360, i64 1218052201031028872, i64 -8653763560546900159, i64 -3522061889845689869, i64 1589593054447395751, i64 -2864095757276022108, i64 6110023862226328886, i64 3156650301523588495, i64 -7226888796495797855, i64 -6806240345811304471, i64 -1086901967876122169, i64 4388837122281051406, i64 -9002155022313912260, i64 -7204617856344939708, i64 4683319306345539417, i64 -8198037067673464515, i64 8761143634945405909, i64 -6110968336891740013, i64 -8488771856270439330, i64 3049135805445366698, i64 -2097687066654823234, i64 -5793191510886988260, i64 -7012361822097941919, i64 -2495651406956368288, i64 -8696421908700313289, i64 -4782307654924488969, i64 8194108069927794915, i64 -916674580653609148, i64 -2718947736873458802, i64 1419718570903352179, i64 3522811582793389743, i64 -3432394563956668621, i64 -563627547248886762, i64 38860896797257494, i64 -2042628746523473393, i64 -5402821591027813917, i64 -3798819789269258720, i64 743848484313302408, i64 -6678725488757401004, i64 -8076011739661267191, i64 3125597660881971151, i64 5126597248682093188, i64 -6174030349904103132, i64 -1449726447986912716, i64 -7591587341292535857, i64 3422861027158943253, i64 -1153616413270850808, i64 -6039866534617795653, i64 -6554054955744205938, i64 7989983215881174767, i64 6080808756991231191, i64 -162247499842027065, i64 1202799654756876022, i64 -2793204098913043243, i64 -6379397328204349917, i64 -5450366403369270791, i64 -4493310145680718182, i64 5847604257482138753, i64 3300397794180904245, i64 5955070724227049612, i64 6109179423762196057, i64 4004977470748141906, i64 3375880412321719617, i64 3485028852855633119, i64 -7330729949630957813, i64 -4347502306748542708, i64 7163745086568079008, i64 -5126314395464908192, i64 -6666816981998844966, i64 9019949598211423578, i64 -774153127550036966, i64 2101527612999159913, i64 6483472609433915776, i64 -2021422647296992260, i64 -4860603967688975262, i64 5229181788746822142, i64 -8068140303147318245, i64 4517926708557722186, i64 2112839902433250019, i64 8764745789138857415, i64 7829979301334654549, i64 7711022609961801378, i64 -5888255738558878150, i64 5467909043080472008, i64 6094830555660233897, i64 -8222127669189501379, i64 9056410245019272526, i64 -145792843557171371, i64 6447344915140831713, i64 5347748779811358304, i64 4945920279835878256, i64 6073725616376793653, i64 4405410203062060195, i64 2229838107731947425, i64 1290399258022126508, i64 -412328829900244319, i64 601805330729854136, i64 -8777257544402727493, i64 -5054573614553077401, i64 2876530048025968477, i64 2959342856373162570, i64 7153619216825365103, i64 -5788837678014801286, i64 -7476774518177767180, i64 -457918060254454124, i64 -7294496137019600238, i64 -2645276943539427025, i64 1203828102973499827, i64 5954907510883320891, i64 1411008401817512342, i64 4251207982678005417, i64 -5217004044124886591, i64 3835598701015948686, i64 -2477050997570458655, i64 -3279369725911251999, i64 5825797567532430954, i64 6118398681506312790, i64 5671317818259594234, i64 1557781939007180694, i64 7863107743113340188, i64 3815335747940879507, i64 -3437276752248259248, i64 5868622341653781196, i64 -4236710304824749950, i64 -8510060549514776501, i64 117616071932271895, i64 760904284720673853, i64 -6800952746222734652, i64 -4131749654038453608, i64 7407759325901974792, i64 6945969762216008399, i64 884571223106271200, i64 -1157637380066453771, i64 3212884742685453025, i64 -2053066476378107732, i64 7164729038836489372, i64 -855114947333297109, i64 -1598688557289222659, i64 1467023464223806683, i64 -8528074458344568263, i64 669264640426795377, i64 -4408576372350145717, i64 -469839761763336455, i64 6657948807317869225, i64 6610290831177020229, i64 4808896232960886174, i64 -3866423660167848775, i64 -2558463489916058599, i64 1546999314747036372, i64 2415941579099653360, i64 -4821177300490340532, i64 -8702993788443728758, i64 1571410724281661744, i64 -4082768951332746730, i64 8567375463160105921, i64 4865289945904542047, i64 -7122320914640397167, i64 9054670300698621922, i64 1560195203312894647, i64 -3310542312617264260, i64 244906492733775219, i64 4153313807199406758, i64 -7072060309304809449, i64 6198287331799292398, i64 3462911989325501720, i64 3092059365907458342, i64 -6555060789698989575, i64 6091622439071618642, i64 1591920043737426531, i64 -7995319030718741521, i64 -2867608578055956349, i64 3606704906376830835, i64 6271817874191244892, i64 1856595563228963088, i64 -1525955382036413778, i64 -2310960409533161415, i64 -247560292225125914, i64 -5563631481520564316, i64 2596579967305590870, i64 1252649564164170047, i64 6929403900129626616, i64 4772517615695876908, i64 1686835236227979901, i64 3248268004960695798, i64 -7917615107212670061, i64 -9100026452337405132, i64 -1395761082832232786, i64 -5180748978357743856, i64 -3452322156147963266, i64 -6245836636398006428, i64 3013564171881894700, i64 1479936447766049605, i64 6091727986592924219, i64 -5196435951200460005, i64 2328295279492089851, i64 9011274838228457148, i64 3731108439267088626, i64 3047701972070042137, i64 -7058941545258839916, i64 3510424384835461699, i64 -7786404249118784323, i64 -3358189258892391842, i64 -7251549094434663386, i64 8087935819392980148, i64 -8640337907545459167, i64 968720091596524210, i64 8759039117305617074, i64 1515627375397102178, i64 -1697806951879326704, i64 -7235952484991617131, i64 96973323278510557, i64 -7958683282711612335, i64 3585228438250481821, i64 8003685863811438579, i64 3924178747224742608, i64 -9175166306530521632, i64 -5973510856708393306, i64 3955135380744862785, i64 -7578716183767330086, i64 -7946997871783105974, i64 -5739439405971692933, i64 3497009666343956038, i64 -5133499122513078414, i64 9059219532476706141, i64 2695153542128269325, i64 5612303672505975401, i64 -1398929834900923720, i64 2974216691083683129, i64 2940721164862137157, i64 3520870538599229157, i64 -581228372852118026, i64 6784344754419113847, i64 -4836686097889009515, i64 -1845975503166190775, i64 -8705434336663827034, i64 5679824232046304201, i64 -7170028473192176838, i64 7317421884367726269, i64 -8473842241064613355, i64 5921552768690537248, i64 -3901948578795812228, i64 8251504718953794225, i64 -5456299947307061370, i64 -8292882660653897718, i64 -5208142111364767530, i64 -5247965080546229530, i64 1028877990570384167, i64 5497230042696524696, i64 681843641538432170, i64 4095083774910005949, i64 3409180294591008448, i64 4614997703900011964, i64 -3536920420980425321, i64 -7879873341892889302, i64 -6531884898913685174, i64 -3438566362722423542, i64 -4858268895376641070, i64 3392356892440341493, i64 3817598046126230139, i64 8711303840448696948, i64 -8766549943267338725, i64 5237183837977344921, i64 7663518199076569810, i64 218577147181654036, i64 -5616648987944330500, i64 -1793959201546014229, i64 -7175836806184057180, i64 1966162389365234323, i64 -2785110633111006571, i64 1323844189094746974, i64 -276761134407427718, i64 -1535142864130923598, i64 -6140571595015803772, i64 -6115542306353663469, i64 -142731237613975474, i64 1212264811292625718, i64 -7756857903339352911, i64 2888653298528888917, i64 205681745603480007, i64 -5576229610090474635, i64 -4060847793300251328, i64 -5409103215631353137, i64 369591556591677006, i64 4504452261880359437, i64 4311499093788898839, i64 2968624543111993515, i64 -1817647416095428184, i64 -3358495746339981138, i64 8611564689119352803, i64 7140721427153245566, i64 -9210331721130358248, i64 3378220540911806200, i64 -1715839617666594644, i64 -5135297884753731543, i64 5279355659262111906, i64 -1728852580671313868, i64 -2803202923500010187, i64 5032183882575686464, i64 2708125916737740425, i64 7341941195526349542, i64 2666057300277165960, i64 -8296734242642252542, i64 -9101643312192563896, i64 7757540651156502467, i64 -7898894738546967085, i64 -1259211122146070297, i64 -2917452465240672892, i64 9198622318178269362, i64 3215340070484144323, i64 540055117032826948, i64 -9163862440056653934, i64 -8651603299010432253, i64 -937337513666886917, i64 4961033155526043594, i64 3768021145760320179, i64 -3374659496113468450, i64 3138835147295486172, i64 -8833074067865737178, i64 2232291382280037527, i64 -4721968384683951867, i64 7814704398193119529, i64 -4778279765387586438, i64 -795714458302830065, i64 -9047822557129482257, i64 -1166393045814274696, i64 1582959255064391467, i64 8693062916824015847, i64 -7614245588056209127, i64 -4360755407415212811, i64 -1530392593747839052, i64 -706236477177512983, i64 5025104134208142829, i64 2123557790459723686, i64 8292669305315950691, i64 5857482467741865119, i64 -6518268665016281230, i64 1710606816236926940, i64 552089043376283478, i64 1107358372773614773, i64 -4044812523320038079, i64 6520076037570157959, i64 -2020631798261915159, i64 -3503853254413614771, i64 -8187004771383656961, i64 -7699375242941958963, i64 -6556076358036493296, i64 -1014468182790733295, i64 5022599456044471592, i64 -6555994992801042121, i64 -8150392429227883978, i64 -8471133075568196245, i64 5517667607258900341, i64 743231014408720697, i64 -3855785807894296535, i64 -4338391341356615417, i64 -348186270094094992, i64 8908371888072528587, i64 4424419295629206906, i64 -8791172209221642361, i64 5458977958916528279, i64 -743080142537727502, i64 465570843054839682, i64 -1807362498206738974, i64 8833974239132299073, i64 -6693663339874997616, i64 8842552006986720936, i64 254970909488459654, i64 2394264233596745038, i64 -2518381007329623155, i64 8753345902108585071, i64 -5525716015113271438, i64 -7789205304164700694, i64 -7489336899586252187, i64 -8028161586417552694, i64 -4799583124580839595, i64 -2999115007413969222, i64 -6959758015923552822, i64 -8483483740259079224, i64 2392315947400441338, i64 4915704502810730318, i64 -6100036587846347816, i64 -484497181516923695, i64 -4273547287580920954, i64 9135948168100158123, i64 -8781598996334621887, i64 8634911478987852411, i64 -3767358022604436293, i64 4841856929456768748, i64 -5973507814210244914, i64 -2214708723163414999, i64 -8778506608536209873, i64 1660786950993055319, i64 8878826704938567817, i64 -8585315296267971885, i64 -2722718567640523933, i64 6185353935829464704, i64 7256423765722767948, i64 -8493741544465736386, i64 -4613485143497040603, i64 4518625321441227358, i64 -2970694220214006298, i64 7344760084861314203, i64 -8668226917417517771, i64 3825462411201619735, i64 2389584054045504874, i64 8611901166465443633, i64 -805131544691303811, i64 5240854166276938757, i64 -7293300899490779763, i64 3852793324737120687, i64 8976695109378034845, i64 1632052881914321849, i64 3081913769037962501, i64 1350384162520418617, i64 -4842792837184084892, i64 -5304010241482995250, i64 6755250961797497775, i64 9048033119086417455, i64 -1108070978414648086, i64 5826105850985828557, i64 -7680453239045641455, i64 560810385776388522, i64 1510258996113381999, i64 4242759787663244041, i64 -6371299727288537809, i64 986721072297230728, i64 -6601622652483542542, i64 5054597165169813465, i64 8434582212576960058, i64 -7344409676906826314, i64 3062362741780863011, i64 3023426232792229705, i64 2589972562094901801, i64 -6059473297868916128, i64 8729237503968203853, i64 -6164933397020528253, i64 857197525987071294, i64 3411515909673742042, i64 -2426274631684257711, i64 6023720643652634704, i64 -6378048178475828903, i64 2003461668597180319, i64 6808868508692211994, i64 840658439931156573, i64 -4193114827417240325, i64 5687680138952488108, i64 -7012340571727775998, i64 3667703542203634467, i64 2577784813664150577, i64 -4783010610732533445, i64 6648086778043386594, i64 -2353720704702899393, i64 7843144523484747129, i64 1956512362778724795, i64 8628432671458396650, i64 -1379604622153729554, i64 -8829191216037587370, i64 -8600451135664357025, i64 -2060573550785558627, i64 -3694534136809396181, i64 -1245794340008498336, i64 -7931995117282534327, i64 8746865353516951171, i64 -445995043368997788, i64 5919538612739260218, i64 6210032595064403510, i64 8447071291496133741, i64 1904379616031944918, i64 -6905476373891173735, i64 -1457727881916548051, i64 3141465294590726539, i64 2990438293690813645, i64 521348813365586629, i64 -6641877390133626113, i64 -7227917970621976616, i64 -1087884681389169805, i64 -5550624350046232735, i64 -1671995580744298335, i64 7053570122562695466, i64 -231419795828374497, i64 -249232188714169816, i64 -7974537088485489274, i64 9077312677216600472, i64 3392912321057737227, i64 -2525636549291120516, i64 -3879146523241428427, i64 1515572415620196880, i64 -2504318552566069147, i64 -4381969474137354723, i64 1453267541181795946, i64 -2895144320618000706, i64 -3163052664478396981, i64 -8147029455899645114, i64 3422317254640551800, i64 -2884408639077695826, i64 -1133416472885995312, i64 -3507527922069304807, i64 -8138048718034251599, i64 -8117993776332515380, i64 -2525856402363592319, i64 -4245717154014504200, i64 5047948850925838546, i64 5414931236390761543, i64 8586588396385453995, i64 4357976456664546391, i64 4627715698433089804, i64 -5452527015859517959, i64 -1866406770048471251, i64 -1288157696922502265, i64 1559076271750742271, i64 -2562509757222663239, i64 -397149411120211849, i64 3526248982355249636, i64 -614726702397292071, i64 -1011980152414198556, i64 6630039495465180908, i64 -3065497249832766734, i64 -594239978017533010, i64 5610924536772170322, i64 -8294545824040224007, i64 5097125344695397423, i64 2311692649520144810, i64 1496084824532971545, i64 4116816738861197830, i64 1495871035212446199, i64 -4516221910899742009, i64 6059670869658250589, i64 -8985758117714506230, i64 6166579375075680570, i64 -449589869985187616, i64 8903541109436695491, i64 -6574313926079006560, i64 -3708712874548444972, i64 -1346172944773535387, i64 -5285595832246696706, i64 6198657968322814225, i64 3549388728474206197, i64 2917136748546788035, i64 1016573541466123185, i64 2229175585786433162, i64 5262117930202955022, i64 -4818982147387600511, i64 2075908781135235143, i64 7142120446694670064, i64 6599853539727975639, i64 -3973390446426796633, i64 3868279111854857493, i64 3039804227570968766, i64 2006112749559396550, i64 -1281917093781343457, i64 -504831433127238821, i64 -324716587375445775, i64 -909817322336163969, i64 -3504663137050099342, i64 3609210663087277133, i64 -7776864834343531130, i64 -7683804379565954404, i64 3983624693211437321, i64 -1341566024329322630, i64 1558979145102971595, i64 6452507669955937957, i64 6170752769123333781, i64 4336556334784039953, i64 513277325919865917, i64 3714195479688616339, i64 3378920775117903921, i64 312840310293552405, i64 1214474229900011662, i64 -8991926405924064001, i64 -6272612268173340246, i64 799856448259696872, i64 2133096173892700458, i64 -7459592635193830476, i64 -5276457647737019850, i64 -310413739156194926, i64 -4581627180005215444, i64 478812132095770283, i64 7723898475803066677, i64 4004759817445430487, i64 7022326497361742438, i64 -5552464792700817026, i64 -3876705664664655412, i64 -3876601219863311430, i64 4306380994592869306, i64 2259107538183221058, i64 684737094155059683, i64 3943329139280516982, i64 6612004273749370935, i64 -1132076040097140922, i64 -5127285451095329674, i64 5293005921377964066, i64 3820925421023736034, i64 1775775958736888782, i64 3807327397722305749, i64 2465144232932323126, i64 4574311005748520861, i64 -3905762377442138317, i64 8079420201738835828, i64 -8306615625637632577, i64 5225111708919268189, i64 2267544200960468422, i64 5333328788344351951, i64 6579160803077912589, i64 -8101172612994549262, i64 -793276268340481022, i64 -4898043879648473674, i64 3967045433163289821, i64 -2105415939475687826, i64 -357497556311767161, i64 -4898041712621253164, i64 -313933981481708348, i64 6600666161849611787, i64 7642030767366603022, i64 7828881024849198044, i64 -5172806965630053424, i64 1714114085259063121, i64 -2230437471695174718, i64 2548765720727708097, i64 5899078933203474842, i64 5353194475414838283, i64 -2860124362733943347, i64 359429797643565852, i64 4919242358345505470, i64 -2816755006375588503, i64 -8405395665541032293, i64 8258411758173218079, i64 -2116306816980085278, i64 -6724603440402990068, i64 6531226468706179430, i64 5494931789739339801, i64 8851363606318816931, i64 -7505771599215041776, i64 -7655652870681453794, i64 4676127176164168613, i64 -8079489078756155105, i64 -3322051505765981366, i64 6834432501311473980, i64 -1100062262004861132, i64 279636138917731265, i64 7832598580484840775, i64 8521502292608841215, i64 7668359187516543107, i64 4503434572376051616, i64 1783353841093934719, i64 3567086072458566588, i64 3503226640861183685, i64 -4854634396491381655, i64 8189241384792796230, i64 -2692906691731787654, i64 -8446323539962951769, i64 5243349618930714576, i64 8974503365339211619, i64 -1615332442013406549, i64 -5941439034986401545, i64 -8234101361082710968, i64 4883963894295408471, i64 6932702735222171907, i64 -8974963476275941012, i64 -8366295244536687782, i64 -8515471052105272883, i64 1646666055534785384, i64 7830189572465321462, i64 3642019452924642072, i64 1790661940214508642, i64 4384281423143300006, i64 -5726563840860710136, i64 2777261201485471337, i64 -6860086806131766376, i64 2795060541894885996, i64 -5463041710724687528, i64 -7779579635385218108, i64 -4001518183735203188, i64 -4935275325125500794, i64 6847359850001629904, i64 9162457171743611678, i64 -4894973360085979152, i64 -5819484020432833224, i64 -2202281810680181963, i64 -5156349566014754413, i64 -6316388368220838369, i64 -3746206307932590047, i64 5667277867122274573, i64 958311840282843228, i64 3369310919865025676, i64 -4801758422567778233, i64 3360538976326515321, i64 -7122795401449233574, i64 8560986679451003508, i64 -8886758606907145304, i64 -8879077466095635215, i64 8030683086018645849, i64 1201935931797805634, i64 -210528124203294677, i64 2128531977001026104, i64 -3049207960361656982, i64 -6952021933647631019, i64 5588175731694521030, i64 -6302528363659798969, i64 4971652866771943025, i64 6797368530941777038, i64 -2457810322957990141, i64 -6277011617532453375, i64 3455224912461966921, i64 -7239267852724068754, i64 6638184008586108551, i64 876966181917354155, i64 -4165969258735821406, i64 -6578367894803781107, i64 5094606124359070792, i64 -3993165062509133654, i64 8505325065227487926, i64 2674253304099911331, i64 4767065821268886283, i64 6944853104044841519, i64 5744300431591737890, i64 3954949945883574155, i64 -3352434035630133401, i64 2386490071391921187, i64 -4177390625672690339, i64 -4965203822961829452, i64 4210343175013169963, i64 544829902919122189, i64 -2829106362432045672, i64 -1146877921750388432, i64 3410194123559955758, i64 7069533333962329062, i64 -8254318984456310439, i64 9014952556091631039, i64 5107897316461534385, i64 -5772949292150339809, i64 -9207953032344870899, i64 -4873143056503091095, i64 -5747602394835791333, i64 -5261707591620839929, i64 3978529059570739985, i64 4053865398269325411, i64 -6105971366527382108, i64 -7176016278410453815, i64 8599792664233539416, i64 -7394796940726284890, i64 -8187459749194905143, i64 5419180324234530336, i64 4027406343440868222, i64 345518724118491300, i64 1213065114220220602, i64 -6512414035810337206, i64 3778002624651860952, i64 -3212951805601536577, i64 -7722082561934210454, i64 -2956415260641883600, i64 -5719013733026342803, i64 -2445952797663818746, i64 152228923778959629, i64 966431570414835836, i64 -1420331402576186583, i64 -8860499076177785105, i64 -4581441890889043419, i64 -5414266252018525408, i64 7205399155639244084, i64 2352698440166616535, i64 3846514820327172682, i64 -4207922285019253810, i64 3385059750753536508, i64 -2980487519021231416, i64 1805234195122157968, i64 4606653501026064278, i64 -501310354189028864, i64 1948400949777969741, i64 -338016297288297744, i64 -4138121067904518727, i64 796159365529948754, i64 3179598216583183331, i64 -6809205246639690351, i64 2397860492018111658, i64 4908263921011540064, i64 6774342117317397613, i64 1868829077897333428, i64 -7891237944755208226, i64 155558651144791074, i64 -8980964988973325817, i64 1940102377673229433, i64 -2162667191148566472, i64 238781847098730611, i64 -2045774016429010681, i64 4112951050880599017, i64 5814990762632464009, i64 -635765796810168096, i64 4887376258962457661, i64 2873453106585598176, i64 5279427371741969323, i64 -5300587972597245939, i64 -8004690919260367339, i64 -1156721020648850970, i64 -171137615038502909, i64 -2833998185087325975, i64 5592228538930893877, i64 -164876482182871979, i64 -2688908313273342993, i64 2522523026832659169, i64 -3597359172814404343, i64 485639147209416474, i64 -2086353870012455751, i64 139637658821967288, i64 -7569987487955923365, i64 -1994878954732108760, i64 9173980366885705387, i64 8215484004463556595, i64 4819453588921901726, i64 -6731712544023348993, i64 2512343942531111825, i64 7621461485574536006, i64 -5455859926050477998, i64 -2360485304371474040, i64 6895512393901928957, i64 3821540787156884607, i64 1768546372631878990, i64 -3616880607626181049, i64 -439668875368121450, i64 -6373121278576178180, i64 1941802825078070479, i64 1769068233912245241, i64 -8060346303731272219, i64 8932829213395227536, i64 -253401864683514930, i64 7658973397173260157, i64 6523501421143486404, i64 7703283707576667150, i64 2547795661672497399, i64 -2307062534906745721, i64 7954308336651083111, i64 7343715418363673997, i64 6087060574844471214, i64 -5985060287096762767, i64 8236584592301084588, i64 -2630005446388045562, i64 -5292779203729366921, i64 1298894337335618562, i64 -3769671402476653745, i64 -3863793853067602495, i64 -5363565941668329263, i64 8974852404156179884, i64 1798350956521727133, i64 5013466233167731166, i64 -6754395169906399453, i64 -1774753347651992030, i64 6339064960668775215, i64 1912919059176229279, i64 1005580841427980045, i64 8889832340360970335, i64 1028690608317777550, i64 -7969198297683031460, i64 -2188213296006820005, i64 -2410513143453071399, i64 4954719812189130653, i64 1243927845078023509, i64 6145454729528379043, i64 -1036382453878825792, i64 -7137974014742975388, i64 -6745767918205724476, i64 1798666966331435977, i64 5123461524421150364, i64 -2811912656342564194, i64 -1964142717409424143, i64 8975193158117025128, i64 2896650296220737543, i64 -6020690955763856672, i64 7026721287269041227, i64 7577296214511485165, i64 -5147849870218565404, i64 -5972018437913443497, i64 5881237347476656540, i64 1768917328883196284, i64 8383361203023520363, i64 -2072594366234692985, i64 -7542399457461778384, i64 -8606281149839176365, i64 7863227075349651633, i64 -1802595991158474540, i64 -4416910009778012894, i64 -1916013627014965977, i64 -6609300243479145756, i64 850963156689718808, i64 6367286466359844068, i64 -4517095702829627613, i64 -3887362813044226931, i64 5347370435514623407, i64 5969170792145270413, i64 2685015990475679972, i64 -6272222068168810414, i64 6482787327551650459, i64 1871080527793615988, i64 784800008162842952, i64 6434313625924110477, i64 -6393825077608969579, i64 -8999161297004943500, i64 2332518408097583169, i64 7695054047075652127, i64 369909262012713925, i64 1950426375346097245, i64 610001451439668796, i64 3872789013368615399, i64 1053454100363932530, i64 -1663995550250338953, i64 6126904672561713892, i64 -5015590453906316272, i64 -6397567063912991430, i64 -6373926470446838714, i64 5887039554596043033, i64 2274282522484318133, i64 6948694536735401974, i64 -2152490733242240245, i64 -6150029413838475976, i64 8750502153271570792, i64 6172492193558171407, i64 -496844292553686344, i64 2344829653319464322, i64 -705382974826945723, i64 2087455608164222304, i64 4839207863369417008, i64 -5873762880718153985, i64 7497300054559117685, i64 7162556720168292917, i64 9204822049915150741, i64 7047562595287496958, i64 2340994275224809727, i64 -277546510464610345, i64 2959133359623322906, i64 2491288740142285288, i64 -6326368450094417585, i64 -3032979202290367787, i64 -8440909035066224126, i64 -694763552253100516, i64 -3249169650368062619, i64 2504647592679715098, i64 -6432370491858187681, i64 -8259227561771703475, i64 -9109602449490329220, i64 258430587357150750, i64 3858649603701246324, i64 4372617778380311878, i64 -8415628289077745013, i64 -5532213361719074532, i64 6535558340052252223, i64 5951707543567391557, i64 -4778248633379624520, i64 8944956890090086615, i64 5357694892575791418, i64 -3312097047795407765, i64 2071527919779221085, i64 -6827278773026336023, i64 -7475194147019027709, i64 3678008345797913014, i64 9088301228714533087, i64 716352713699229370, i64 5468613820129061192, i64 736280772609974982, i64 8732421590908121296, i64 5011406136390284615, i64 -6392580584541489291, i64 -9018186611627040517, i64 5178329383078476890, i64 -1890601787245741510, i64 -6002683287543503669, i64 3786450332483043526, i64 5785391420266496925, i64 353118917433246955, i64 -7149209000770721055, i64 -990819830123673635, i64 -6868851160078125111, i64 -3159639599678132365, i64 914820744821229949, i64 5658526771607848737, i64 3058430832652411597, i64 -996920893753582678, i64 7855186425420216249, i64 2243727555715047523, i64 2927006143245194068, i64 -6184243646227995729, i64 -4024384913812967687, i64 -3662350827464227552, i64 -4375751129515084696, i64 2139724702804485878, i64 1718734737257099089, i64 -6251640209310801701, i64 -4769191961837085171, i64 2446785372705403151, i64 -5066275772588404254, i64 8231621782885613121, i64 -4377796573624781842, i64 7427554024871240936, i64 3827655727677995720, i64 -1475312005614911138, i64 8600552947987688870, i64 6954186393397195388, i64 -3234343779929110634, i64 2466793751451509832, i64 3016477515025926431, i64 3595198308576847809, i64 6873728170862481894, i64 6027345941909366311, i64 -8045040450770600548, i64 2977178977420206943, i64 -3128359324519544163, i64 -2232497166487281518, i64 -9056566133514550598, i64 -1055187030742993025, i64 -8259227802295545632, i64 -8198182772167448695, i64 -8941957637879787831, i64 -4893376402833483516, i64 3301310628363111367, i64 6697198390580922039, i64 -9189519753996203962, i64 1922058221675652419, i64 2920663345753759635, i64 5411577630881610944, i64 -1147021503686353450, i64 8072697897136943000, i64 -4735896551369698374, i64 1008171771484055390, i64 -4575798249065042682, i64 7512820168301025948, i64 -6724647464899983619, i64 15092335579270506, i64 5699389842190439205, i64 5259216842248279616, i64 -4071646158542517349, i64 4649155322824331691, i64 300893959773608440, i64 -1075772636782497719, i64 -8637684257900368061, i64 -8896789680466912034, i64 8969796075548559424, i64 -5403835223799643017, i64 6172254402129603377, i64 4260389265785216118, i64 -4735909728688810780, i64 8703439489581744400, i64 7456611812514992934, i64 215704865425018655, i64 -7760307987085805045, i64 -9221650329899304678, i64 5123402988313574261, i64 34716075518443559, i64 1609911818846776885, i64 -2446332033998983476, i64 -7950493158636580295, i64 9076935399502779631, i64 -5707204498251770339, i64 4587369999475364528, i64 -4755682717117443046, i64 2768509191348354303, i64 -7949934750866304988, i64 -8748466028426412081, i64 -3128222511856496738, i64 4386016269206374340, i64 -1936576286807328996, i64 713330194081895637, i64 -9034761923861027326, i64 3286106633106470864, i64 3828096096928671411, i64 5209617279780088663, i64 3477125941330628412, i64 2781423519679516837, i64 -3916478174351109830, i64 -1520087358475324885, i64 2451206555975058846, i64 -1530220525827117852, i64 6940214238082566529, i64 2495702344634241346, i64 7640437649933985588, i64 -6840642049799937404, i64 3544616115316618252, i64 2759661567688885401, i64 -8445920473501951725, i64 4907322223143314448, i64 -7510087839601025635, i64 2802968306533830474, i64 7224928628005721446, i64 777400028362281738, i64 8229564866246240724, i64 2458981100046072061, i64 7466904468547768455, i64 -1996143025294675659, i64 -148444378760521322, i64 -1301538213696910732, i64 -4446721954384638072, i64 1564420620720105007, i64 -873017680362677146, i64 -2463981007177022318, i64 -531714539932880493, i64 2234377672776033504, i64 4392410093821568924, i64 -1763540088586725391, i64 2625935453790503975, i64 541720599595198017, i64 -6023599695165866200, i64 5462736248263173664, i64 -307191194773001712, i64 7326779425594417683, i64 -3246818086200818474, i64 2748002045194789851, i64 4337737133472993109, i64 -2019542026209522533, i64 -4854224241617993096, i64 6421693823977912474, i64 -4854847336056731746, i64 6721525410758065211, i64 4897834480203358898, i64 3519160508371502152, i64 6543794081768966985, i64 5002141270370413641, i64 -5131405157215729532, i64 -2118251338002405818, i64 -4140987971454625091, i64 4255613480757482182, i64 9060982250795060299, i64 6936148112530690187, i64 7767922353316176975, i64 -8530282557450974011, i64 7158869138698810774, i64 3826756665916266962, i64 -8267996045548563415, i64 -5485644677874128108, i64 5811000786916235909, i64 6387346790437876477, i64 -5403375653857371537, i64 -1872792479039029440, i64 3640259391128869315, i64 3772715117218441747, i64 -2493383513873493463, i64 5366300220411246953, i64 8560302770044260339, i64 -6158596122160288822, i64 -4746919280615642693, i64 -7070870046929585423, i64 1437747298378380433, i64 -8290601125044842366, i64 7760752774162175607, i64 -3522378698364750678, i64 5654265972961560447, i64 -2642250793514734320, i64 -5564047645630037117, i64 -2656984758653230867, i64 1202246274069166921, i64 8978461412460108263, i64 -4950193270962789360, i64 -3737388917121471957, i64 -4627242956271270101, i64 -7925632212410609938, i64 360561314205319522, i64 -1014450657442244063, i64 3844246373639227904, i64 -7449453281688330695, i64 -3026970143955637252, i64 -2052596039291042265, i64 8039703378765865205, i64 -8190442649480628401, i64 6223136497702151391, i64 6884037246495997459, i64 7750477367842721014, i64 -8527513931591199398, i64 5983758330917873119, i64 8080169393455602628, i64 7129706753557296106, i64 -2448446947716420575, i64 1148197514430783220, i64 -490477633727630398, i64 -4681175669691572177, i64 -6380122600320269558, i64 -1688328157876821077, i64 -4357294453107864219, i64 5718863207330332387, i64 8078799244427056790, i64 -869480601129828420, i64 3080103771601508849, i64 -6799744614784857682, i64 -3761527910769745907, i64 8326964186548177965, i64 -842901409028370796, i64 -288304117453707321, i64 1568532110067833324, i64 -6597966412978041498, i64 -7228523251451307355, i64 7956839362854936156, i64 -6107431544279320199, i64 -5799902204203978074, i64 5875002213749965235, i64 2488707390168885139, i64 -3162142518637518693, i64 9090137542582707732, i64 2534824136935543297, i64 2930930424997279802, i64 -4528294173742845110, i64 4005680406608373022, i64 -7838026684074798488, i64 -2740196053903424520, i64 6393164243796758224, i64 2437649465006005478, i64 -306949412090684804, i64 -4887108798060299336, i64 6366150665369128402, i64 -1956083399632168181, i64 8121439193596516994, i64 -307346778523348260, i64 7968674360056347576, i64 5399915716818505602, i64 -5469732333506250716, i64 -3468968279422342195, i64 -1667557619501959779, i64 6078978836731585181, i64 -5933358529001143028, i64 1356568094718277291, i64 4115234450336779917, i64 -7731658572132209740, i64 5657016889543829590, i64 -6565265413604094843, i64 -4124500013913083557, i64 2866718548829749820, i64 8936690029114718460, i64 -2981962552088653489, i64 7552630162910436918, i64 -6828618431052030529, i64 -9128638966702058021, i64 -6647121753656875571, i64 -9161863194185897741, i64 5159675774553656146, i64 -3108284678587539864, i64 9129171606079927741, i64 -8839965997850666939, i64 3523167926059913710, i64 4773488787380547525, i64 -6344463025900789243, i64 -8108838869142588441, i64 -5692612750775516225, i64 9065048612415864635, i64 1473403800163027588, i64 -3962537726424173543, i64 6159547896675059748, i64 -8069888612806714672, i64 -3053905959787282253, i64 2600144273408632312, i64 -6446278815663946329, i64 -5084575461263341854, i64 5856491691432097349, i64 -1627620665369928152, i64 1144313748587248038, i64 -2757333911342737850, i64 -6040819469514024312, i64 4700640393986870661, i64 570096523357887364, i64 -2847968367206701176, i64 7458691496668920165, i64 2029504264016384135, i64 3028956415590250090, i64 -4069019421986739600, i64 1442910432905839611, i64 -1128201750854411275, i64 -706883046993358940, i64 94726522777784274, i64 8427604660473015937, i64 -6252608734261073394, i64 -9181068449420549260, i64 4062331271446666540, i64 -4543431513034703850, i64 2236983194165755824, i64 7939462294146913819, i64 -8785767662933549896, i64 1470730960193089462, i64 -2892576261181037224, i64 -5656182241554242309, i64 -4135209529446105500, i64 -8538394872994640275, i64 3472524216287674563, i64 -3487735530365370708, i64 3183242320380955704, i64 2878016466924384895, i64 5868889183165449324, i64 4381445937149458199, i64 -2506147185731114704, i64 3711308361374123526, i64 5480655901559294991, i64 6481731991139615170, i64 -3454273327635465130, i64 2509244857646016692, i64 801138577162747418, i64 724810289389177359, i64 -5027052859632137065, i64 -2830905515180507707, i64 3790463863780918757, i64 7589256655410776507, i64 8512131695373096802, i64 -4955530020661851639, i64 3897608633505264824, i64 5502653925990797983, i64 -7801933488656569989, i64 3806203440322792908, i64 -660881853540309897, i64 4296272696357204921, i64 -5057042658954890672, i64 1760430828667296628, i64 991643058234472204, i64 6354686522332725635, i64 -6699566764378347821, i64 3954969360378171933, i64 -749814511124519305, i64 9129697865445061379, i64 3447048662087358048, i64 -5415528113476565300, i64 -9010203234579321770, i64 6682333795156342943, i64 -6641356947676460101, i64 4941906214047074965, i64 -3365760567903385174, i64 -5986147962569016173, i64 4556427109574682965, i64 -1782493279068119795, i64 -884781829898770905, i64 6614940032135975123, i64 7467795881381699025, i64 -4394442208398229262, i64 -4394446197497503623, i64 -4392190408586446164, i64 -2192296704404080763, i64 4357810142831324517, i64 2211615386921368077, i64 -6857918264679431345, i64 -3046732479401372729, i64 4566628565552742239, i64 -7866274128970745554, i64 -5978635514316673785, i64 4748952733488056222, i64 8785063245189113771, i64 -5055939068786316591, i64 -5854453606889235658, i64 -7538912822819432423, i64 7760561383454598061, i64 6536954718999901702, i64 7303593466718526898, i64 -730933339434883128, i64 -6357593940058896576, i64 -4413618431348388994, i64 -2767395202856025942, i64 6226057576454500473, i64 4395279262386518526, i64 -151356848327763560, i64 -4324722290747493430, i64 -5428124424412657113, i64 -4540219927567515804, i64 285487678346502076, i64 -8780818956579966733, i64 -6272607259189001185, i64 6355334886555388322, i64 6781440947545252888, i64 2411404755807239316, i64 -5171111091681169905, i64 -8067151737420670709, i64 1912347198243552670, i64 -2368116077377428313, i64 2513827753766728154, i64 -8950686822847815461, i64 3437358272649597323, i64 4873580237692481039, i64 3874954268333103908, i64 -9171426063402998994, i64 4114311407637512581, i64 -1358030564112127811, i64 -5209366736374799251, i64 8314558821959111569, i64 2458345596860686034, i64 474208757496452057, i64 -7855370256086009483, i64 -1092355488444895332, i64 -2121460163528110552, i64 -1084371081213887428, i64 -2944153878138681816, i64 -7490622727635709712, i64 438432761121026070, i64 1539308820544809033, i64 -4069109526351566758, i64 8330665875692461689, i64 5730967313327399912, i64 -7547213003359910644, i64 1558326453798627397, i64 3647278725309419782, i64 -169788107540520771, i64 -1163533270367260002, i64 7278550417115878185, i64 1455436749807255250, i64 6930415949892454936, i64 -3723197596307255199, i64 -6799584050977255083, i64 1743603942023185932, i64 363973750171731213, i64 -7193893060633754291, i64 5120652738103190070, i64 -5373628744072951340, i64 7821401911523562915, i64 -5313089009496518393, i64 -8320335351454578557, i64 5626425506538171294, i64 -8546629385368708841, i64 1505021263815645270, i64 -5258038995762783881, i64 3666735048468335800, i64 -7272028843477776968, i64 958867347596288813, i64 -7095219537267957014, i64 5182949519969261166, i64 -6113021442289784505, i64 4049558620389903884, i64 2348869346005116376, i64 3004024531931837993, i64 9140209335745649565, i64 1315478909342399249, i64 1640954074359565371, i64 3525264658045614827, i64 7001581029492661640, i64 3580649855943285520, i64 7050538112213326429, i64 1300778438878870289, i64 6820094195466636859, i64 8201199569566725718, i64 -2137629054884496880, i64 -6682763343522221024, i64 -3419482786617465483, i64 876171571319702929, i64 425921477949902994, i64 5883302833204894681, i64 7031360831657684358, i64 -3253739500447235253, i64 -3241664424286327768, i64 4716593184217524857, i64 -9004329144013505958, i64 -5034335474421332524, i64 775760096859150319, i64 2671051676869970568, i64 608062835592933227, i64 -7670918618896252611, i64 6419976207768976812, i64 1178994320035588991, i64 2986737936803177281, i64 7540657568598614234, i64 -7478638031148107389, i64 -5712478127799248117, i64 1762751864763712669, i64 -8598565000059474940, i64 -7761012013083030233, i64 5334078977447676961, i64 -6659684057392758575, i64 -6752657101457763965, i64 4896549038525771941, i64 4234565112740734371, i64 -7785587460263044630, i64 1819975392278753923, i64 -4084564115950010068, i64 6595999157426327821, i64 4751688129473828625, i64 -8293058491221261527, i64 -8542091368622698194, i64 333327972377293442, i64 301246261774545074, i64 6161722732172572882, i64 5892118497064938257, i64 2946059042374170784, i64 3848947167163341904, i64 -2279599985457775386, i64 1897746185093178299, i64 6207959568679065127, i64 -2951182921323595686, i64 6536070948945349450, i64 2578931787052546323, i64 -7933094526407378433, i64 -4398892827431355137, i64 7934705904821673599, i64 2927876031012374771, i64 4760035599491130391, i64 1216334200558084599, i64 1306120055072325016, i64 -5195290428222698211, i64 7659701765395050988, i64 2909179773061746041, i64 -177980263159322151, i64 1533630297828575327, i64 3124186917254249105, i64 6775559079125221562, i64 -7655829586533847946, i64 8824397455575160090, i64 -4682207061469456325, i64 9222676629967964498, i64 -7052884684815076484, i64 1989036848745278527, i64 -1468367207418438086, i64 -2616863057665993741, i64 9123799973866208573, i64 -5148496769890156577, i64 -2354148683035414273, i64 358176329226154807, i64 -3204346323839762863, i64 8050026568231098873, i64 -2022727857247687010, i64 2278572779521262899, i64 6419084201404792783, i64 9169661565782687457, i64 -8537631063376777, i64 -7619429671567534465, i64 7365510243690695903, i64 6323810004702819326, i64 9191280176379190383, i64 3456940280950337333, i64 4011553441366603135, i64 -2117723194691596695, i64 7357307183832919895, i64 -2324962795290623450, i64 146371480050444092, i64 1235805173920228964, i64 -1837398971238092272, i64 1650411309665424154, i64 2466120413719351360, i64 -2587910338730510540, i64 -3686547202315701171, i64 -8879166845538157108, i64 -2276227799093753479, i64 17918651407794152], align 8


define i64 @df.scalar_nullable_count$2edart.Node.count(i64 %v0) nounwind {
b0:
  %gcq = alloca { ptr, i64, [2 x i64] }, align 8
  %pilhaq = alloca i8, align 1
  %ctx = call ptr @df.context()
  %ctxtopo = getelementptr inbounds i8, ptr %ctx, i64 8
  %pilhalp = getelementptr inbounds i8, ptr %ctx, i64 376
  %pilhal = load ptr, ptr %pilhalp, align 8
  %pilhab = icmp ult ptr %pilhaq, %pilhal
  %pilhax = call i1 @llvm.expect.i1(i1 %pilhab, i1 false)
  br i1 %pilhax, label %pilha.estouro, label %pilha.ok
pilha.estouro:
  call void @dartforge_stack_overflow()
  ret i64 0
pilha.ok:
  store { ptr, i64, [2 x i64] } { ptr null, i64 2, [2 x i64] zeroinitializer }, ptr %gcq
  %gcs0 = getelementptr inbounds { ptr, i64, [2 x i64] }, ptr %gcq, i64 0, i32 2, i64 0
  %gcs1 = getelementptr inbounds { ptr, i64, [2 x i64] }, ptr %gcq, i64 0, i32 2, i64 1
  %gcant = load ptr, ptr %ctxtopo, align 8
  store ptr %gcant, ptr %gcq, align 8
  store ptr %gcq, ptr %ctxtopo, align 8
  store i64 %v0, ptr %gcs0
  %v1 = add i64 0, 1
  %fxa2 = add i64 %v0, -2
  %fcb2 = inttoptr i64 %fxa2 to ptr
  %fp2 = getelementptr inbounds i8, ptr %fcb2, i64 16
  %fg2 = getelementptr inbounds i64, ptr %fp2, i64 0
  %v2 = load i64, ptr %fg2, align 8
  store i64 %v2, ptr %gcs1
  %v3 = icmp eq i64 %v2, 0
  br i1 %v3, label %b1, label %b2
b1:
  %v8 = phi i64 [ 0, %pilha.ok ], [ %v7, %b3 ]
  store i64 %v8, ptr %gcs1
  %v9 = icmp eq i64 %v8, 0
  br i1 %v9, label %b5, label %b6
b2:
  %v4 = call i64 @df.scalar_nullable_count$2edart.Node.count(i64 %v2)
  %v5 = load i8, ptr %ctx, align 8
  %c0 = zext i8 %v5 to i64
  %v6 = icmp ne i64 %c0, 0
  br i1 %v6, label %b4, label %b3
b3:
  store i64 0, ptr %gcs1
  %v7 = call i64 @df.box_int(i64 %v4)
  br label %b1
b4:
  %gcvolta4 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta4, ptr %ctxtopo, align 8
  ret i64 0
b5:
  %v13 = add i64 0, 0
  br label %b7
b6:
  %v10 = call i64 @df.unbox_int(i64 %v8)
  %v11 = load i8, ptr %ctx, align 8
  %c1 = zext i8 %v11 to i64
  %v12 = icmp ne i64 %c1, 0
  br i1 %v12, label %b9, label %b8
b7:
  %v14 = phi i64 [ %v10, %b8 ], [ %v13, %b5 ]
  %v15 = add i64 %v1, %v14
  %fxa16 = add i64 %v0, -2
  %fcb16 = inttoptr i64 %fxa16 to ptr
  %fp16 = getelementptr inbounds i8, ptr %fcb16, i64 16
  %fg16 = getelementptr inbounds i64, ptr %fp16, i64 1
  %v16 = load i64, ptr %fg16, align 8
  store i64 %v16, ptr %gcs0
  store i64 0, ptr %gcs1
  %v17 = icmp eq i64 %v16, 0
  br i1 %v17, label %b10, label %b11
b8:
  br label %b7
b9:
  %gcvolta9 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta9, ptr %ctxtopo, align 8
  ret i64 0
b10:
  %v22 = phi i64 [ 0, %b7 ], [ %v21, %b12 ]
  store i64 %v22, ptr %gcs0
  %v23 = icmp eq i64 %v22, 0
  br i1 %v23, label %b14, label %b15
b11:
  %v18 = call i64 @df.scalar_nullable_count$2edart.Node.count(i64 %v16)
  %v19 = load i8, ptr %ctx, align 8
  %c2 = zext i8 %v19 to i64
  %v20 = icmp ne i64 %c2, 0
  br i1 %v20, label %b13, label %b12
b12:
  store i64 0, ptr %gcs0
  %v21 = call i64 @df.box_int(i64 %v18)
  br label %b10
b13:
  %gcvolta13 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta13, ptr %ctxtopo, align 8
  ret i64 0
b14:
  %v27 = add i64 0, 0
  br label %b16
b15:
  %v24 = call i64 @df.unbox_int(i64 %v22)
  %v25 = load i8, ptr %ctx, align 8
  %c3 = zext i8 %v25 to i64
  %v26 = icmp ne i64 %c3, 0
  br i1 %v26, label %b18, label %b17
b16:
  %v28 = phi i64 [ %v24, %b17 ], [ %v27, %b14 ]
  %v29 = add i64 %v15, %v28
  %gcvolta16 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta16, ptr %ctxtopo, align 8
  ret i64 %v29
b17:
  br label %b16
b18:
  %gcvolta18 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta18, ptr %ctxtopo, align 8
  ret i64 0
}




define void @dart_main() nounwind {
b0:
  %list_buf_35 = alloca [5 x i64], align 8
  %list_tags_35 = alloca [5 x i8], align 1
  %sargs97 = alloca [1 x i64]
  %sargs73 = alloca [2 x i64]
  %sargs100 = alloca [1 x i64]
  %sargs111 = alloca [1 x i64]
  %gcq = alloca { ptr, i64, [3 x i64] }, align 8
  %pilhaq = alloca i8, align 1
  %area = call ptr @df.get_area()
  %ctx = call ptr @df.context()
  %ctxtopo = getelementptr inbounds i8, ptr %ctx, i64 8
  %pilhalp = getelementptr inbounds i8, ptr %ctx, i64 376
  %pilhal = load ptr, ptr %pilhalp, align 8
  %pilhab = icmp ult ptr %pilhaq, %pilhal
  %pilhax = call i1 @llvm.expect.i1(i1 %pilhab, i1 false)
  br i1 %pilhax, label %pilha.estouro, label %pilha.ok
pilha.estouro:
  call void @dartforge_stack_overflow()
  ret void
pilha.ok:
  store { ptr, i64, [3 x i64] } { ptr null, i64 3, [3 x i64] zeroinitializer }, ptr %gcq
  %gcs0 = getelementptr inbounds { ptr, i64, [3 x i64] }, ptr %gcq, i64 0, i32 2, i64 0
  %gcs1 = getelementptr inbounds { ptr, i64, [3 x i64] }, ptr %gcq, i64 0, i32 2, i64 1
  %gcs2 = getelementptr inbounds { ptr, i64, [3 x i64] }, ptr %gcq, i64 0, i32 2, i64 2
  %gcant = load ptr, ptr %ctxtopo, align 8
  store ptr %gcant, ptr %gcq, align 8
  store ptr %gcq, ptr %ctxtopo, align 8
  %ta2 = getelementptr inbounds i8, ptr %ctx, i64 96
  %tb2 = load ptr, ptr %ta2, align 8
  %tfa2 = getelementptr inbounds i8, ptr %ctx, i64 104
  %tf2 = load ptr, ptr %tfa2, align 8
  %tnx2 = getelementptr i8, ptr %tb2, i64 32
  %tz2 = icmp ugt ptr %tnx2, %tf2
  %tnp2 = getelementptr inbounds i8, ptr %ctx, i64 56
  %tn2 = load i64, ptr %tnp2, align 8
  %tk2 = icmp ule i64 %tn2, 1024
  %tq2 = or i1 %tz2, %tk2
  %tx2 = call i1 @llvm.expect.i1(i1 %tq2, i1 false)
  br i1 %tx2, label %ao2.lento, label %ao2.reg
ao2.reg:
  %trp2 = getelementptr inbounds i8, ptr %ctx, i64 48
  %tr2 = load ptr, ptr %trp2, align 8
  %trb2 = getelementptr inbounds i8, ptr %tr2, i64 1024
  %trv2 = load i8, ptr %trb2, align 1
  %trz2 = icmp eq i8 %trv2, 0
  %try2 = call i1 @llvm.expect.i1(i1 %trz2, i1 false)
  br i1 %try2, label %ao2.lento, label %ao2.rapido
ao2.rapido:
  store ptr %tnx2, ptr %ta2, align 8
  %tpp2 = getelementptr inbounds i8, ptr %tb2, i64 16
  store i64 0, ptr %tpp2, align 8
  store i64 4398046642177, ptr %tb2, align 8
  %thb2 = ptrtoint ptr %tb2 to i64
  %th2 = add i64 %thb2, 2
  br label %ao2.fim
ao2.lento:
  %tl2 = call i64 @dartforge_object_new_t(i64 1024, i64 2, ptr @df.mt.scalar_nullable_count$2edart.Node)
  br label %ao2.fim
ao2.fim:
  %v2 = phi i64 [ %th2, %ao2.rapido ], [ %tl2, %ao2.lento ]
  store i64 %v2, ptr %gcs0
  %fxa167 = add i64 %v2, -2
  %fcb167 = inttoptr i64 %fxa167 to ptr
  %fp167 = getelementptr inbounds i8, ptr %fcb167, i64 16
  %fg167 = getelementptr inbounds i64, ptr %fp167, i64 0
  store i64 0, ptr %fg167, align 8
  %fmp167 = getelementptr inbounds i8, ptr %fcb167, i64 8
  %fm167 = load i32, ptr %fmp167, align 4
  %fmc167 = and i32 %fm167, -2
  %fms167 = or i32 %fm167, 1
  store i32 %fms167, ptr %fmp167, align 4
  %fxa168 = add i64 %v2, -2
  %fcb168 = inttoptr i64 %fxa168 to ptr
  %fp168 = getelementptr inbounds i8, ptr %fcb168, i64 16
  %fg168 = getelementptr inbounds i64, ptr %fp168, i64 1
  store i64 0, ptr %fg168, align 8
  %fmp168 = getelementptr inbounds i8, ptr %fcb168, i64 8
  %fm168 = load i32, ptr %fmp168, align 4
  %fmc168 = and i32 %fm168, -3
  %fms168 = or i32 %fm168, 2
  store i32 %fms168, ptr %fmp168, align 4
  %v4 = load i8, ptr %ctx, align 8
  %c0 = zext i8 %v4 to i64
  %v5 = icmp ne i64 %c0, 0
  br i1 %v5, label %b2, label %b1
b1:
  %ta8 = getelementptr inbounds i8, ptr %ctx, i64 96
  %tb8 = load ptr, ptr %ta8, align 8
  %tfa8 = getelementptr inbounds i8, ptr %ctx, i64 104
  %tf8 = load ptr, ptr %tfa8, align 8
  %tnx8 = getelementptr i8, ptr %tb8, i64 32
  %tz8 = icmp ugt ptr %tnx8, %tf8
  %tnp8 = getelementptr inbounds i8, ptr %ctx, i64 56
  %tn8 = load i64, ptr %tnp8, align 8
  %tk8 = icmp ule i64 %tn8, 1024
  %tq8 = or i1 %tz8, %tk8
  %tx8 = call i1 @llvm.expect.i1(i1 %tq8, i1 false)
  br i1 %tx8, label %ao8.lento, label %ao8.reg
ao8.reg:
  %trp8 = getelementptr inbounds i8, ptr %ctx, i64 48
  %tr8 = load ptr, ptr %trp8, align 8
  %trb8 = getelementptr inbounds i8, ptr %tr8, i64 1024
  %trv8 = load i8, ptr %trb8, align 1
  %trz8 = icmp eq i8 %trv8, 0
  %try8 = call i1 @llvm.expect.i1(i1 %trz8, i1 false)
  br i1 %try8, label %ao8.lento, label %ao8.rapido
ao8.rapido:
  store ptr %tnx8, ptr %ta8, align 8
  %tpp8 = getelementptr inbounds i8, ptr %tb8, i64 16
  store i64 0, ptr %tpp8, align 8
  store i64 4398046642177, ptr %tb8, align 8
  %thb8 = ptrtoint ptr %tb8 to i64
  %th8 = add i64 %thb8, 2
  br label %ao8.fim
ao8.lento:
  %tl8 = call i64 @dartforge_object_new_t(i64 1024, i64 2, ptr @df.mt.scalar_nullable_count$2edart.Node)
  br label %ao8.fim
ao8.fim:
  %v8 = phi i64 [ %th8, %ao8.rapido ], [ %tl8, %ao8.lento ]
  store i64 %v8, ptr %gcs1
  %fxa169 = add i64 %v8, -2
  %fcb169 = inttoptr i64 %fxa169 to ptr
  %fp169 = getelementptr inbounds i8, ptr %fcb169, i64 16
  %fg169 = getelementptr inbounds i64, ptr %fp169, i64 0
  store i64 0, ptr %fg169, align 8
  %fmp169 = getelementptr inbounds i8, ptr %fcb169, i64 8
  %fm169 = load i32, ptr %fmp169, align 4
  %fmc169 = and i32 %fm169, -2
  %fms169 = or i32 %fm169, 1
  store i32 %fms169, ptr %fmp169, align 4
  %fxa170 = add i64 %v8, -2
  %fcb170 = inttoptr i64 %fxa170 to ptr
  %fp170 = getelementptr inbounds i8, ptr %fcb170, i64 16
  %fg170 = getelementptr inbounds i64, ptr %fp170, i64 1
  store i64 0, ptr %fg170, align 8
  %fmp170 = getelementptr inbounds i8, ptr %fcb170, i64 8
  %fm170 = load i32, ptr %fmp170, align 4
  %fmc170 = and i32 %fm170, -3
  %fms170 = or i32 %fm170, 2
  store i32 %fms170, ptr %fmp170, align 4
  %v10 = load i8, ptr %ctx, align 8
  %c1 = zext i8 %v10 to i64
  %v11 = icmp ne i64 %c1, 0
  br i1 %v11, label %b4, label %b3
b2:
  %gcvolta2 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta2, ptr %ctxtopo, align 8
  ret void
b3:
  %ta13 = getelementptr inbounds i8, ptr %ctx, i64 96
  %tb13 = load ptr, ptr %ta13, align 8
  %tfa13 = getelementptr inbounds i8, ptr %ctx, i64 104
  %tf13 = load ptr, ptr %tfa13, align 8
  %tnx13 = getelementptr i8, ptr %tb13, i64 32
  %tz13 = icmp ugt ptr %tnx13, %tf13
  %tnp13 = getelementptr inbounds i8, ptr %ctx, i64 56
  %tn13 = load i64, ptr %tnp13, align 8
  %tk13 = icmp ule i64 %tn13, 1024
  %tq13 = or i1 %tz13, %tk13
  %tx13 = call i1 @llvm.expect.i1(i1 %tq13, i1 false)
  br i1 %tx13, label %ao13.lento, label %ao13.reg
ao13.reg:
  %trp13 = getelementptr inbounds i8, ptr %ctx, i64 48
  %tr13 = load ptr, ptr %trp13, align 8
  %trb13 = getelementptr inbounds i8, ptr %tr13, i64 1024
  %trv13 = load i8, ptr %trb13, align 1
  %trz13 = icmp eq i8 %trv13, 0
  %try13 = call i1 @llvm.expect.i1(i1 %trz13, i1 false)
  br i1 %try13, label %ao13.lento, label %ao13.rapido
ao13.rapido:
  store ptr %tnx13, ptr %ta13, align 8
  %tpp13 = getelementptr inbounds i8, ptr %tb13, i64 16
  store i64 0, ptr %tpp13, align 8
  store i64 4398046642177, ptr %tb13, align 8
  %thb13 = ptrtoint ptr %tb13 to i64
  %th13 = add i64 %thb13, 2
  br label %ao13.fim
ao13.lento:
  %tl13 = call i64 @dartforge_object_new_t(i64 1024, i64 2, ptr @df.mt.scalar_nullable_count$2edart.Node)
  br label %ao13.fim
ao13.fim:
  %v13 = phi i64 [ %th13, %ao13.rapido ], [ %tl13, %ao13.lento ]
  store i64 %v13, ptr %gcs2
  %fxa171 = add i64 %v13, -2
  %fcb171 = inttoptr i64 %fxa171 to ptr
  %fp171 = getelementptr inbounds i8, ptr %fcb171, i64 16
  %fg171 = getelementptr inbounds i64, ptr %fp171, i64 0
  store i64 %v8, ptr %fg171, align 8
  %fmp171 = getelementptr inbounds i8, ptr %fcb171, i64 8
  %fm171 = load i32, ptr %fmp171, align 4
  %fmc171 = and i32 %fm171, -2
  %fms171 = or i32 %fm171, 1
  store i32 %fms171, ptr %fmp171, align 4
  br label %wb171.fim
wb171.fim:
  %fxa172 = add i64 %v13, -2
  %fcb172 = inttoptr i64 %fxa172 to ptr
  %fp172 = getelementptr inbounds i8, ptr %fcb172, i64 16
  %fg172 = getelementptr inbounds i64, ptr %fp172, i64 1
  store i64 0, ptr %fg172, align 8
  %fmp172 = getelementptr inbounds i8, ptr %fcb172, i64 8
  %fm172 = load i32, ptr %fmp172, align 4
  %fmc172 = and i32 %fm172, -3
  %fms172 = or i32 %fm172, 2
  store i32 %fms172, ptr %fmp172, align 4
  %v15 = load i8, ptr %ctx, align 8
  %c2 = zext i8 %v15 to i64
  %v16 = icmp ne i64 %c2, 0
  br i1 %v16, label %b6, label %b5
b4:
  %gcvolta4 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta4, ptr %ctxtopo, align 8
  ret void
b5:
  store i64 0, ptr %gcs1
  %ta17 = getelementptr inbounds i8, ptr %ctx, i64 96
  %tb17 = load ptr, ptr %ta17, align 8
  %tfa17 = getelementptr inbounds i8, ptr %ctx, i64 104
  %tf17 = load ptr, ptr %tfa17, align 8
  %tnx17 = getelementptr i8, ptr %tb17, i64 32
  %tz17 = icmp ugt ptr %tnx17, %tf17
  %tnp17 = getelementptr inbounds i8, ptr %ctx, i64 56
  %tn17 = load i64, ptr %tnp17, align 8
  %tk17 = icmp ule i64 %tn17, 1024
  %tq17 = or i1 %tz17, %tk17
  %tx17 = call i1 @llvm.expect.i1(i1 %tq17, i1 false)
  br i1 %tx17, label %ao17.lento, label %ao17.reg
ao17.reg:
  %trp17 = getelementptr inbounds i8, ptr %ctx, i64 48
  %tr17 = load ptr, ptr %trp17, align 8
  %trb17 = getelementptr inbounds i8, ptr %tr17, i64 1024
  %trv17 = load i8, ptr %trb17, align 1
  %trz17 = icmp eq i8 %trv17, 0
  %try17 = call i1 @llvm.expect.i1(i1 %trz17, i1 false)
  br i1 %try17, label %ao17.lento, label %ao17.rapido
ao17.rapido:
  store ptr %tnx17, ptr %ta17, align 8
  %tpp17 = getelementptr inbounds i8, ptr %tb17, i64 16
  store i64 0, ptr %tpp17, align 8
  store i64 4398046642177, ptr %tb17, align 8
  %thb17 = ptrtoint ptr %tb17 to i64
  %th17 = add i64 %thb17, 2
  br label %ao17.fim
ao17.lento:
  %tl17 = call i64 @dartforge_object_new_t(i64 1024, i64 2, ptr @df.mt.scalar_nullable_count$2edart.Node)
  br label %ao17.fim
ao17.fim:
  %v17 = phi i64 [ %th17, %ao17.rapido ], [ %tl17, %ao17.lento ]
  store i64 %v17, ptr %gcs1
  %fxa173 = add i64 %v17, -2
  %fcb173 = inttoptr i64 %fxa173 to ptr
  %fp173 = getelementptr inbounds i8, ptr %fcb173, i64 16
  %fg173 = getelementptr inbounds i64, ptr %fp173, i64 0
  store i64 %v2, ptr %fg173, align 8
  %fmp173 = getelementptr inbounds i8, ptr %fcb173, i64 8
  %fm173 = load i32, ptr %fmp173, align 4
  %fmc173 = and i32 %fm173, -2
  %fms173 = or i32 %fm173, 1
  store i32 %fms173, ptr %fmp173, align 4
  br label %wb173.fim
wb173.fim:
  %fxa174 = add i64 %v17, -2
  %fcb174 = inttoptr i64 %fxa174 to ptr
  %fp174 = getelementptr inbounds i8, ptr %fcb174, i64 16
  %fg174 = getelementptr inbounds i64, ptr %fp174, i64 1
  store i64 %v13, ptr %fg174, align 8
  %fmp174 = getelementptr inbounds i8, ptr %fcb174, i64 8
  %fm174 = load i32, ptr %fmp174, align 4
  %fmc174 = and i32 %fm174, -3
  %fms174 = or i32 %fm174, 2
  store i32 %fms174, ptr %fmp174, align 4
  br label %wb174.fim
wb174.fim:
  %v19 = load i8, ptr %ctx, align 8
  %c3 = zext i8 %v19 to i64
  %v20 = icmp ne i64 %c3, 0
  br i1 %v20, label %b8, label %b7
b6:
  %gcvolta6 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta6, ptr %ctxtopo, align 8
  ret void
b7:
  store i64 0, ptr %gcs0
  store i64 0, ptr %gcs2
  %v21 = call i64 @df.scalar_nullable_count$2edart.Node.count(i64 %v17)
  %v22 = load i8, ptr %ctx, align 8
  %c4 = zext i8 %v22 to i64
  %v23 = icmp ne i64 %c4, 0
  br i1 %v23, label %b10, label %b9
b8:
  %gcvolta8 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta8, ptr %ctxtopo, align 8
  ret void
b9:
  store i64 0, ptr %gcs1
  %v24 = call i64 @df.box_int(i64 %v21)
  store i64 %v24, ptr %gcs0
  call void @df.dart$3acore..print(i64 %v24)
  %v26 = load i8, ptr %ctx, align 8
  %c5 = zext i8 %v26 to i64
  %v27 = icmp ne i64 %c5, 0
  br i1 %v27, label %b12, label %b11
b10:
  %gcvolta10 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta10, ptr %ctxtopo, align 8
  ret void
b11:
  %v28 = add i64 0, 0
  %v29 = add i64 0, 1
  %v30 = sub i64 0, %v29
  %v31 = add i64 0, 4611686018427387904
  %v32 = add i64 0, -9223372036854775808
  %v33 = sub i64 0, %v32
  %v34 = add i64 0, 9223372036854775807
  store i64 0, ptr %gcs0
  %lp35_0 = getelementptr [5 x i64], ptr %list_buf_35, i64 0, i64 0
  store i64 %v28, ptr %lp35_0, align 8
  %lp35_1 = getelementptr [5 x i64], ptr %list_buf_35, i64 0, i64 1
  store i64 %v30, ptr %lp35_1, align 8
  %lp35_2 = getelementptr [5 x i64], ptr %list_buf_35, i64 0, i64 2
  store i64 %v31, ptr %lp35_2, align 8
  %lp35_3 = getelementptr [5 x i64], ptr %list_buf_35, i64 0, i64 3
  store i64 %v33, ptr %lp35_3, align 8
  %lp35_4 = getelementptr [5 x i64], ptr %list_buf_35, i64 0, i64 4
  store i64 %v34, ptr %lp35_4, align 8
  %v35 = call i64 @dartforge_list_new(ptr %list_buf_35, i64 5, i64 10, i64 1)
  store i64 %v35, ptr %gcs0
  %ga36 = getelementptr i64, ptr %area, i64 1
  %v36 = load i8, ptr %ga36
  %c6 = zext i8 %v36 to i64
  %v37 = icmp ne i64 %c6, 0
  br i1 %v37, label %b13, label %b14
b12:
  %gcvolta12 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta12, ptr %ctxtopo, align 8
  ret void
b13:
  %ga38 = getelementptr i64, ptr %area, i64 0
  %v38 = load i64, ptr %ga38
  br label %b15
b14:
  %v39 = call i64 @df.rti.3826facde6a2fcb1.scalar_nullable_count$2edart()
  br label %b15
b15:
  %v40 = phi i64 [ %v38, %b13 ], [ %v39, %b14 ]
  call void @dartforge_effects_before(ptr @df.efn.0, i64 17, i64 2)
  call void @dartforge_rti_set(i64 %v35, i64 %v40)
  call void @dartforge_effects_after()
  %v42 = call i64 @df.class(i64 %v35)
  %v43 = sub i64 %v42, 8
  %v44 = icmp ult i64 %v43, 3
  br i1 %v44, label %b16, label %b17
b16:
  %v45 = call i64 @df.list_len(i64 %v35)
  br label %b19
b17:
  %sat97 = getelementptr [1 x i64], ptr %sargs97, i64 0, i64 0
  store i64 0, ptr %sat97
  %sic97 = getelementptr i64, ptr %area, i64 4
  ; df.selector-exact 10
  %sf97 = call ptr @df.selector(ptr %sic97, i64 %v35, i64 -5476269667379286226, ptr @df.seln.0, i64 10)
  %v97 = call i64 %sf97(i64 %v35, ptr %sargs97, ptr @df.const.i64.2.c314eb35009b14025e5ef5c352349ffcb0ff36f19602db3b02250d0153c9f892)
  store i64 %v97, ptr %gcs0
  %v98 = load i8, ptr %ctx, align 8
  %c7 = zext i8 %v98 to i64
  %v99 = icmp ne i64 %c7, 0
  br i1 %v99, label %b48, label %b47
b18:
  %v182 = add i64 0, 7
  %v183 = sub i64 0, %v182
  %v134 = load i8, ptr %ctx, align 8
  %c8 = zext i8 %v134 to i64
  %v135 = icmp ne i64 %c8, 0
  br i1 %v135, label %b71, label %b70
b19:
  %v166 = phi i64 [ 0, %b16 ], [ %v80, %b45 ]
  %v48 = call i64 @df.list_len(i64 %v35)
  %v49 = icmp eq i64 %v48, %v45
  br i1 %v49, label %b21, label %b20
b20:
  store i64 0, ptr %gcs1
  %ta50 = getelementptr inbounds i8, ptr %ctx, i64 96
  %tb50 = load ptr, ptr %ta50, align 8
  %tfa50 = getelementptr inbounds i8, ptr %ctx, i64 104
  %tf50 = load ptr, ptr %tfa50, align 8
  %tnx50 = getelementptr i8, ptr %tb50, i64 32
  %tz50 = icmp ugt ptr %tnx50, %tf50
  %tnp50 = getelementptr inbounds i8, ptr %ctx, i64 56
  %tn50 = load i64, ptr %tnp50, align 8
  %tk50 = icmp ule i64 %tn50, 581
  %tq50 = or i1 %tz50, %tk50
  %tx50 = call i1 @llvm.expect.i1(i1 %tq50, i1 false)
  br i1 %tx50, label %ao50.lento, label %ao50.reg
ao50.reg:
  %trp50 = getelementptr inbounds i8, ptr %ctx, i64 48
  %tr50 = load ptr, ptr %trp50, align 8
  %trb50 = getelementptr inbounds i8, ptr %tr50, i64 581
  %trv50 = load i8, ptr %trb50, align 1
  %trz50 = icmp eq i8 %trv50, 0
  %try50 = call i1 @llvm.expect.i1(i1 %trz50, i1 false)
  br i1 %try50, label %ao50.lento, label %ao50.rapido
ao50.rapido:
  store ptr %tnx50, ptr %ta50, align 8
  %tpp50 = getelementptr inbounds i8, ptr %tb50, i64 16
  store i64 0, ptr %tpp50, align 8
  store i64 2495376130049, ptr %tb50, align 8
  %thb50 = ptrtoint ptr %tb50 to i64
  %th50 = add i64 %thb50, 2
  br label %ao50.fim
ao50.lento:
  %tl50 = call i64 @dartforge_object_new_t(i64 581, i64 2, ptr @df.mt.dart$3acore.ConcurrentModificationError)
  br label %ao50.fim
ao50.fim:
  %v50 = phi i64 [ %th50, %ao50.rapido ], [ %tl50, %ao50.lento ]
  store i64 %v50, ptr %gcs1
  call void @df.dart$3acore.ConcurrentModificationError.new(i64 %v50, i64 %v35)
  %v52 = load i8, ptr %ctx, align 8
  %c9 = zext i8 %v52 to i64
  %v53 = icmp ne i64 %c9, 0
  br i1 %v53, label %b24, label %b23
b21:
  %v56 = icmp slt i64 %v166, %v48
  br i1 %v56, label %b22, label %b18
b22:
  %ip57 = getelementptr inbounds i8, ptr %ctx, i64 32
  %iv57 = load atomic i8, ptr %ip57 monotonic, align 8
  %v57 = call i8 @llvm.expect.i8(i8 %iv57, i8 0)
  %c10 = zext i8 %v57 to i64
  %v58 = icmp ne i64 %c10, 0
  br i1 %v58, label %b26, label %b27
b23:
  store i64 0, ptr %gcs0
  call void @dartforge_exception_throw(i64 %v50, i8 3)
  %gcvolta23 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta23, ptr %ctxtopo, align 8
  ret void
b24:
  %gcvolta24 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta24, ptr %ctxtopo, align 8
  ret void
b26:
  store i64 0, ptr %gcs1
  call void @dartforge_safepoint()
  %v60 = load i8, ptr %ctx, align 8
  %c11 = zext i8 %v60 to i64
  %v61 = icmp ne i64 %c11, 0
  br i1 %v61, label %b29, label %b28
b27:
  %v62 = call i64 @df.core_storage(i64 %v35)
  %v63 = call i64 @df.core_shape(i64 %v62)
  %v64 = add i64 %v62, 22
  %v65 = icmp eq i64 %v63, 34
  br i1 %v65, label %b31, label %b32
b28:
  br label %b27
b29:
  %gcvolta29 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta29, ptr %ctxtopo, align 8
  ret void
b30:
  %v79 = phi i64 [ %v66, %b31 ], [ %v69, %b35 ], [ %v76, %b39 ]
  %v80 = add i64 %v166, 1
  store i64 0, ptr %gcs1
  %ta86 = getelementptr inbounds i8, ptr %ctx, i64 96
  %tb86 = load ptr, ptr %ta86, align 8
  %tfa86 = getelementptr inbounds i8, ptr %ctx, i64 104
  %tf86 = load ptr, ptr %tfa86, align 8
  %tnx86 = getelementptr i8, ptr %tb86, i64 32
  %tz86 = icmp ugt ptr %tnx86, %tf86
  %tnp86 = getelementptr inbounds i8, ptr %ctx, i64 56
  %tn86 = load i64, ptr %tnp86, align 8
  %tk86 = icmp ule i64 %tn86, 1025
  %tq86 = or i1 %tz86, %tk86
  %tx86 = call i1 @llvm.expect.i1(i1 %tq86, i1 false)
  br i1 %tx86, label %ao86.lento, label %ao86.reg
ao86.reg:
  %trp86 = getelementptr inbounds i8, ptr %ctx, i64 48
  %tr86 = load ptr, ptr %trp86, align 8
  %trb86 = getelementptr inbounds i8, ptr %tr86, i64 1025
  %trv86 = load i8, ptr %trb86, align 1
  %trz86 = icmp eq i8 %trv86, 0
  %try86 = call i1 @llvm.expect.i1(i1 %trz86, i1 false)
  br i1 %try86, label %ao86.lento, label %ao86.rapido
ao86.rapido:
  store ptr %tnx86, ptr %ta86, align 8
  %tpp86 = getelementptr inbounds i8, ptr %tb86, i64 16
  store i64 0, ptr %tpp86, align 8
  store i64 4402341609473, ptr %tb86, align 8
  %thb86 = ptrtoint ptr %tb86 to i64
  %th86 = add i64 %thb86, 2
  br label %ao86.fim
ao86.lento:
  %tl86 = call i64 @dartforge_object_new_t(i64 1025, i64 2, ptr @df.mt.scalar_nullable_count$2edart.NumberSource)
  br label %ao86.fim
ao86.fim:
  %v86 = phi i64 [ %th86, %ao86.rapido ], [ %tl86, %ao86.lento ]
  store i64 %v86, ptr %gcs1
  %fxa200 = add i64 %v86, -2
  %fcb200 = inttoptr i64 %fxa200 to ptr
  %fp200 = getelementptr inbounds i8, ptr %fcb200, i64 16
  %fg200 = getelementptr inbounds i64, ptr %fp200, i64 0
  store i64 %v79, ptr %fg200, align 8
  %fmp200 = getelementptr inbounds i8, ptr %fcb200, i64 8
  %fm200 = load i32, ptr %fmp200, align 4
  %fmc200 = and i32 %fm200, -2
  store i32 %fmc200, ptr %fmp200, align 4
  %fxa202 = add i64 %v86, -2
  %fcb202 = inttoptr i64 %fxa202 to ptr
  %fp202 = getelementptr inbounds i8, ptr %fcb202, i64 16
  %fg202 = getelementptr inbounds i64, ptr %fp202, i64 1
  store i64 0, ptr %fg202, align 8
  %fmp202 = getelementptr inbounds i8, ptr %fcb202, i64 8
  %fm202 = load i32, ptr %fmp202, align 4
  %fmc202 = and i32 %fm202, -3
  store i32 %fmc202, ptr %fmp202, align 4
  %v88 = load i8, ptr %ctx, align 8
  %c12 = zext i8 %v88 to i64
  %v89 = icmp ne i64 %c12, 0
  br i1 %v89, label %b42, label %b41
b31:
  %cp66 = inttoptr i64 %v64 to ptr
  %cg66 = getelementptr i64, ptr %cp66, i64 %v166
  %v66 = load i64, ptr %cg66, align 1
  br label %b30
b32:
  %v67 = icmp eq i64 %v63, 4
  br i1 %v67, label %b33, label %b34
b33:
  %v68 = call i64 @df.word_ref(i64 %v64, i64 %v166)
  store i64 %v68, ptr %gcs1
  %v69 = call i64 @df.unbox_int(i64 %v68)
  %v70 = load i8, ptr %ctx, align 8
  %c13 = zext i8 %v70 to i64
  %v71 = icmp ne i64 %c13, 0
  br i1 %v71, label %b36, label %b35
b34:
  store i64 0, ptr %gcs1
  %v72 = call i64 @df.box_int(i64 %v166)
  store i64 %v72, ptr %gcs1
  %sa73_0 = getelementptr [2 x i64], ptr %sargs73, i64 0, i64 0
  store i64 %v72, ptr %sa73_0
  %sat73 = getelementptr [2 x i64], ptr %sargs73, i64 0, i64 1
  store i64 0, ptr %sat73
  %sic73 = getelementptr i64, ptr %area, i64 6
  ; df.selector-exact 10
  %sf73 = call ptr @df.selector(ptr %sic73, i64 %v35, i64 2870274114568068918, ptr @df.seln.1, i64 5)
  %v73 = call i64 %sf73(i64 %v35, ptr %sargs73, ptr @df.const.i64.2.5add879d03074d0745fe088492026a7fe5e24eae5505fb5feeaa2dea820028da)
  store i64 %v73, ptr %gcs1
  %v74 = load i8, ptr %ctx, align 8
  %c14 = zext i8 %v74 to i64
  %v75 = icmp ne i64 %c14, 0
  br i1 %v75, label %b38, label %b37
b35:
  br label %b30
b36:
  %gcvolta36 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta36, ptr %ctxtopo, align 8
  ret void
b37:
  %v76 = call i64 @df.unbox_int(i64 %v73)
  %v77 = load i8, ptr %ctx, align 8
  %c15 = zext i8 %v77 to i64
  %v78 = icmp ne i64 %c15, 0
  br i1 %v78, label %b40, label %b39
b38:
  %gcvolta38 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta38, ptr %ctxtopo, align 8
  ret void
b39:
  br label %b30
b40:
  %gcvolta40 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta40, ptr %ctxtopo, align 8
  ret void
b41:
  %v203 = icmp eq i64 %v86, 0
  br i1 %v203, label %b115, label %b116
b115:
  %v204 = phi i64 [ 0, %b41 ], [ %v209, %b117 ]
  store i64 %v204, ptr %gcs1
  %v205 = icmp eq i64 %v204, 0
  br i1 %v205, label %b119, label %b120
b116:
  %fxk217 = and i64 %v86, -9223372036854775801
  %fxo217 = icmp eq i64 %fxk217, 2
  %fxa217 = add i64 %v86, -2
  %fxq217 = inttoptr i64 %fxa217 to ptr
  %fxvp217 = getelementptr inbounds i8, ptr %ctx, i64 40
  %fxv217 = load ptr, ptr %fxvp217, align 8
  %fxh217 = select i1 %fxo217, ptr %fxq217, ptr %fxv217
  %fxfp217 = getelementptr inbounds i8, ptr %fxh217, i64 1
  %fxf217 = load i8, ptr %fxfp217, align 1
  %fxfb217 = and i8 %fxf217, 1
  %fxfo217 = icmp ne i8 %fxfb217, 0
  %fxcp217 = getelementptr inbounds i8, ptr %fxh217, i64 16
  %fxc217 = load ptr, ptr %fxcp217, align 8
  %fcb217 = select i1 %fxfo217, ptr %fxc217, ptr %fxh217
  %fp217 = getelementptr inbounds i8, ptr %fcb217, i64 16
  %fg217 = getelementptr inbounds i64, ptr %fp217, i64 1
  %v217 = load i64, ptr %fg217, align 8
  %v218 = icmp ne i64 %v217, 0
  br i1 %v218, label %b126, label %b127
b126:
  %v219 = ptrtoint ptr getelementptr inbounds (i8, ptr @"df.s.9e342f55d946ea1f6cdc7c8dec0e9944", i64 2) to i64
  store i64 %v219, ptr %gcs1
  %ta220 = getelementptr inbounds i8, ptr %ctx, i64 96
  %tb220 = load ptr, ptr %ta220, align 8
  %tfa220 = getelementptr inbounds i8, ptr %ctx, i64 104
  %tf220 = load ptr, ptr %tfa220, align 8
  %tnx220 = getelementptr i8, ptr %tb220, i64 32
  %tz220 = icmp ugt ptr %tnx220, %tf220
  %tnp220 = getelementptr inbounds i8, ptr %ctx, i64 56
  %tn220 = load i64, ptr %tnp220, align 8
  %tk220 = icmp ule i64 %tn220, 615
  %tq220 = or i1 %tz220, %tk220
  %tx220 = call i1 @llvm.expect.i1(i1 %tq220, i1 false)
  br i1 %tx220, label %ao220.lento, label %ao220.reg
ao220.reg:
  %trp220 = getelementptr inbounds i8, ptr %ctx, i64 48
  %tr220 = load ptr, ptr %trp220, align 8
  %trb220 = getelementptr inbounds i8, ptr %tr220, i64 615
  %trv220 = load i8, ptr %trb220, align 1
  %trz220 = icmp eq i8 %trv220, 0
  %try220 = call i1 @llvm.expect.i1(i1 %trz220, i1 false)
  br i1 %try220, label %ao220.lento, label %ao220.rapido
ao220.rapido:
  store ptr %tnx220, ptr %ta220, align 8
  %tpp220 = getelementptr inbounds i8, ptr %tb220, i64 16
  store i64 0, ptr %tpp220, align 8
  store i64 2641405018113, ptr %tb220, align 8
  %thb220 = ptrtoint ptr %tb220 to i64
  %th220 = add i64 %thb220, 2
  br label %ao220.fim
ao220.lento:
  %tl220 = call i64 @dartforge_object_new_t(i64 615, i64 2, ptr @df.mt.dart$3acore.StateError)
  br label %ao220.fim
ao220.fim:
  %v220 = phi i64 [ %th220, %ao220.rapido ], [ %tl220, %ao220.lento ]
  store i64 %v220, ptr %gcs2
  call void @df.dart$3acore.StateError.new(i64 %v220, i64 %v219)
  %v222 = load i8, ptr %ctx, align 8
  %c16 = zext i8 %v222 to i64
  %v223 = icmp ne i64 %c16, 0
  br i1 %v223, label %b129, label %b128
b127:
  %fxk224 = and i64 %v86, -9223372036854775801
  %fxo224 = icmp eq i64 %fxk224, 2
  %fxa224 = add i64 %v86, -2
  %fxq224 = inttoptr i64 %fxa224 to ptr
  %fxvp224 = getelementptr inbounds i8, ptr %ctx, i64 40
  %fxv224 = load ptr, ptr %fxvp224, align 8
  %fxh224 = select i1 %fxo224, ptr %fxq224, ptr %fxv224
  %fxfp224 = getelementptr inbounds i8, ptr %fxh224, i64 1
  %fxf224 = load i8, ptr %fxfp224, align 1
  %fxfb224 = and i8 %fxf224, 1
  %fxfo224 = icmp ne i8 %fxfb224, 0
  %fxcp224 = getelementptr inbounds i8, ptr %fxh224, i64 16
  %fxc224 = load ptr, ptr %fxcp224, align 8
  %fcb224 = select i1 %fxfo224, ptr %fxc224, ptr %fxh224
  %fp224 = getelementptr inbounds i8, ptr %fcb224, i64 16
  %fg224 = getelementptr inbounds i64, ptr %fp224, i64 0
  %v224 = load i64, ptr %fg224, align 8
  %xcp225 = load i8, ptr %ctx, align 8
  %xcn225 = icmp ne i8 %xcp225, 0
  %xce225 = call i1 @llvm.expect.i1(i1 %xcn225, i1 false)
  br i1 %xce225, label %xc225.limpar, label %xc225.fim
xc225.limpar:
  call void @dartforge_exception_clear()
  br label %xc225.fim
xc225.fim:
  br label %b130
b128:
  store i64 0, ptr %gcs1
  call void @dartforge_exception_throw(i64 %v220, i8 3)
  br label %b130
b129:
  br label %b130
b130:
  %v227 = phi i64 [ %v224, %xc225.fim ], [ 0, %b128 ], [ 0, %b129 ]
  %v207 = load i8, ptr %ctx, align 8
  %c17 = zext i8 %v207 to i64
  %v208 = icmp ne i64 %c17, 0
  br i1 %v208, label %b118, label %b117
b117:
  store i64 0, ptr %gcs1
  store i64 0, ptr %gcs2
  %v209 = call i64 @df.box_int(i64 %v227)
  br label %b115
b118:
  br label %b124
b119:
  %v210 = add i64 0, 7
  %v211 = sub i64 0, %v210
  br label %b121
b120:
  %v212 = call i64 @df.unbox_int(i64 %v204)
  %v213 = load i8, ptr %ctx, align 8
  %c18 = zext i8 %v213 to i64
  %v214 = icmp ne i64 %c18, 0
  br i1 %v214, label %b123, label %b122
b121:
  %v215 = phi i64 [ %v212, %b122 ], [ %v211, %b119 ]
  br label %b124
b122:
  br label %b121
b123:
  br label %b124
b124:
  %v216 = phi i64 [ 0, %b118 ], [ %v215, %b121 ], [ 0, %b123 ]
  %v91 = load i8, ptr %ctx, align 8
  %c19 = zext i8 %v91 to i64
  %v92 = icmp ne i64 %c19, 0
  br i1 %v92, label %b44, label %b43
b42:
  %gcvolta42 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta42, ptr %ctxtopo, align 8
  ret void
b43:
  store i64 0, ptr %gcs1
  store i64 0, ptr %gcs2
  %v93 = call i64 @df.box_int(i64 %v216)
  store i64 %v93, ptr %gcs1
  call void @df.dart$3acore..print(i64 %v93)
  %v95 = load i8, ptr %ctx, align 8
  %c20 = zext i8 %v95 to i64
  %v96 = icmp ne i64 %c20, 0
  br i1 %v96, label %b46, label %b45
b44:
  %gcvolta44 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta44, ptr %ctxtopo, align 8
  ret void
b45:
  br label %b19
b46:
  %gcvolta46 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta46, ptr %ctxtopo, align 8
  ret void
b47:
  br label %b49
b48:
  %gcvolta48 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta48, ptr %ctxtopo, align 8
  ret void
b49:
  store i64 0, ptr %gcs1
  %sat100 = getelementptr [1 x i64], ptr %sargs100, i64 0, i64 0
  store i64 0, ptr %sat100
  %sic100 = getelementptr i64, ptr %area, i64 8
  %sf100 = call ptr @df.selector(ptr %sic100, i64 %v97, i64 -5038376148439920376, ptr @df.seln.2, i64 10)
  %v100 = call i64 %sf100(i64 %v97, ptr %sargs100, ptr @df.const.i64.2.c314eb35009b14025e5ef5c352349ffcb0ff36f19602db3b02250d0153c9f892)
  store i64 %v100, ptr %gcs1
  %v101 = load i8, ptr %ctx, align 8
  %c21 = zext i8 %v101 to i64
  %v102 = icmp ne i64 %c21, 0
  br i1 %v102, label %b53, label %b52
b50:
  %ip106 = getelementptr inbounds i8, ptr %ctx, i64 32
  %iv106 = load atomic i8, ptr %ip106 monotonic, align 8
  %v106 = call i8 @llvm.expect.i8(i8 %iv106, i8 0)
  %c22 = zext i8 %v106 to i64
  %v107 = icmp ne i64 %c22, 0
  br i1 %v107, label %b56, label %b57
b51:
  br label %b18
b52:
  %v103 = call i1 @df.unbox_bool(i64 %v100)
  %v104 = load i8, ptr %ctx, align 8
  %c23 = zext i8 %v104 to i64
  %v105 = icmp ne i64 %c23, 0
  br i1 %v105, label %b55, label %b54
b53:
  %gcvolta53 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta53, ptr %ctxtopo, align 8
  ret void
b54:
  br i1 %v103, label %b50, label %b51
b55:
  %gcvolta55 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta55, ptr %ctxtopo, align 8
  ret void
b56:
  store i64 0, ptr %gcs1
  call void @dartforge_safepoint()
  %v109 = load i8, ptr %ctx, align 8
  %c24 = zext i8 %v109 to i64
  %v110 = icmp ne i64 %c24, 0
  br i1 %v110, label %b59, label %b58
b57:
  store i64 0, ptr %gcs1
  %sat111 = getelementptr [1 x i64], ptr %sargs111, i64 0, i64 0
  store i64 0, ptr %sat111
  %sic111 = getelementptr i64, ptr %area, i64 10
  %sf111 = call ptr @df.selector(ptr %sic111, i64 %v97, i64 1052728634250411761, ptr @df.seln.3, i64 9)
  %v111 = call i64 %sf111(i64 %v97, ptr %sargs111, ptr @df.const.i64.2.c314eb35009b14025e5ef5c352349ffcb0ff36f19602db3b02250d0153c9f892)
  store i64 %v111, ptr %gcs1
  %v112 = load i8, ptr %ctx, align 8
  %c25 = zext i8 %v112 to i64
  %v113 = icmp ne i64 %c25, 0
  br i1 %v113, label %b61, label %b60
b58:
  br label %b57
b59:
  %gcvolta59 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta59, ptr %ctxtopo, align 8
  ret void
b60:
  %v114 = call i64 @df.unbox_int(i64 %v111)
  %v115 = load i8, ptr %ctx, align 8
  %c26 = zext i8 %v115 to i64
  %v116 = icmp ne i64 %c26, 0
  br i1 %v116, label %b63, label %b62
b61:
  %gcvolta61 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta61, ptr %ctxtopo, align 8
  ret void
b62:
  store i64 0, ptr %gcs1
  %ta121 = getelementptr inbounds i8, ptr %ctx, i64 96
  %tb121 = load ptr, ptr %ta121, align 8
  %tfa121 = getelementptr inbounds i8, ptr %ctx, i64 104
  %tf121 = load ptr, ptr %tfa121, align 8
  %tnx121 = getelementptr i8, ptr %tb121, i64 32
  %tz121 = icmp ugt ptr %tnx121, %tf121
  %tnp121 = getelementptr inbounds i8, ptr %ctx, i64 56
  %tn121 = load i64, ptr %tnp121, align 8
  %tk121 = icmp ule i64 %tn121, 1025
  %tq121 = or i1 %tz121, %tk121
  %tx121 = call i1 @llvm.expect.i1(i1 %tq121, i1 false)
  br i1 %tx121, label %ao121.lento, label %ao121.reg
ao121.reg:
  %trp121 = getelementptr inbounds i8, ptr %ctx, i64 48
  %tr121 = load ptr, ptr %trp121, align 8
  %trb121 = getelementptr inbounds i8, ptr %tr121, i64 1025
  %trv121 = load i8, ptr %trb121, align 1
  %trz121 = icmp eq i8 %trv121, 0
  %try121 = call i1 @llvm.expect.i1(i1 %trz121, i1 false)
  br i1 %try121, label %ao121.lento, label %ao121.rapido
ao121.rapido:
  store ptr %tnx121, ptr %ta121, align 8
  %tpp121 = getelementptr inbounds i8, ptr %tb121, i64 16
  store i64 0, ptr %tpp121, align 8
  store i64 4402341609473, ptr %tb121, align 8
  %thb121 = ptrtoint ptr %tb121 to i64
  %th121 = add i64 %thb121, 2
  br label %ao121.fim
ao121.lento:
  %tl121 = call i64 @dartforge_object_new_t(i64 1025, i64 2, ptr @df.mt.scalar_nullable_count$2edart.NumberSource)
  br label %ao121.fim
ao121.fim:
  %v121 = phi i64 [ %th121, %ao121.rapido ], [ %tl121, %ao121.lento ]
  store i64 %v121, ptr %gcs1
  %fxa228 = add i64 %v121, -2
  %fcb228 = inttoptr i64 %fxa228 to ptr
  %fp228 = getelementptr inbounds i8, ptr %fcb228, i64 16
  %fg228 = getelementptr inbounds i64, ptr %fp228, i64 0
  store i64 %v114, ptr %fg228, align 8
  %fmp228 = getelementptr inbounds i8, ptr %fcb228, i64 8
  %fm228 = load i32, ptr %fmp228, align 4
  %fmc228 = and i32 %fm228, -2
  store i32 %fmc228, ptr %fmp228, align 4
  %fxa230 = add i64 %v121, -2
  %fcb230 = inttoptr i64 %fxa230 to ptr
  %fp230 = getelementptr inbounds i8, ptr %fcb230, i64 16
  %fg230 = getelementptr inbounds i64, ptr %fp230, i64 1
  store i64 0, ptr %fg230, align 8
  %fmp230 = getelementptr inbounds i8, ptr %fcb230, i64 8
  %fm230 = load i32, ptr %fmp230, align 4
  %fmc230 = and i32 %fm230, -3
  store i32 %fmc230, ptr %fmp230, align 4
  %v123 = load i8, ptr %ctx, align 8
  %c27 = zext i8 %v123 to i64
  %v124 = icmp ne i64 %c27, 0
  br i1 %v124, label %b65, label %b64
b63:
  %gcvolta63 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta63, ptr %ctxtopo, align 8
  ret void
b64:
  %v231 = icmp eq i64 %v121, 0
  br i1 %v231, label %b134, label %b135
b134:
  %v232 = phi i64 [ 0, %b64 ], [ %v237, %b136 ]
  store i64 %v232, ptr %gcs1
  %v233 = icmp eq i64 %v232, 0
  br i1 %v233, label %b138, label %b139
b135:
  %fxk245 = and i64 %v121, -9223372036854775801
  %fxo245 = icmp eq i64 %fxk245, 2
  %fxa245 = add i64 %v121, -2
  %fxq245 = inttoptr i64 %fxa245 to ptr
  %fxvp245 = getelementptr inbounds i8, ptr %ctx, i64 40
  %fxv245 = load ptr, ptr %fxvp245, align 8
  %fxh245 = select i1 %fxo245, ptr %fxq245, ptr %fxv245
  %fxfp245 = getelementptr inbounds i8, ptr %fxh245, i64 1
  %fxf245 = load i8, ptr %fxfp245, align 1
  %fxfb245 = and i8 %fxf245, 1
  %fxfo245 = icmp ne i8 %fxfb245, 0
  %fxcp245 = getelementptr inbounds i8, ptr %fxh245, i64 16
  %fxc245 = load ptr, ptr %fxcp245, align 8
  %fcb245 = select i1 %fxfo245, ptr %fxc245, ptr %fxh245
  %fp245 = getelementptr inbounds i8, ptr %fcb245, i64 16
  %fg245 = getelementptr inbounds i64, ptr %fp245, i64 1
  %v245 = load i64, ptr %fg245, align 8
  %v246 = icmp ne i64 %v245, 0
  br i1 %v246, label %b145, label %b146
b145:
  %v247 = ptrtoint ptr getelementptr inbounds (i8, ptr @"df.s.9e342f55d946ea1f6cdc7c8dec0e9944", i64 2) to i64
  store i64 %v247, ptr %gcs1
  %ta248 = getelementptr inbounds i8, ptr %ctx, i64 96
  %tb248 = load ptr, ptr %ta248, align 8
  %tfa248 = getelementptr inbounds i8, ptr %ctx, i64 104
  %tf248 = load ptr, ptr %tfa248, align 8
  %tnx248 = getelementptr i8, ptr %tb248, i64 32
  %tz248 = icmp ugt ptr %tnx248, %tf248
  %tnp248 = getelementptr inbounds i8, ptr %ctx, i64 56
  %tn248 = load i64, ptr %tnp248, align 8
  %tk248 = icmp ule i64 %tn248, 615
  %tq248 = or i1 %tz248, %tk248
  %tx248 = call i1 @llvm.expect.i1(i1 %tq248, i1 false)
  br i1 %tx248, label %ao248.lento, label %ao248.reg
ao248.reg:
  %trp248 = getelementptr inbounds i8, ptr %ctx, i64 48
  %tr248 = load ptr, ptr %trp248, align 8
  %trb248 = getelementptr inbounds i8, ptr %tr248, i64 615
  %trv248 = load i8, ptr %trb248, align 1
  %trz248 = icmp eq i8 %trv248, 0
  %try248 = call i1 @llvm.expect.i1(i1 %trz248, i1 false)
  br i1 %try248, label %ao248.lento, label %ao248.rapido
ao248.rapido:
  store ptr %tnx248, ptr %ta248, align 8
  %tpp248 = getelementptr inbounds i8, ptr %tb248, i64 16
  store i64 0, ptr %tpp248, align 8
  store i64 2641405018113, ptr %tb248, align 8
  %thb248 = ptrtoint ptr %tb248 to i64
  %th248 = add i64 %thb248, 2
  br label %ao248.fim
ao248.lento:
  %tl248 = call i64 @dartforge_object_new_t(i64 615, i64 2, ptr @df.mt.dart$3acore.StateError)
  br label %ao248.fim
ao248.fim:
  %v248 = phi i64 [ %th248, %ao248.rapido ], [ %tl248, %ao248.lento ]
  store i64 %v248, ptr %gcs2
  call void @df.dart$3acore.StateError.new(i64 %v248, i64 %v247)
  %v250 = load i8, ptr %ctx, align 8
  %c28 = zext i8 %v250 to i64
  %v251 = icmp ne i64 %c28, 0
  br i1 %v251, label %b148, label %b147
b146:
  %fxk252 = and i64 %v121, -9223372036854775801
  %fxo252 = icmp eq i64 %fxk252, 2
  %fxa252 = add i64 %v121, -2
  %fxq252 = inttoptr i64 %fxa252 to ptr
  %fxvp252 = getelementptr inbounds i8, ptr %ctx, i64 40
  %fxv252 = load ptr, ptr %fxvp252, align 8
  %fxh252 = select i1 %fxo252, ptr %fxq252, ptr %fxv252
  %fxfp252 = getelementptr inbounds i8, ptr %fxh252, i64 1
  %fxf252 = load i8, ptr %fxfp252, align 1
  %fxfb252 = and i8 %fxf252, 1
  %fxfo252 = icmp ne i8 %fxfb252, 0
  %fxcp252 = getelementptr inbounds i8, ptr %fxh252, i64 16
  %fxc252 = load ptr, ptr %fxcp252, align 8
  %fcb252 = select i1 %fxfo252, ptr %fxc252, ptr %fxh252
  %fp252 = getelementptr inbounds i8, ptr %fcb252, i64 16
  %fg252 = getelementptr inbounds i64, ptr %fp252, i64 0
  %v252 = load i64, ptr %fg252, align 8
  %xcp253 = load i8, ptr %ctx, align 8
  %xcn253 = icmp ne i8 %xcp253, 0
  %xce253 = call i1 @llvm.expect.i1(i1 %xcn253, i1 false)
  br i1 %xce253, label %xc253.limpar, label %xc253.fim
xc253.limpar:
  call void @dartforge_exception_clear()
  br label %xc253.fim
xc253.fim:
  br label %b149
b147:
  store i64 0, ptr %gcs1
  call void @dartforge_exception_throw(i64 %v248, i8 3)
  br label %b149
b148:
  br label %b149
b149:
  %v255 = phi i64 [ %v252, %xc253.fim ], [ 0, %b147 ], [ 0, %b148 ]
  %v235 = load i8, ptr %ctx, align 8
  %c29 = zext i8 %v235 to i64
  %v236 = icmp ne i64 %c29, 0
  br i1 %v236, label %b137, label %b136
b136:
  store i64 0, ptr %gcs1
  store i64 0, ptr %gcs2
  %v237 = call i64 @df.box_int(i64 %v255)
  br label %b134
b137:
  br label %b143
b138:
  %v238 = add i64 0, 7
  %v239 = sub i64 0, %v238
  br label %b140
b139:
  %v240 = call i64 @df.unbox_int(i64 %v232)
  %v241 = load i8, ptr %ctx, align 8
  %c30 = zext i8 %v241 to i64
  %v242 = icmp ne i64 %c30, 0
  br i1 %v242, label %b142, label %b141
b140:
  %v243 = phi i64 [ %v240, %b141 ], [ %v239, %b138 ]
  br label %b143
b141:
  br label %b140
b142:
  br label %b143
b143:
  %v244 = phi i64 [ 0, %b137 ], [ %v243, %b140 ], [ 0, %b142 ]
  %v126 = load i8, ptr %ctx, align 8
  %c31 = zext i8 %v126 to i64
  %v127 = icmp ne i64 %c31, 0
  br i1 %v127, label %b67, label %b66
b65:
  %gcvolta65 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta65, ptr %ctxtopo, align 8
  ret void
b66:
  store i64 0, ptr %gcs1
  store i64 0, ptr %gcs2
  %v128 = call i64 @df.box_int(i64 %v244)
  store i64 %v128, ptr %gcs1
  call void @df.dart$3acore..print(i64 %v128)
  %v130 = load i8, ptr %ctx, align 8
  %c32 = zext i8 %v130 to i64
  %v131 = icmp ne i64 %c32, 0
  br i1 %v131, label %b69, label %b68
b67:
  %gcvolta67 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta67, ptr %ctxtopo, align 8
  ret void
b68:
  br label %b49
b69:
  %gcvolta69 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta69, ptr %ctxtopo, align 8
  ret void
b70:
  store i64 0, ptr %gcs0
  store i64 0, ptr %gcs1
  %v136 = call i64 @df.box_int(i64 %v183)
  store i64 %v136, ptr %gcs0
  call void @df.dart$3acore..print(i64 %v136)
  %v138 = load i8, ptr %ctx, align 8
  %c33 = zext i8 %v138 to i64
  %v139 = icmp ne i64 %c33, 0
  br i1 %v139, label %b73, label %b72
b71:
  %gcvolta71 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta71, ptr %ctxtopo, align 8
  ret void
b72:
  %v140 = add i64 0, 12
  store i64 0, ptr %gcs0
  %ta142 = getelementptr inbounds i8, ptr %ctx, i64 96
  %tb142 = load ptr, ptr %ta142, align 8
  %tfa142 = getelementptr inbounds i8, ptr %ctx, i64 104
  %tf142 = load ptr, ptr %tfa142, align 8
  %tnx142 = getelementptr i8, ptr %tb142, i64 32
  %tz142 = icmp ugt ptr %tnx142, %tf142
  %tnp142 = getelementptr inbounds i8, ptr %ctx, i64 56
  %tn142 = load i64, ptr %tnp142, align 8
  %tk142 = icmp ule i64 %tn142, 1025
  %tq142 = or i1 %tz142, %tk142
  %tx142 = call i1 @llvm.expect.i1(i1 %tq142, i1 false)
  br i1 %tx142, label %ao142.lento, label %ao142.reg
ao142.reg:
  %trp142 = getelementptr inbounds i8, ptr %ctx, i64 48
  %tr142 = load ptr, ptr %trp142, align 8
  %trb142 = getelementptr inbounds i8, ptr %tr142, i64 1025
  %trv142 = load i8, ptr %trb142, align 1
  %trz142 = icmp eq i8 %trv142, 0
  %try142 = call i1 @llvm.expect.i1(i1 %trz142, i1 false)
  br i1 %try142, label %ao142.lento, label %ao142.rapido
ao142.rapido:
  store ptr %tnx142, ptr %ta142, align 8
  %tpp142 = getelementptr inbounds i8, ptr %tb142, i64 16
  store i64 0, ptr %tpp142, align 8
  store i64 4402341609473, ptr %tb142, align 8
  %thb142 = ptrtoint ptr %tb142 to i64
  %th142 = add i64 %thb142, 2
  br label %ao142.fim
ao142.lento:
  %tl142 = call i64 @dartforge_object_new_t(i64 1025, i64 2, ptr @df.mt.scalar_nullable_count$2edart.NumberSource)
  br label %ao142.fim
ao142.fim:
  %v142 = phi i64 [ %th142, %ao142.rapido ], [ %tl142, %ao142.lento ]
  store i64 %v142, ptr %gcs0
  %fxa256 = add i64 %v142, -2
  %fcb256 = inttoptr i64 %fxa256 to ptr
  %fp256 = getelementptr inbounds i8, ptr %fcb256, i64 16
  %fg256 = getelementptr inbounds i64, ptr %fp256, i64 0
  store i64 %v140, ptr %fg256, align 8
  %fmp256 = getelementptr inbounds i8, ptr %fcb256, i64 8
  %fm256 = load i32, ptr %fmp256, align 4
  %fmc256 = and i32 %fm256, -2
  store i32 %fmc256, ptr %fmp256, align 4
  %fxa258 = add i64 %v142, -2
  %fcb258 = inttoptr i64 %fxa258 to ptr
  %fp258 = getelementptr inbounds i8, ptr %fcb258, i64 16
  %fg258 = getelementptr inbounds i64, ptr %fp258, i64 1
  store i64 1, ptr %fg258, align 8
  %fmp258 = getelementptr inbounds i8, ptr %fcb258, i64 8
  %fm258 = load i32, ptr %fmp258, align 4
  %fmc258 = and i32 %fm258, -3
  store i32 %fmc258, ptr %fmp258, align 4
  %v144 = load i8, ptr %ctx, align 8
  %c34 = zext i8 %v144 to i64
  %v145 = icmp ne i64 %c34, 0
  br i1 %v145, label %b76, label %b77
b73:
  %gcvolta73 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta73, ptr %ctxtopo, align 8
  ret void
b75:
  %gcvolta75 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta75, ptr %ctxtopo, align 8
  ret void
b76:
  store i64 0, ptr %gcs0
  store i64 0, ptr %gcs1
  %v156 = call i64 @dartforge_exception_peek_ref()
  call void @dartforge_effects_before(ptr @df.efn.1, i64 29, i64 3)
  %v157 = call i8 @dartforge_exception_catchable()
  call void @dartforge_effects_after()
  %c35 = zext i8 %v157 to i64
  %v158 = icmp ne i64 %c35, 0
  br i1 %v158, label %b81, label %b82
b77:
  %v259 = icmp eq i64 %v142, 0
  br i1 %v259, label %b153, label %b154
b153:
  %v260 = phi i64 [ 0, %b77 ], [ %v265, %b155 ]
  store i64 %v260, ptr %gcs0
  %v261 = icmp eq i64 %v260, 0
  br i1 %v261, label %b157, label %b158
b154:
  %fxk273 = and i64 %v142, -9223372036854775801
  %fxo273 = icmp eq i64 %fxk273, 2
  %fxa273 = add i64 %v142, -2
  %fxq273 = inttoptr i64 %fxa273 to ptr
  %fxvp273 = getelementptr inbounds i8, ptr %ctx, i64 40
  %fxv273 = load ptr, ptr %fxvp273, align 8
  %fxh273 = select i1 %fxo273, ptr %fxq273, ptr %fxv273
  %fxfp273 = getelementptr inbounds i8, ptr %fxh273, i64 1
  %fxf273 = load i8, ptr %fxfp273, align 1
  %fxfb273 = and i8 %fxf273, 1
  %fxfo273 = icmp ne i8 %fxfb273, 0
  %fxcp273 = getelementptr inbounds i8, ptr %fxh273, i64 16
  %fxc273 = load ptr, ptr %fxcp273, align 8
  %fcb273 = select i1 %fxfo273, ptr %fxc273, ptr %fxh273
  %fp273 = getelementptr inbounds i8, ptr %fcb273, i64 16
  %fg273 = getelementptr inbounds i64, ptr %fp273, i64 1
  %v273 = load i64, ptr %fg273, align 8
  %v274 = icmp ne i64 %v273, 0
  br i1 %v274, label %b164, label %b165
b164:
  %v275 = ptrtoint ptr getelementptr inbounds (i8, ptr @"df.s.9e342f55d946ea1f6cdc7c8dec0e9944", i64 2) to i64
  store i64 %v275, ptr %gcs0
  %ta276 = getelementptr inbounds i8, ptr %ctx, i64 96
  %tb276 = load ptr, ptr %ta276, align 8
  %tfa276 = getelementptr inbounds i8, ptr %ctx, i64 104
  %tf276 = load ptr, ptr %tfa276, align 8
  %tnx276 = getelementptr i8, ptr %tb276, i64 32
  %tz276 = icmp ugt ptr %tnx276, %tf276
  %tnp276 = getelementptr inbounds i8, ptr %ctx, i64 56
  %tn276 = load i64, ptr %tnp276, align 8
  %tk276 = icmp ule i64 %tn276, 615
  %tq276 = or i1 %tz276, %tk276
  %tx276 = call i1 @llvm.expect.i1(i1 %tq276, i1 false)
  br i1 %tx276, label %ao276.lento, label %ao276.reg
ao276.reg:
  %trp276 = getelementptr inbounds i8, ptr %ctx, i64 48
  %tr276 = load ptr, ptr %trp276, align 8
  %trb276 = getelementptr inbounds i8, ptr %tr276, i64 615
  %trv276 = load i8, ptr %trb276, align 1
  %trz276 = icmp eq i8 %trv276, 0
  %try276 = call i1 @llvm.expect.i1(i1 %trz276, i1 false)
  br i1 %try276, label %ao276.lento, label %ao276.rapido
ao276.rapido:
  store ptr %tnx276, ptr %ta276, align 8
  %tpp276 = getelementptr inbounds i8, ptr %tb276, i64 16
  store i64 0, ptr %tpp276, align 8
  store i64 2641405018113, ptr %tb276, align 8
  %thb276 = ptrtoint ptr %tb276 to i64
  %th276 = add i64 %thb276, 2
  br label %ao276.fim
ao276.lento:
  %tl276 = call i64 @dartforge_object_new_t(i64 615, i64 2, ptr @df.mt.dart$3acore.StateError)
  br label %ao276.fim
ao276.fim:
  %v276 = phi i64 [ %th276, %ao276.rapido ], [ %tl276, %ao276.lento ]
  store i64 %v276, ptr %gcs1
  call void @df.dart$3acore.StateError.new(i64 %v276, i64 %v275)
  %v278 = load i8, ptr %ctx, align 8
  %c36 = zext i8 %v278 to i64
  %v279 = icmp ne i64 %c36, 0
  br i1 %v279, label %b167, label %b166
b165:
  %fxk280 = and i64 %v142, -9223372036854775801
  %fxo280 = icmp eq i64 %fxk280, 2
  %fxa280 = add i64 %v142, -2
  %fxq280 = inttoptr i64 %fxa280 to ptr
  %fxvp280 = getelementptr inbounds i8, ptr %ctx, i64 40
  %fxv280 = load ptr, ptr %fxvp280, align 8
  %fxh280 = select i1 %fxo280, ptr %fxq280, ptr %fxv280
  %fxfp280 = getelementptr inbounds i8, ptr %fxh280, i64 1
  %fxf280 = load i8, ptr %fxfp280, align 1
  %fxfb280 = and i8 %fxf280, 1
  %fxfo280 = icmp ne i8 %fxfb280, 0
  %fxcp280 = getelementptr inbounds i8, ptr %fxh280, i64 16
  %fxc280 = load ptr, ptr %fxcp280, align 8
  %fcb280 = select i1 %fxfo280, ptr %fxc280, ptr %fxh280
  %fp280 = getelementptr inbounds i8, ptr %fcb280, i64 16
  %fg280 = getelementptr inbounds i64, ptr %fp280, i64 0
  %v280 = load i64, ptr %fg280, align 8
  %xcp281 = load i8, ptr %ctx, align 8
  %xcn281 = icmp ne i8 %xcp281, 0
  %xce281 = call i1 @llvm.expect.i1(i1 %xcn281, i1 false)
  br i1 %xce281, label %xc281.limpar, label %xc281.fim
xc281.limpar:
  call void @dartforge_exception_clear()
  br label %xc281.fim
xc281.fim:
  br label %b168
b166:
  store i64 0, ptr %gcs0
  call void @dartforge_exception_throw(i64 %v276, i8 3)
  br label %b168
b167:
  br label %b168
b168:
  %v283 = phi i64 [ %v280, %xc281.fim ], [ 0, %b166 ], [ 0, %b167 ]
  %v263 = load i8, ptr %ctx, align 8
  %c37 = zext i8 %v263 to i64
  %v264 = icmp ne i64 %c37, 0
  br i1 %v264, label %b156, label %b155
b155:
  store i64 0, ptr %gcs0
  store i64 0, ptr %gcs1
  %v265 = call i64 @df.box_int(i64 %v283)
  br label %b153
b156:
  br label %b162
b157:
  %v266 = add i64 0, 7
  %v267 = sub i64 0, %v266
  br label %b159
b158:
  %v268 = call i64 @df.unbox_int(i64 %v260)
  %v269 = load i8, ptr %ctx, align 8
  %c38 = zext i8 %v269 to i64
  %v270 = icmp ne i64 %c38, 0
  br i1 %v270, label %b161, label %b160
b159:
  %v271 = phi i64 [ %v268, %b160 ], [ %v267, %b157 ]
  br label %b162
b160:
  br label %b159
b161:
  br label %b162
b162:
  %v272 = phi i64 [ 0, %b156 ], [ %v271, %b159 ], [ 0, %b161 ]
  %v147 = load i8, ptr %ctx, align 8
  %c39 = zext i8 %v147 to i64
  %v148 = icmp ne i64 %c39, 0
  br i1 %v148, label %b76, label %b78
b78:
  store i64 0, ptr %gcs0
  store i64 0, ptr %gcs1
  %v149 = call i64 @df.box_int(i64 %v272)
  store i64 %v149, ptr %gcs0
  call void @df.dart$3acore..print(i64 %v149)
  %v151 = load i8, ptr %ctx, align 8
  %c40 = zext i8 %v151 to i64
  %v152 = icmp ne i64 %c40, 0
  br i1 %v152, label %b76, label %b79
b79:
  %v154 = load i8, ptr %ctx, align 8
  %c41 = zext i8 %v154 to i64
  %v155 = icmp ne i64 %c41, 0
  br i1 %v155, label %b76, label %b80
b80:
  br label %b75
b81:
  %xcp159 = load i8, ptr %ctx, align 8
  %xcn159 = icmp ne i8 %xcp159, 0
  %xce159 = call i1 @llvm.expect.i1(i1 %xcn159, i1 false)
  br i1 %xce159, label %xc159.limpar, label %xc159.fim
xc159.limpar:
  call void @dartforge_exception_clear()
  br label %xc159.fim
xc159.fim:
  %v162 = ptrtoint ptr getelementptr inbounds (i8, ptr @"df.s.836222fa803db3948287b6db9a77b50d", i64 2) to i64
  store i64 %v162, ptr %gcs0
  call void @df.dart$3acore..print(i64 %v162)
  %v164 = load i8, ptr %ctx, align 8
  %c42 = zext i8 %v164 to i64
  %v165 = icmp ne i64 %c42, 0
  br i1 %v165, label %b86, label %b85
b82:
  %gcvolta82 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta82, ptr %ctxtopo, align 8
  ret void
b85:
  br label %b75
b86:
  %gcvolta86 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta86, ptr %ctxtopo, align 8
  ret void
}

define i64 @df.rti.3826facde6a2fcb1.scalar_nullable_count$2edart() nounwind {
b0:
  %area = call ptr @df.get_area()
  %ga0 = getelementptr i64, ptr %area, i64 1
  %v0 = load i8, ptr %ga0
  %c0 = zext i8 %v0 to i64
  %v1 = icmp ne i64 %c0, 0
  br i1 %v1, label %b1, label %b2
b1:
  %ga2 = getelementptr i64, ptr %area, i64 0
  %v2 = load i64, ptr %ga2
  ret i64 %v2
b2:
  %v3 = ptrtoint ptr getelementptr inbounds (i8, ptr @"df.s.cb7f3572c64be131669558df21a34c70", i64 2) to i64
  call void @dartforge_effects_before(ptr @df.efn.2, i64 20, i64 3)
  %v4 = call i64 @dartforge_rti_recipe(i64 %v3)
  call void @dartforge_effects_after()
  %ga5 = getelementptr i64, ptr %area, i64 0
  store i64 %v4, ptr %ga5
  %ga6 = getelementptr i64, ptr %area, i64 1
  store i8 1, ptr %ga6
  ret i64 %v4
}




define i64 @df.$type.$3d$3d$c(i64 %v0, ptr %v1, ptr %v2) nounwind {
b0:
  %gcq = alloca { ptr, i64, [2 x i64] }, align 8
  %pilhaq = alloca i8, align 1
  %ctx = call ptr @df.context()
  %ctxtopo = getelementptr inbounds i8, ptr %ctx, i64 8
  %pilhalp = getelementptr inbounds i8, ptr %ctx, i64 376
  %pilhal = load ptr, ptr %pilhalp, align 8
  %pilhab = icmp ult ptr %pilhaq, %pilhal
  %pilhax = call i1 @llvm.expect.i1(i1 %pilhab, i1 false)
  br i1 %pilhax, label %pilha.estouro, label %pilha.ok
pilha.estouro:
  call void @dartforge_stack_overflow()
  ret i64 0
pilha.ok:
  store { ptr, i64, [2 x i64] } { ptr null, i64 2, [2 x i64] zeroinitializer }, ptr %gcq
  %gcs0 = getelementptr inbounds { ptr, i64, [2 x i64] }, ptr %gcq, i64 0, i32 2, i64 0
  %gcs1 = getelementptr inbounds { ptr, i64, [2 x i64] }, ptr %gcq, i64 0, i32 2, i64 1
  %gcant = load ptr, ptr %ctxtopo, align 8
  store ptr %gcant, ptr %gcq, align 8
  store ptr %gcq, ptr %ctxtopo, align 8
  store i64 %v0, ptr %gcs0
  %li3 = getelementptr i64, ptr %v1, i64 0
  %v3 = load i64, ptr %li3
  store i64 %v3, ptr %gcs1
  %v4 = icmp eq i64 %v0, %v3
  store i64 0, ptr %gcs0
  store i64 0, ptr %gcs1
  %v5 = call i64 @df.box_bool(i1 %v4)
  %gcvolta0 = load ptr, ptr %gcq, align 8
  store ptr %gcvolta0, ptr %ctxtopo, align 8
  ret i64 %v5
}

define i64 @df.$type.toString$c(i64 %v0, ptr %v1, ptr %v2) nounwind {
b0:
  %pilhaq = alloca i8, align 1
  %ctx = call ptr @df.context()
  %ctxtopo = getelementptr inbounds i8, ptr %ctx, i64 8
  %pilhalp = getelementptr inbounds i8, ptr %ctx, i64 376
  %pilhal = load ptr, ptr %pilhalp, align 8
  %pilhab = icmp ult ptr %pilhaq, %pilhal
  %pilhax = call i1 @llvm.expect.i1(i1 %pilhab, i1 false)
  br i1 %pilhax, label %pilha.estouro, label %pilha.ok
pilha.estouro:
  call void @dartforge_stack_overflow()
  ret i64 0
pilha.ok:
  %fxa6 = add i64 %v0, -2
  %fcb6 = inttoptr i64 %fxa6 to ptr
  %fp6 = getelementptr inbounds i8, ptr %fcb6, i64 16
  %fg6 = getelementptr inbounds i64, ptr %fp6, i64 0
  %v6 = load i64, ptr %fg6, align 8
  %v7 = call i64 @dartforge_rti_string(i64 %v6)
  %v4 = load i8, ptr %ctx, align 8
  %c0 = zext i8 %v4 to i64
  %v5 = icmp ne i64 %c0, 0
  br i1 %v5, label %b2, label %b1
b1:
  ret i64 %v7
b2:
  ret i64 0
}

define void @dartforge_rti_init() nounwind {
b0:
  %v0 = getelementptr i64, ptr @df.const.i64.2286.e28bda741dcd35c90d584a41a9adeb7d34119bfe232997dce14f5a0ac2ed187b, i64 0
  call void @dartforge_effects_before(ptr @df.efn.3, i64 24, i64 3)
  call void @dartforge_rti_init_table(ptr %v0, i64 18287)
  call void @dartforge_effects_after()
  ret void
}

define i64 @dartforge_dispatch_toString(i64 %obj) nounwind {
b0:
  %a = alloca [1 x i64]
  store i64 0, ptr %a
  %area = call ptr @df.get_area()
  %ic = getelementptr i64, ptr %area, i64 12
  %f = call ptr @df.selector(ptr %ic, i64 %obj, i64 -3445551396850951156, ptr @df.seln.4, i64 10)
  %r = call i64 %f(i64 %obj, ptr %a, ptr @df.const.i64.2.c314eb35009b14025e5ef5c352349ffcb0ff36f19602db3b02250d0153c9f892)
  ret i64 %r
}

@df.mt.scalar_nullable_count$2edart.Node$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 1024, i64 7, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.scalar_nullable_count$2edart.Node() nounwind {
b0:
  ret ptr @df.mt.scalar_nullable_count$2edart.Node$d
}
@df.mt.scalar_nullable_count$2edart.NumberSource$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 1025, i64 7, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.scalar_nullable_count$2edart.NumberSource() nounwind {
b0:
  ret ptr @df.mt.scalar_nullable_count$2edart.NumberSource$d
}
@df.mt.$type$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 1073741569, i64 7, i64 -9163797671095228218, ptr @df.$type.$3d$3d$c, i64 -3445551396850951156, ptr @df.$type.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.$type() nounwind {
b0:
  ret ptr @df.mt.$type$d
}
@"\01section$start$__DATA_CONST$__dfimg" = external hidden global i8
@"\01section$end$__DATA_CONST$__dfimg" = external hidden global i8
define void @df.register.program() nounwind {
b0:
  call void @dartforge_register_class_name(i64 0, ptr @.str.3, i64 6)
  call void @dartforge_register_class_name(i64 1024, ptr @.str.4, i64 4)
  call void @dartforge_register_class_name(i64 1025, ptr @.str.5, i64 12)
  call void @dartforge_register_class_name(i64 1073741569, ptr @.str.6, i64 5)
  call void @dartforge_register_subclass(i64 1024, i64 0)
  call void @dartforge_register_subclass(i64 1024, i64 602)
  call void @dartforge_register_subclass(i64 1025, i64 0)
  call void @dartforge_register_subclass(i64 1025, i64 602)
  call void @dartforge_register_subclass(i64 1073741569, i64 621)
  call void @dartforge_register_image(ptr @"\01section$start$__DATA_CONST$__dfimg", ptr @"\01section$end$__DATA_CONST$__dfimg")
  call void @dartforge_register_table(i64 1024, ptr @df.mt.scalar_nullable_count$2edart.Node)
  call void @dartforge_register_table(i64 1025, ptr @df.mt.scalar_nullable_count$2edart.NumberSource)
  call void @dartforge_register_table(i64 1073741569, ptr @df.mt.$type)
  ret void
}

@df.cids = private unnamed_addr constant [32 x i64] [i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7, i64 10, i64 8, i64 9, i64 11, i64 12, i64 23, i64 37, i64 29, i64 19, i64 20, i64 21, i64 22, i64 24, i64 25, i64 26, i64 27, i64 28, i64 30, i64 31, i64 32, i64 34, i64 33, i64 35, i64 17, i64 18]
@df.sdk_version = private unnamed_addr constant [47 x i8] c"3.6.2 \28stable\29 \28Wed Jan 29 01:20:39 2025 \2D0800\29"
define void @df.prepare_isolate() nounwind {
  call void @dartforge_register_cids(ptr @df.cids, i64 32)
  call void @dartforge_register_sdk_version(ptr @df.sdk_version, i64 47)
  call void @dartforge_register_table(i64 1, ptr @df.mt.dart$3acore.Null)
  call void @dartforge_register_table(i64 2, ptr @df.mt.dart$3acore._Smi)
  call void @dartforge_register_table(i64 3, ptr @df.mt.dart$3acore._Mint)
  call void @dartforge_register_table(i64 4, ptr @df.mt.dart$3acore._Double)
  call void @dartforge_register_table(i64 5, ptr @df.mt.dart$3acore.bool)
  call void @dartforge_register_table(i64 6, ptr @df.mt.dart$3acore._OneByteString)
  call void @dartforge_register_table(i64 7, ptr @df.mt.dart$3acore._TwoByteString)
  call void @dartforge_register_table(i64 10, ptr @df.mt.dart$3acore._GrowableList)
  call void @dartforge_register_table(i64 8, ptr @df.mt.dart$3acore._List)
  call void @dartforge_register_table(i64 9, ptr @df.mt.dart$3acore._ImmutableList)
  call void @dartforge_register_table(i64 11, ptr @df.mt.dart$3acore._Closure)
  call void @dartforge_register_table(i64 12, ptr @df.mt.dart$3acore._Record)
  call void @dartforge_register_table(i64 23, ptr @df.mt.dart$3atyped_data._Uint8List)
  call void @dartforge_register_table(i64 37, ptr @df.mt.dart$3atyped_data._Uint8ArrayView)
  call void @dartforge_register_table(i64 29, ptr @df.mt.dart$3atyped_data._Int64List)
  call void @dartforge_register_table(i64 19, ptr @df.mt.dart$3atyped_data._Float32x4)
  call void @dartforge_register_table(i64 20, ptr @df.mt.dart$3atyped_data._Int32x4)
  call void @dartforge_register_table(i64 21, ptr @df.mt.dart$3atyped_data._Float64x2)
  call void @dartforge_register_table(i64 22, ptr @df.mt.dart$3atyped_data._Int8List)
  call void @dartforge_register_table(i64 24, ptr @df.mt.dart$3atyped_data._Uint8ClampedList)
  call void @dartforge_register_table(i64 25, ptr @df.mt.dart$3atyped_data._Int16List)
  call void @dartforge_register_table(i64 26, ptr @df.mt.dart$3atyped_data._Uint16List)
  call void @dartforge_register_table(i64 27, ptr @df.mt.dart$3atyped_data._Int32List)
  call void @dartforge_register_table(i64 28, ptr @df.mt.dart$3atyped_data._Uint32List)
  call void @dartforge_register_table(i64 30, ptr @df.mt.dart$3atyped_data._Uint64List)
  call void @dartforge_register_table(i64 31, ptr @df.mt.dart$3atyped_data._Float32List)
  call void @dartforge_register_table(i64 32, ptr @df.mt.dart$3atyped_data._Float64List)
  call void @dartforge_register_table(i64 34, ptr @df.mt.dart$3atyped_data._Int32x4List)
  call void @dartforge_register_table(i64 33, ptr @df.mt.dart$3atyped_data._Float32x4List)
  call void @dartforge_register_table(i64 35, ptr @df.mt.dart$3atyped_data._Float64x2List)
  call void @dartforge_register_table(i64 17, ptr @df.mt.dart$3aisolate._SendPort)
  call void @dartforge_register_table(i64 18, ptr @df.mt.dart$3aisolate._Capability)
  call void @df.register.dart$3a_internal()
  call void @df.register.dart$3acore()
  call void @df.register.dart$3a_compact_hash()
  call void @df.register.dart$3acollection()
  call void @df.register.dart$3amath()
  call void @df.register.dart$3aconvert()
  call void @df.register.dart$3aasync()
  call void @df.register.dart$3atyped_data()
  call void @df.register.dart$3aisolate()
  call void @df.register.dart$3adeveloper()
  call void @df.register.dart$3anativewrappers()
  call void @df.register.dart$3affi()
  call void @df.register.dart$3a_http()
  call void @df.register.dart$3aio()
  call void @df.register.dart$3amirrors()
  call void @df.register.program()
  call void @dartforge_rti_init()
  call void @dartforge_ffi_register_type(i64 693, i64 98)
  call void @dartforge_ffi_register_type(i64 694, i64 97)
  call void @dartforge_ffi_register_type(i64 698, i64 100)
  call void @dartforge_ffi_register_type(i64 701, i64 102)
  call void @dartforge_ffi_register_type(i64 702, i64 72)
  call void @dartforge_ffi_register_type(i64 703, i64 105)
  call void @dartforge_ffi_register_type(i64 704, i64 115)
  call void @dartforge_ffi_register_type(i64 705, i64 105)
  call void @dartforge_ffi_register_type(i64 706, i64 108)
  call void @dartforge_ffi_register_type(i64 707, i64 97)
  call void @dartforge_ffi_register_type(i64 708, i64 108)
  call void @dartforge_ffi_register_type(i64 709, i64 108)
  call void @dartforge_ffi_register_type(i64 710, i64 108)
  call void @dartforge_ffi_register_type(i64 719, i64 112)
  call void @dartforge_ffi_register_type(i64 720, i64 115)
  call void @dartforge_ffi_register_type(i64 721, i64 97)
  call void @dartforge_ffi_register_type(i64 722, i64 109)
  call void @dartforge_ffi_register_type(i64 725, i64 116)
  call void @dartforge_ffi_register_type(i64 726, i64 106)
  call void @dartforge_ffi_register_type(i64 727, i64 109)
  call void @dartforge_ffi_register_type(i64 728, i64 104)
  call void @dartforge_ffi_register_type(i64 729, i64 109)
  call void @dartforge_ffi_register_type(i64 731, i64 104)
  call void @dartforge_ffi_register_type(i64 732, i64 106)
  call void @dartforge_ffi_register_type(i64 733, i64 109)
  call void @dartforge_ffi_register_type(i64 734, i64 109)
  call void @dartforge_ffi_register_type(i64 735, i64 116)
  call void @dartforge_ffi_register_type(i64 736, i64 42)
  call void @dartforge_ffi_register_type(i64 737, i64 118)
  call void @dartforge_ffi_register_type(i64 738, i64 105)
  call void @dartforge_prepare_embedder()
  ret void
}

define void @dartforge_entry() nounwind {
  call void @dartforge_register_isolates(ptr @df.prepare_isolate, ptr null)
  call void @df.prepare_isolate()
  call void @dart_main()
  ret void
}

define i32 @main() nounwind {
  %r = call i32 @dartforge_init(ptr @dartforge_entry, ptr @dartforge_dispatch_toString)
  ret i32 %r
}

@df.seln.0 = private unnamed_addr constant [10 x i8] c"g:iterator"
@df.seln.1 = private unnamed_addr constant [5 x i8] c"tc:\5B\5D"
@df.seln.2 = private unnamed_addr constant [10 x i8] c"c:moveNext"
@df.seln.3 = private unnamed_addr constant [9 x i8] c"g:current"
@df.seln.4 = private unnamed_addr constant [10 x i8] c"c:toString"

@df.area = private unnamed_addr constant [2 x i64] [i64 -7318119598941579387, i64 -14]
@df.area_id.program = internal global i64 0, align 8
define internal ptr @df.get_area() alwaysinline nounwind {
%ctx = call ptr @df.context()
%id = load atomic i64, ptr @df.area_id.program monotonic, align 8
%tp = getelementptr inbounds i8, ptr %ctx, i64 16
%t = load ptr, ptr %tp, align 8
%np = getelementptr inbounds i8, ptr %ctx, i64 24
%n = load i64, ptr %np, align 8
%dentro = icmp ult i64 %id, %n
br i1 %dentro, label %ler, label %lenta
ler:
%e = getelementptr ptr, ptr %t, i64 %id
%p = load ptr, ptr %e, align 8
%tem = icmp ne ptr %p, null
br i1 %tem, label %pronto, label %lenta
pronto:
ret ptr %p
lenta:
%q = call ptr @dartforge_globals_area_id(ptr @df.area, ptr @df.area_id.program)
ret ptr %q
}
; Static string literals (docs/NATIVO-ESPACO-UNIFICADO.md §2.11)
@"df.s.836222fa803db3948287b6db9a77b50d" = linkonce_odr constant { i64, i64, i64, [8 x i8] } { i64 25769935365, i64 799585169, i64 6, [8 x i8] c"caught\00\00" }, section "__DATA_CONST,__dfimg", align 8
@"df.s.9e342f55d946ea1f6cdc7c8dec0e9944" = linkonce_odr constant { i64, i64, i64, [16 x i8] } { i64 25770000901, i64 272845359, i64 11, [16 x i8] c"read failed\00\00\00\00\00" }, section "__DATA_CONST,__dfimg", align 8
@"df.s.cb7f3572c64be131669558df21a34c70" = linkonce_odr constant { i64, i64, i64, [16 x i8] } { i64 25770000901, i64 800598431, i64 10, [16 x i8] c"C597<C674>\00\00\00\00\00\00" }, section "__DATA_CONST,__dfimg", align 8

@df.efn.0 = private unnamed_addr constant [17 x i8] c"dartforge_rti_set"
@df.efn.1 = private unnamed_addr constant [29 x i8] c"dartforge_exception_catchable"
@df.efn.2 = private unnamed_addr constant [20 x i8] c"dartforge_rti_recipe"
@df.efn.3 = private unnamed_addr constant [24 x i8] c"dartforge_rti_init_table"
; Defined in another module (source SDK) or in the runtime
declare void @df.dart$3acore..print(i64)
declare void @df.dart$3acore.ConcurrentModificationError.new(i64, i64)
declare i64 @df.dart$3acore.Object.$3d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.Object._identityHashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.Object.hashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.Object.noSuchMethod$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.Object.noSuchMethod$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore.Object.runtimeType$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.Object.toString$c(i64, ptr, ptr)
declare void @df.dart$3acore.StateError.new(i64, i64)
declare void @df.register.dart$3a_compact_hash()
declare void @df.register.dart$3a_http()
declare void @df.register.dart$3a_internal()
declare void @df.register.dart$3aasync()
declare void @df.register.dart$3acollection()
declare void @df.register.dart$3aconvert()
declare void @df.register.dart$3acore()
declare void @df.register.dart$3adeveloper()
declare void @df.register.dart$3affi()
declare void @df.register.dart$3aio()
declare void @df.register.dart$3aisolate()
declare void @df.register.dart$3amath()
declare void @df.register.dart$3amirrors()
declare void @df.register.dart$3anativewrappers()
declare void @df.register.dart$3atyped_data()


@dartforge_context_slot = external global i64, align 8
define internal ptr @df.context() nounwind willreturn memory(none) alwaysinline {
  %o = load i64, ptr @dartforge_context_slot, align 8, !invariant.load !{}
  %t = call i64 asm "mrs $0, TPIDRRO_EL0", "=r"() nounwind memory(none)
  %b = and i64 %t, -8
  %a = add i64 %b, %o
  %p = inttoptr i64 %a to ptr
  %c = load ptr, ptr %p, align 8, !invariant.load !{}
  %z0 = icmp eq i64 %o, 0
  %z1 = icmp eq ptr %c, null
  %z = or i1 %z0, %z1
  br i1 %z, label %lento, label %pronto
lento:
  %n = call ptr @df.context.slow()
  ret ptr %n
pronto:
  ret ptr %c
}
define internal ptr @df.context.slow() noinline cold nounwind {
  %n = call ptr @dartforge_context()
  ret ptr %n
}

; SDK method tables assembled at link time (docs/NATIVO-PODA-DE-TABELAS.md)
@df.mt.dart$3a_internal.CodeUnits$d = private unnamed_addr constant { i64, i64 } { i64 266, i64 0 }
define ptr @df.mt.dart$3a_internal.CodeUnits() {
b0:
  ret ptr @df.mt.dart$3a_internal.CodeUnits$d
}
@df.mt.dart$3a_internal.ExternalName$d = private unnamed_addr constant { i64, i64 } { i64 278, i64 0 }
define ptr @df.mt.dart$3a_internal.ExternalName() {
b0:
  ret ptr @df.mt.dart$3a_internal.ExternalName$d
}
@df.mt.dart$3a_internal.SentinelValue$d = private unnamed_addr constant { i64, i64 } { i64 306, i64 0 }
define ptr @df.mt.dart$3a_internal.SentinelValue() {
b0:
  ret ptr @df.mt.dart$3a_internal.SentinelValue$d
}
@df.mt.dart$3a_internal.Since$d = private unnamed_addr constant { i64, i64 } { i64 307, i64 0 }
define ptr @df.mt.dart$3a_internal.Since() {
b0:
  ret ptr @df.mt.dart$3a_internal.Since$d
}
@df.mt.dart$3a_internal.NotNullableError$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 303, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -4713017734788692867, ptr @df.dart$3acore.Error.stackTrace$g, i64 -3445551396850951156, ptr @df.dart$3a_internal.NotNullableError.toString$c, i64 -2772688926328976598, ptr @df.dart$3acore.Error._stackTrace$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3a_internal.NotNullableError() {
b0:
  ret ptr @df.mt.dart$3a_internal.NotNullableError$d
}
@df.mt.dart$3a_internal.DoubleLinkedQueueEntry$d = private unnamed_addr constant { i64, i64 } { i64 267, i64 0 }
define ptr @df.mt.dart$3a_internal.DoubleLinkedQueueEntry() {
b0:
  ret ptr @df.mt.dart$3a_internal.DoubleLinkedQueueEntry$d
}
@df.mt.dart$3a_internal.TypeTest$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 320, i64 8, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8837432310960030788, ptr @df.dart$3a_internal.TypeTest.test$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3a_internal.TypeTest() {
b0:
  ret ptr @df.mt.dart$3a_internal.TypeTest$d
}
@df.mt.dart$3a_internal.CastStream$d = private unnamed_addr constant { i64, i64 } { i64 262, i64 0 }
define ptr @df.mt.dart$3a_internal.CastStream() {
b0:
  ret ptr @df.mt.dart$3a_internal.CastStream$d
}
@df.mt.dart$3a_internal.CastStreamSubscription$d = private unnamed_addr constant { i64, i64 } { i64 263, i64 0 }
define ptr @df.mt.dart$3a_internal.CastStreamSubscription() {
b0:
  ret ptr @df.mt.dart$3a_internal.CastStreamSubscription$d
}
@df.mt.dart$3a_internal.CastStreamTransformer$d = private unnamed_addr constant { i64, i64 } { i64 264, i64 0 }
define ptr @df.mt.dart$3a_internal.CastStreamTransformer() {
b0:
  ret ptr @df.mt.dart$3a_internal.CastStreamTransformer$d
}
@df.mt.dart$3a_internal.CastConverter$d = private unnamed_addr constant { i64, i64 } { i64 255, i64 0 }
define ptr @df.mt.dart$3a_internal.CastConverter() {
b0:
  ret ptr @df.mt.dart$3a_internal.CastConverter$d
}
@df.mt.dart$3a_internal._CopyingBytesBuilder$d = private unnamed_addr constant { i64, i64 } { i64 333, i64 0 }
define ptr @df.mt.dart$3a_internal._CopyingBytesBuilder() {
b0:
  ret ptr @df.mt.dart$3a_internal._CopyingBytesBuilder$d
}
@df.mt.dart$3a_internal._BytesBuilder$d = private unnamed_addr constant { i64, i64 } { i64 330, i64 0 }
define ptr @df.mt.dart$3a_internal._BytesBuilder() {
b0:
  ret ptr @df.mt.dart$3a_internal._BytesBuilder$d
}
@df.mt.dart$3a_internal.CastIterator$d = private unnamed_addr constant { i64, i64 } { i64 257, i64 0 }
define ptr @df.mt.dart$3a_internal.CastIterator() {
b0:
  ret ptr @df.mt.dart$3a_internal.CastIterator$d
}
@df.mt.dart$3a_internal.CastIterable$d = private unnamed_addr constant { i64, i64 } { i64 256, i64 0 }
define ptr @df.mt.dart$3a_internal.CastIterable() {
b0:
  ret ptr @df.mt.dart$3a_internal.CastIterable$d
}
@df.mt.dart$3a_internal._EfficientLengthCastIterable$d = private unnamed_addr constant { i64, i64 } { i64 334, i64 0 }
define ptr @df.mt.dart$3a_internal._EfficientLengthCastIterable() {
b0:
  ret ptr @df.mt.dart$3a_internal._EfficientLengthCastIterable$d
}
@df.mt.dart$3a_internal.CastList$d = private unnamed_addr constant { i64, i64 } { i64 258, i64 0 }
define ptr @df.mt.dart$3a_internal.CastList() {
b0:
  ret ptr @df.mt.dart$3a_internal.CastList$d
}
@df.mt.dart$3a_internal.CastSet$d = private unnamed_addr constant { i64, i64 } { i64 261, i64 0 }
define ptr @df.mt.dart$3a_internal.CastSet() {
b0:
  ret ptr @df.mt.dart$3a_internal.CastSet$d
}
@df.mt.dart$3a_internal.CastMap$d = private unnamed_addr constant { i64, i64 } { i64 259, i64 0 }
define ptr @df.mt.dart$3a_internal.CastMap() {
b0:
  ret ptr @df.mt.dart$3a_internal.CastMap$d
}
@df.mt.dart$3a_internal.CastQueue$d = private unnamed_addr constant { i64, i64 } { i64 260, i64 0 }
define ptr @df.mt.dart$3a_internal.CastQueue() {
b0:
  ret ptr @df.mt.dart$3a_internal.CastQueue$d
}
@df.mt.dart$3a_internal.LateError$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 290, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -4713017734788692867, ptr @df.dart$3acore.Error.stackTrace$g, i64 -3445551396850951156, ptr @df.dart$3a_internal.LateError.toString$c, i64 -2772688926328976598, ptr @df.dart$3acore.Error._stackTrace$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3a_internal.LateError() {
b0:
  ret ptr @df.mt.dart$3a_internal.LateError$d
}
@df.mt.dart$3a_internal.ReachabilityError$d = private unnamed_addr constant { i64, i64 } { i64 304, i64 0 }
define ptr @df.mt.dart$3a_internal.ReachabilityError() {
b0:
  ret ptr @df.mt.dart$3a_internal.ReachabilityError$d
}
@df.mt.dart$3a_internal.SubListIterable$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 313, i64 25, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -7142806495848668844, ptr @df.dart$3a_internal.ListIterable.last$g, i64 -7048868133546680485, ptr @df.dart$3a_internal.SubListIterable.toList$tc, i64 -6880024560892829041, ptr @df.dart$3a_internal.SubListIterable.skip$c, i64 -6565620648322651272, ptr @df.dart$3a_internal.SubListIterable.length$g, i64 -6455655928913991845, ptr @df.dart$3a_internal.SubListIterable.take$c, i64 -5476269667379286226, ptr @df.dart$3a_internal.ListIterable.iterator$g, i64 -4183823290162052582, ptr @df.dart$3a_internal.ListIterable.join$tc, i64 -3445551396850951156, ptr @df.dart$3acore.Iterable.toString$c, i64 -3444103220339216083, ptr @df.dart$3a_internal.ListIterable.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3a_internal.SubListIterable.elementAt$c, i64 -2322265645133230011, ptr @df.dart$3a_internal.SubListIterable.skip$tc, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -730073319095210781, ptr @df.dart$3a_internal.SubListIterable.elementAt$tc, i64 590583546444750725, ptr @df.dart$3a_internal.SubListIterable.take$tc, i64 1309726782632086582, ptr @df.dart$3acore.Iterable.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3a_internal.SubListIterable.toList$c, i64 1890975232377856814, ptr @df.dart$3a_internal.ListIterable.map$c, i64 3251101298082571214, ptr @df.dart$3a_internal.ListIterable.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4584568332005005361, ptr @df.dart$3a_internal.ListIterable.contains$c, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3a_internal.ListIterable.join$c, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3a_internal.SubListIterable() {
b0:
  ret ptr @df.mt.dart$3a_internal.SubListIterable$d
}
@df.mt.dart$3a_internal.ListIterator$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 294, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -5038376148439920376, ptr @df.dart$3a_internal.ListIterator.moveNext$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 1052728634250411761, ptr @df.dart$3a_internal.ListIterator.current$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3a_internal.ListIterator() {
b0:
  ret ptr @df.mt.dart$3a_internal.ListIterator$d
}
@df.mt.dart$3a_internal.MappedIterable$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 297, i64 25, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -7142806495848668844, ptr @df.dart$3a_internal.MappedIterable.last$g, i64 -7048868133546680485, ptr @df.dart$3acore.Iterable.toList$tc, i64 -6880024560892829041, ptr @df.dart$3acore.Iterable.skip$c, i64 -6565620648322651272, ptr @df.dart$3a_internal.MappedIterable.length$g, i64 -6455655928913991845, ptr @df.dart$3acore.Iterable.take$c, i64 -5476269667379286226, ptr @df.dart$3a_internal.MappedIterable.iterator$g, i64 -4183823290162052582, ptr @df.dart$3acore.Iterable.join$tc, i64 -3445551396850951156, ptr @df.dart$3acore.Iterable.toString$c, i64 -3444103220339216083, ptr @df.dart$3a_internal.MappedIterable.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3a_internal.MappedIterable.elementAt$c, i64 -2322265645133230011, ptr @df.dart$3acore.Iterable.skip$tc, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -730073319095210781, ptr @df.dart$3a_internal.MappedIterable.elementAt$tc, i64 590583546444750725, ptr @df.dart$3acore.Iterable.take$tc, i64 1309726782632086582, ptr @df.dart$3acore.Iterable.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3acore.Iterable.toList$c, i64 1890975232377856814, ptr @df.dart$3acore.Iterable.map$c, i64 3251101298082571214, ptr @df.dart$3acore.Iterable.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4584568332005005361, ptr @df.dart$3acore.Iterable.contains$c, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3acore.Iterable.join$c, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3a_internal.MappedIterable() {
b0:
  ret ptr @df.mt.dart$3a_internal.MappedIterable$d
}
@df.mt.dart$3a_internal.EfficientLengthMappedIterable$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 271, i64 25, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -7142806495848668844, ptr @df.dart$3a_internal.MappedIterable.last$g, i64 -7048868133546680485, ptr @df.dart$3acore.Iterable.toList$tc, i64 -6880024560892829041, ptr @df.dart$3acore.Iterable.skip$c, i64 -6565620648322651272, ptr @df.dart$3a_internal.MappedIterable.length$g, i64 -6455655928913991845, ptr @df.dart$3acore.Iterable.take$c, i64 -5476269667379286226, ptr @df.dart$3a_internal.MappedIterable.iterator$g, i64 -4183823290162052582, ptr @df.dart$3acore.Iterable.join$tc, i64 -3445551396850951156, ptr @df.dart$3acore.Iterable.toString$c, i64 -3444103220339216083, ptr @df.dart$3a_internal.MappedIterable.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3a_internal.MappedIterable.elementAt$c, i64 -2322265645133230011, ptr @df.dart$3acore.Iterable.skip$tc, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -730073319095210781, ptr @df.dart$3a_internal.MappedIterable.elementAt$tc, i64 590583546444750725, ptr @df.dart$3acore.Iterable.take$tc, i64 1309726782632086582, ptr @df.dart$3acore.Iterable.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3acore.Iterable.toList$c, i64 1890975232377856814, ptr @df.dart$3acore.Iterable.map$c, i64 3251101298082571214, ptr @df.dart$3acore.Iterable.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4584568332005005361, ptr @df.dart$3acore.Iterable.contains$c, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3acore.Iterable.join$c, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3a_internal.EfficientLengthMappedIterable() {
b0:
  ret ptr @df.mt.dart$3a_internal.EfficientLengthMappedIterable$d
}
@df.mt.dart$3a_internal.MappedIterator$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 298, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -5038376148439920376, ptr @df.dart$3a_internal.MappedIterator.moveNext$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 1052728634250411761, ptr @df.dart$3a_internal.MappedIterator.current$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3a_internal.MappedIterator() {
b0:
  ret ptr @df.mt.dart$3a_internal.MappedIterator$d
}
@df.mt.dart$3a_internal.MappedListIterable$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 299, i64 25, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -7142806495848668844, ptr @df.dart$3a_internal.ListIterable.last$g, i64 -7048868133546680485, ptr @df.dart$3a_internal.ListIterable.toList$tc, i64 -6880024560892829041, ptr @df.dart$3a_internal.ListIterable.skip$c, i64 -6565620648322651272, ptr @df.dart$3a_internal.MappedListIterable.length$g, i64 -6455655928913991845, ptr @df.dart$3a_internal.ListIterable.take$c, i64 -5476269667379286226, ptr @df.dart$3a_internal.ListIterable.iterator$g, i64 -4183823290162052582, ptr @df.dart$3a_internal.ListIterable.join$tc, i64 -3445551396850951156, ptr @df.dart$3acore.Iterable.toString$c, i64 -3444103220339216083, ptr @df.dart$3a_internal.ListIterable.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3a_internal.MappedListIterable.elementAt$c, i64 -2322265645133230011, ptr @df.dart$3a_internal.ListIterable.skip$tc, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -730073319095210781, ptr @df.dart$3a_internal.MappedListIterable.elementAt$tc, i64 590583546444750725, ptr @df.dart$3a_internal.ListIterable.take$tc, i64 1309726782632086582, ptr @df.dart$3acore.Iterable.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3a_internal.ListIterable.toList$c, i64 1890975232377856814, ptr @df.dart$3a_internal.ListIterable.map$c, i64 3251101298082571214, ptr @df.dart$3a_internal.ListIterable.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4584568332005005361, ptr @df.dart$3a_internal.ListIterable.contains$c, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3a_internal.ListIterable.join$c, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3a_internal.MappedListIterable() {
b0:
  ret ptr @df.mt.dart$3a_internal.MappedListIterable$d
}
@df.mt.dart$3a_internal.WhereIterable$d = private unnamed_addr constant { i64, i64 } { i64 326, i64 0 }
define ptr @df.mt.dart$3a_internal.WhereIterable() {
b0:
  ret ptr @df.mt.dart$3a_internal.WhereIterable$d
}
@df.mt.dart$3a_internal.WhereIterator$d = private unnamed_addr constant { i64, i64 } { i64 327, i64 0 }
define ptr @df.mt.dart$3a_internal.WhereIterator() {
b0:
  ret ptr @df.mt.dart$3a_internal.WhereIterator$d
}
@df.mt.dart$3a_internal.ExpandIterable$d = private unnamed_addr constant { i64, i64 } { i64 276, i64 0 }
define ptr @df.mt.dart$3a_internal.ExpandIterable() {
b0:
  ret ptr @df.mt.dart$3a_internal.ExpandIterable$d
}
@df.mt.dart$3a_internal.ExpandIterator$d = private unnamed_addr constant { i64, i64 } { i64 277, i64 0 }
define ptr @df.mt.dart$3a_internal.ExpandIterator() {
b0:
  ret ptr @df.mt.dart$3a_internal.ExpandIterator$d
}
@df.mt.dart$3a_internal.TakeIterable$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 316, i64 25, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -7142806495848668844, ptr @df.dart$3acore.Iterable.last$g, i64 -7048868133546680485, ptr @df.dart$3acore.Iterable.toList$tc, i64 -6880024560892829041, ptr @df.dart$3acore.Iterable.skip$c, i64 -6565620648322651272, ptr @df.dart$3acore.Iterable.length$g, i64 -6455655928913991845, ptr @df.dart$3acore.Iterable.take$c, i64 -5476269667379286226, ptr @df.dart$3a_internal.TakeIterable.iterator$g, i64 -4183823290162052582, ptr @df.dart$3acore.Iterable.join$tc, i64 -3445551396850951156, ptr @df.dart$3acore.Iterable.toString$c, i64 -3444103220339216083, ptr @df.dart$3acore.Iterable.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3acore.Iterable.elementAt$c, i64 -2322265645133230011, ptr @df.dart$3acore.Iterable.skip$tc, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -730073319095210781, ptr @df.dart$3acore.Iterable.elementAt$tc, i64 590583546444750725, ptr @df.dart$3acore.Iterable.take$tc, i64 1309726782632086582, ptr @df.dart$3acore.Iterable.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3acore.Iterable.toList$c, i64 1890975232377856814, ptr @df.dart$3acore.Iterable.map$c, i64 3251101298082571214, ptr @df.dart$3acore.Iterable.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4584568332005005361, ptr @df.dart$3acore.Iterable.contains$c, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3acore.Iterable.join$c, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3a_internal.TakeIterable() {
b0:
  ret ptr @df.mt.dart$3a_internal.TakeIterable$d
}
@df.mt.dart$3a_internal.EfficientLengthTakeIterable$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 273, i64 25, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -7142806495848668844, ptr @df.dart$3acore.Iterable.last$g, i64 -7048868133546680485, ptr @df.dart$3acore.Iterable.toList$tc, i64 -6880024560892829041, ptr @df.dart$3acore.Iterable.skip$c, i64 -6565620648322651272, ptr @df.dart$3a_internal.EfficientLengthTakeIterable.length$g, i64 -6455655928913991845, ptr @df.dart$3acore.Iterable.take$c, i64 -5476269667379286226, ptr @df.dart$3a_internal.TakeIterable.iterator$g, i64 -4183823290162052582, ptr @df.dart$3acore.Iterable.join$tc, i64 -3445551396850951156, ptr @df.dart$3acore.Iterable.toString$c, i64 -3444103220339216083, ptr @df.dart$3acore.Iterable.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3acore.Iterable.elementAt$c, i64 -2322265645133230011, ptr @df.dart$3acore.Iterable.skip$tc, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -730073319095210781, ptr @df.dart$3acore.Iterable.elementAt$tc, i64 590583546444750725, ptr @df.dart$3acore.Iterable.take$tc, i64 1309726782632086582, ptr @df.dart$3acore.Iterable.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3acore.Iterable.toList$c, i64 1890975232377856814, ptr @df.dart$3acore.Iterable.map$c, i64 3251101298082571214, ptr @df.dart$3acore.Iterable.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4584568332005005361, ptr @df.dart$3acore.Iterable.contains$c, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3acore.Iterable.join$c, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3a_internal.EfficientLengthTakeIterable() {
b0:
  ret ptr @df.mt.dart$3a_internal.EfficientLengthTakeIterable$d
}
@df.mt.dart$3a_internal.TakeIterator$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 317, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -5038376148439920376, ptr @df.dart$3a_internal.TakeIterator.moveNext$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 1052728634250411761, ptr @df.dart$3a_internal.TakeIterator.current$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3a_internal.TakeIterator() {
b0:
  ret ptr @df.mt.dart$3a_internal.TakeIterator$d
}
@df.mt.dart$3a_internal.TakeWhileIterable$d = private unnamed_addr constant { i64, i64 } { i64 318, i64 0 }
define ptr @df.mt.dart$3a_internal.TakeWhileIterable() {
b0:
  ret ptr @df.mt.dart$3a_internal.TakeWhileIterable$d
}
@df.mt.dart$3a_internal.TakeWhileIterator$d = private unnamed_addr constant { i64, i64 } { i64 319, i64 0 }
define ptr @df.mt.dart$3a_internal.TakeWhileIterator() {
b0:
  ret ptr @df.mt.dart$3a_internal.TakeWhileIterator$d
}
@df.mt.dart$3a_internal.SkipIterable$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 308, i64 25, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -7142806495848668844, ptr @df.dart$3acore.Iterable.last$g, i64 -7048868133546680485, ptr @df.dart$3acore.Iterable.toList$tc, i64 -6880024560892829041, ptr @df.dart$3a_internal.SkipIterable.skip$c, i64 -6565620648322651272, ptr @df.dart$3acore.Iterable.length$g, i64 -6455655928913991845, ptr @df.dart$3acore.Iterable.take$c, i64 -5476269667379286226, ptr @df.dart$3a_internal.SkipIterable.iterator$g, i64 -4183823290162052582, ptr @df.dart$3acore.Iterable.join$tc, i64 -3445551396850951156, ptr @df.dart$3acore.Iterable.toString$c, i64 -3444103220339216083, ptr @df.dart$3acore.Iterable.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3acore.Iterable.elementAt$c, i64 -2322265645133230011, ptr @df.dart$3a_internal.SkipIterable.skip$tc, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -730073319095210781, ptr @df.dart$3acore.Iterable.elementAt$tc, i64 590583546444750725, ptr @df.dart$3acore.Iterable.take$tc, i64 1309726782632086582, ptr @df.dart$3acore.Iterable.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3acore.Iterable.toList$c, i64 1890975232377856814, ptr @df.dart$3acore.Iterable.map$c, i64 3251101298082571214, ptr @df.dart$3acore.Iterable.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4584568332005005361, ptr @df.dart$3acore.Iterable.contains$c, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3acore.Iterable.join$c, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3a_internal.SkipIterable() {
b0:
  ret ptr @df.mt.dart$3a_internal.SkipIterable$d
}
@df.mt.dart$3a_internal.EfficientLengthSkipIterable$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 272, i64 25, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -7142806495848668844, ptr @df.dart$3acore.Iterable.last$g, i64 -7048868133546680485, ptr @df.dart$3acore.Iterable.toList$tc, i64 -6880024560892829041, ptr @df.dart$3a_internal.EfficientLengthSkipIterable.skip$c, i64 -6565620648322651272, ptr @df.dart$3a_internal.EfficientLengthSkipIterable.length$g, i64 -6455655928913991845, ptr @df.dart$3acore.Iterable.take$c, i64 -5476269667379286226, ptr @df.dart$3a_internal.SkipIterable.iterator$g, i64 -4183823290162052582, ptr @df.dart$3acore.Iterable.join$tc, i64 -3445551396850951156, ptr @df.dart$3acore.Iterable.toString$c, i64 -3444103220339216083, ptr @df.dart$3acore.Iterable.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3acore.Iterable.elementAt$c, i64 -2322265645133230011, ptr @df.dart$3a_internal.EfficientLengthSkipIterable.skip$tc, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -730073319095210781, ptr @df.dart$3acore.Iterable.elementAt$tc, i64 590583546444750725, ptr @df.dart$3acore.Iterable.take$tc, i64 1309726782632086582, ptr @df.dart$3acore.Iterable.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3acore.Iterable.toList$c, i64 1890975232377856814, ptr @df.dart$3acore.Iterable.map$c, i64 3251101298082571214, ptr @df.dart$3acore.Iterable.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4584568332005005361, ptr @df.dart$3acore.Iterable.contains$c, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3acore.Iterable.join$c, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3a_internal.EfficientLengthSkipIterable() {
b0:
  ret ptr @df.mt.dart$3a_internal.EfficientLengthSkipIterable$d
}
@df.mt.dart$3a_internal.SkipIterator$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 309, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -5038376148439920376, ptr @df.dart$3a_internal.SkipIterator.moveNext$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 1052728634250411761, ptr @df.dart$3a_internal.SkipIterator.current$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3a_internal.SkipIterator() {
b0:
  ret ptr @df.mt.dart$3a_internal.SkipIterator$d
}
@df.mt.dart$3a_internal.SkipWhileIterable$d = private unnamed_addr constant { i64, i64 } { i64 310, i64 0 }
define ptr @df.mt.dart$3a_internal.SkipWhileIterable() {
b0:
  ret ptr @df.mt.dart$3a_internal.SkipWhileIterable$d
}
@df.mt.dart$3a_internal.SkipWhileIterator$d = private unnamed_addr constant { i64, i64 } { i64 311, i64 0 }
define ptr @df.mt.dart$3a_internal.SkipWhileIterator() {
b0:
  ret ptr @df.mt.dart$3a_internal.SkipWhileIterator$d
}
@df.mt.dart$3a_internal.EmptyIterable$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 274, i64 25, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -7142806495848668844, ptr @df.dart$3a_internal.EmptyIterable.last$g, i64 -7048868133546680485, ptr @df.dart$3a_internal.EmptyIterable.toList$tc, i64 -6880024560892829041, ptr @df.dart$3a_internal.EmptyIterable.skip$c, i64 -6565620648322651272, ptr @df.dart$3a_internal.EmptyIterable.length$g, i64 -6455655928913991845, ptr @df.dart$3a_internal.EmptyIterable.take$c, i64 -5476269667379286226, ptr @df.dart$3a_internal.EmptyIterable.iterator$g, i64 -4183823290162052582, ptr @df.dart$3a_internal.EmptyIterable.join$tc, i64 -3445551396850951156, ptr @df.dart$3acore.Iterable.toString$c, i64 -3444103220339216083, ptr @df.dart$3a_internal.EmptyIterable.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3a_internal.EmptyIterable.elementAt$c, i64 -2322265645133230011, ptr @df.dart$3a_internal.EmptyIterable.skip$tc, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -730073319095210781, ptr @df.dart$3a_internal.EmptyIterable.elementAt$tc, i64 590583546444750725, ptr @df.dart$3a_internal.EmptyIterable.take$tc, i64 1309726782632086582, ptr @df.dart$3acore.Iterable.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3a_internal.EmptyIterable.toList$c, i64 1890975232377856814, ptr @df.dart$3a_internal.EmptyIterable.map$c, i64 3251101298082571214, ptr @df.dart$3a_internal.EmptyIterable.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4584568332005005361, ptr @df.dart$3a_internal.EmptyIterable.contains$c, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3a_internal.EmptyIterable.join$c, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3a_internal.EmptyIterable() {
b0:
  ret ptr @df.mt.dart$3a_internal.EmptyIterable$d
}
@df.mt.dart$3a_internal.EmptyIterator$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 275, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -5038376148439920376, ptr @df.dart$3a_internal.EmptyIterator.moveNext$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 1052728634250411761, ptr @df.dart$3a_internal.EmptyIterator.current$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3a_internal.EmptyIterator() {
b0:
  ret ptr @df.mt.dart$3a_internal.EmptyIterator$d
}
@df.mt.dart$3a_internal.FollowedByIterable$d = private unnamed_addr constant { i64, i64 } { i64 283, i64 0 }
define ptr @df.mt.dart$3a_internal.FollowedByIterable() {
b0:
  ret ptr @df.mt.dart$3a_internal.FollowedByIterable$d
}
@df.mt.dart$3a_internal.EfficientLengthFollowedByIterable$d = private unnamed_addr constant { i64, i64 } { i64 268, i64 0 }
define ptr @df.mt.dart$3a_internal.EfficientLengthFollowedByIterable() {
b0:
  ret ptr @df.mt.dart$3a_internal.EfficientLengthFollowedByIterable$d
}
@df.mt.dart$3a_internal.FollowedByIterator$d = private unnamed_addr constant { i64, i64 } { i64 284, i64 0 }
define ptr @df.mt.dart$3a_internal.FollowedByIterator() {
b0:
  ret ptr @df.mt.dart$3a_internal.FollowedByIterator$d
}
@df.mt.dart$3a_internal.WhereTypeIterable$d = private unnamed_addr constant { i64, i64 } { i64 328, i64 0 }
define ptr @df.mt.dart$3a_internal.WhereTypeIterable() {
b0:
  ret ptr @df.mt.dart$3a_internal.WhereTypeIterable$d
}
@df.mt.dart$3a_internal.WhereTypeIterator$d = private unnamed_addr constant { i64, i64 } { i64 329, i64 0 }
define ptr @df.mt.dart$3a_internal.WhereTypeIterator() {
b0:
  ret ptr @df.mt.dart$3a_internal.WhereTypeIterator$d
}
@df.mt.dart$3a_internal.NonNullsIterable$d = private unnamed_addr constant { i64, i64 } { i64 301, i64 0 }
define ptr @df.mt.dart$3a_internal.NonNullsIterable() {
b0:
  ret ptr @df.mt.dart$3a_internal.NonNullsIterable$d
}
@df.mt.dart$3a_internal.NonNullsIterator$d = private unnamed_addr constant { i64, i64 } { i64 302, i64 0 }
define ptr @df.mt.dart$3a_internal.NonNullsIterator() {
b0:
  ret ptr @df.mt.dart$3a_internal.NonNullsIterator$d
}
@df.mt.dart$3a_internal.IndexedIterable$d = private unnamed_addr constant { i64, i64 } { i64 287, i64 0 }
define ptr @df.mt.dart$3a_internal.IndexedIterable() {
b0:
  ret ptr @df.mt.dart$3a_internal.IndexedIterable$d
}
@df.mt.dart$3a_internal.EfficientLengthIndexedIterable$d = private unnamed_addr constant { i64, i64 } { i64 269, i64 0 }
define ptr @df.mt.dart$3a_internal.EfficientLengthIndexedIterable() {
b0:
  ret ptr @df.mt.dart$3a_internal.EfficientLengthIndexedIterable$d
}
@df.mt.dart$3a_internal.IndexedIterator$d = private unnamed_addr constant { i64, i64 } { i64 288, i64 0 }
define ptr @df.mt.dart$3a_internal.IndexedIterator() {
b0:
  ret ptr @df.mt.dart$3a_internal.IndexedIterator$d
}
@df.mt.dart$3a_internal._ListIndicesIterable$d = private unnamed_addr constant { i64, i64 } { i64 336, i64 0 }
define ptr @df.mt.dart$3a_internal._ListIndicesIterable() {
b0:
  ret ptr @df.mt.dart$3a_internal._ListIndicesIterable$d
}
@df.mt.dart$3a_internal.ListMapView$d = private unnamed_addr constant { i64, i64 } { i64 295, i64 0 }
define ptr @df.mt.dart$3a_internal.ListMapView() {
b0:
  ret ptr @df.mt.dart$3a_internal.ListMapView$d
}
@df.mt.dart$3a_internal.ReversedListIterable$d = private unnamed_addr constant { i64, i64 } { i64 305, i64 0 }
define ptr @df.mt.dart$3a_internal.ReversedListIterable() {
b0:
  ret ptr @df.mt.dart$3a_internal.ReversedListIterable$d
}
@df.mt.dart$3a_internal.LinkedList$d = private unnamed_addr constant { i64, i64 } { i64 291, i64 0 }
define ptr @df.mt.dart$3a_internal.LinkedList() {
b0:
  ret ptr @df.mt.dart$3a_internal.LinkedList$d
}
@df.mt.dart$3a_internal.LinkedListEntry$d = private unnamed_addr constant { i64, i64 } { i64 292, i64 0 }
define ptr @df.mt.dart$3a_internal.LinkedListEntry() {
b0:
  ret ptr @df.mt.dart$3a_internal.LinkedListEntry$d
}
@df.mt.dart$3a_internal._LinkedListIterator$d = private unnamed_addr constant { i64, i64 } { i64 335, i64 0 }
define ptr @df.mt.dart$3a_internal._LinkedListIterator() {
b0:
  ret ptr @df.mt.dart$3a_internal._LinkedListIterator$d
}
@df.mt.dart$3a_internal._Patch$d = private unnamed_addr constant { i64, i64 } { i64 337, i64 0 }
define ptr @df.mt.dart$3a_internal._Patch() {
b0:
  ret ptr @df.mt.dart$3a_internal._Patch$d
}
@df.mt.dart$3a_internal.Sort$d = private unnamed_addr constant { i64, i64 } { i64 312, i64 0 }
define ptr @df.mt.dart$3a_internal.Sort() {
b0:
  ret ptr @df.mt.dart$3a_internal.Sort$d
}
@df.mt.dart$3a_internal.Symbol$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 314, i64 7, i64 -9163797671095228218, ptr @df.dart$3a_internal.Symbol.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3a_internal.Symbol.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3a_internal.Symbol.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3a_internal.Symbol() {
b0:
  ret ptr @df.mt.dart$3a_internal.Symbol$d
}
@df.mt.dart$3a_internal.VMLibraryHooks$d = private unnamed_addr constant { i64, i64 } { i64 325, i64 0 }
define ptr @df.mt.dart$3a_internal.VMLibraryHooks() {
b0:
  ret ptr @df.mt.dart$3a_internal.VMLibraryHooks$d
}
@df.mt.dart$3a_internal.Lists$d = private unnamed_addr constant { i64, i64 } { i64 296, i64 0 }
define ptr @df.mt.dart$3a_internal.Lists() {
b0:
  ret ptr @df.mt.dart$3a_internal.Lists$d
}
@df.mt.dart$3a_internal.FinalizerBase$d = private unnamed_addr constant { i64, i64 } { i64 279, i64 0 }
define ptr @df.mt.dart$3a_internal.FinalizerBase() {
b0:
  ret ptr @df.mt.dart$3a_internal.FinalizerBase$d
}
@df.mt.dart$3a_internal.FinalizerEntry$d = private unnamed_addr constant { i64, i64 } { i64 280, i64 0 }
define ptr @df.mt.dart$3a_internal.FinalizerEntry() {
b0:
  ret ptr @df.mt.dart$3a_internal.FinalizerEntry$d
}
@df.mt.dart$3a_internal.ClassID$d = private unnamed_addr constant { i64, i64 } { i64 265, i64 0 }
define ptr @df.mt.dart$3a_internal.ClassID() {
b0:
  ret ptr @df.mt.dart$3a_internal.ClassID$d
}
@df.mt.dart$3acore.Deprecated$d = private unnamed_addr constant { i64, i64 } { i64 583, i64 0 }
define ptr @df.mt.dart$3acore.Deprecated() {
b0:
  ret ptr @df.mt.dart$3acore.Deprecated$d
}
@df.mt.dart$3acore._Override$d = private unnamed_addr constant { i64, i64 } { i64 653, i64 0 }
define ptr @df.mt.dart$3acore._Override() {
b0:
  ret ptr @df.mt.dart$3acore._Override$d
}
@df.mt.dart$3acore.pragma$d = private unnamed_addr constant { i64, i64 } { i64 676, i64 0 }
define ptr @df.mt.dart$3acore.pragma() {
b0:
  ret ptr @df.mt.dart$3acore.pragma$d
}
@df.mt.dart$3acore.bool$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 5, i64 7, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.bool.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.bool.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.bool._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore.bool() {
b0:
  ret ptr @df.mt.dart$3acore.bool$d
}
@df.mt.dart$3acore.DateTime$d = private unnamed_addr constant { i64, i64 } { i64 582, i64 0 }
define ptr @df.mt.dart$3acore.DateTime() {
b0:
  ret ptr @df.mt.dart$3acore.DateTime$d
}
@df.mt.dart$3acore.Duration$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 584, i64 22, i64 -9163797671095228218, ptr @df.dart$3acore.Duration.$3d$3d$c, i64 -8984386194205794907, ptr @df.dart$3acore.Duration.inMilliseconds$g, i64 -8605601643615677530, ptr @df.dart$3acore.Duration.inMicroseconds$g, i64 -7706065890611529093, ptr @df.dart$3acore.Duration.isNegative$g, i64 -4020826134895005383, ptr @df.dart$3acore.Duration.$2d$tc, i64 -4020825035383377172, ptr @df.dart$3acore.Duration.$2a$tc, i64 -4020823935871748961, ptr @df.dart$3acore.Duration.$2b$tc, i64 -4020811841243838640, ptr @df.dart$3acore.Duration.$3e$tc, i64 -4020809642220582218, ptr @df.dart$3acore.Duration.$3c$tc, i64 -3445551396850951156, ptr @df.dart$3acore.Duration.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -678006041086143636, ptr @df.dart$3acore.Duration.$3c$c, i64 -678003842062887214, ptr @df.dart$3acore.Duration.$3e$c, i64 -677990647923348682, ptr @df.dart$3acore.Duration.$2a$c, i64 -677989548411720471, ptr @df.dart$3acore.Duration.$2b$c, i64 -677987349388464049, ptr @df.dart$3acore.Duration.$2d$c, i64 2896079652477072013, ptr @df.dart$3acore.Duration.$7e$2f$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Duration.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 9222726150749128103, ptr @df.dart$3acore.Duration.$7e$2f$c }
define ptr @df.mt.dart$3acore.Duration() {
b0:
  ret ptr @df.mt.dart$3acore.Duration$d
}
@df.mt.dart$3acore.Error$d = private unnamed_addr constant { i64, i64 } { i64 586, i64 0 }
define ptr @df.mt.dart$3acore.Error() {
b0:
  ret ptr @df.mt.dart$3acore.Error$d
}
@df.mt.dart$3acore.AssertionError$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 578, i64 10, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8460972710066630285, ptr @df.dart$3acore.AssertionError.message$g, i64 -4713017734788692867, ptr @df.dart$3acore.Error.stackTrace$g, i64 -3445551396850951156, ptr @df.dart$3acore.AssertionError.toString$c, i64 -2772688926328976598, ptr @df.dart$3acore.Error._stackTrace$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore.AssertionError() {
b0:
  ret ptr @df.mt.dart$3acore.AssertionError$d
}
@df.mt.dart$3acore.TypeError$d = private unnamed_addr constant { i64, i64 } { i64 622, i64 0 }
define ptr @df.mt.dart$3acore.TypeError() {
b0:
  ret ptr @df.mt.dart$3acore.TypeError$d
}
@df.mt.dart$3acore.ArgumentError$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 577, i64 14, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8460972710066630285, ptr @df.dart$3acore.ArgumentError.message$g, i64 -6451786132744734646, ptr @df.dart$3acore.ArgumentError._errorExplanation$g, i64 -4713017734788692867, ptr @df.dart$3acore.Error.stackTrace$g, i64 -3445551396850951156, ptr @df.dart$3acore.ArgumentError.toString$c, i64 -2917121967835686444, ptr @df.dart$3acore.ArgumentError._errorName$g, i64 -2772688926328976598, ptr @df.dart$3acore.Error._stackTrace$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1086115141751169460, ptr @df.dart$3acore.ArgumentError.invalidValue$g, i64 494151758419248719, ptr @df.dart$3acore.ArgumentError.name$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore.ArgumentError() {
b0:
  ret ptr @df.mt.dart$3acore.ArgumentError$d
}
@df.mt.dart$3acore.RangeError$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 605, i64 16, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8460972710066630285, ptr @df.dart$3acore.ArgumentError.message$g, i64 -6451786132744734646, ptr @df.dart$3acore.RangeError._errorExplanation$g, i64 -4713017734788692867, ptr @df.dart$3acore.Error.stackTrace$g, i64 -3445551396850951156, ptr @df.dart$3acore.ArgumentError.toString$c, i64 -2917121967835686444, ptr @df.dart$3acore.RangeError._errorName$g, i64 -2772688926328976598, ptr @df.dart$3acore.Error._stackTrace$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1086115141751169460, ptr @df.dart$3acore.RangeError.invalidValue$g, i64 491505953491204280, ptr @df.dart$3acore.RangeError.start$g, i64 494151758419248719, ptr @df.dart$3acore.ArgumentError.name$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4304133201855208329, ptr @df.dart$3acore.RangeError.end$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore.RangeError() {
b0:
  ret ptr @df.mt.dart$3acore.RangeError$d
}
@df.mt.dart$3acore.IndexError$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 592, i64 17, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8460972710066630285, ptr @df.dart$3acore.ArgumentError.message$g, i64 -6565620648322651272, ptr @df.dart$3acore.IndexError.length$g, i64 -6451786132744734646, ptr @df.dart$3acore.IndexError._errorExplanation$g, i64 -4713017734788692867, ptr @df.dart$3acore.Error.stackTrace$g, i64 -3445551396850951156, ptr @df.dart$3acore.ArgumentError.toString$c, i64 -2917121967835686444, ptr @df.dart$3acore.IndexError._errorName$g, i64 -2772688926328976598, ptr @df.dart$3acore.Error._stackTrace$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1086115141751169460, ptr @df.dart$3acore.IndexError.invalidValue$g, i64 491505953491204280, ptr @df.dart$3acore.IndexError.start$g, i64 494151758419248719, ptr @df.dart$3acore.ArgumentError.name$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4304133201855208329, ptr @df.dart$3acore.IndexError.end$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore.IndexError() {
b0:
  ret ptr @df.mt.dart$3acore.IndexError$d
}
@df.mt.dart$3acore.NoSuchMethodError$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 601, i64 11, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -7741363322340457002, ptr @df.dart$3acore.NoSuchMethodError._receiver$g, i64 -4713017734788692867, ptr @df.dart$3acore.Error.stackTrace$g, i64 -3445551396850951156, ptr @df.dart$3acore.NoSuchMethodError.toString$c, i64 -2772688926328976598, ptr @df.dart$3acore.Error._stackTrace$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 6631225139736982849, ptr @df.dart$3acore.NoSuchMethodError._invocation$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore.NoSuchMethodError() {
b0:
  ret ptr @df.mt.dart$3acore.NoSuchMethodError$d
}
@df.mt.dart$3acore.UnsupportedError$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 624, i64 10, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8460972710066630285, ptr @df.dart$3acore.UnsupportedError.message$g, i64 -4713017734788692867, ptr @df.dart$3acore.Error.stackTrace$g, i64 -3445551396850951156, ptr @df.dart$3acore.UnsupportedError.toString$c, i64 -2772688926328976598, ptr @df.dart$3acore.Error._stackTrace$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore.UnsupportedError() {
b0:
  ret ptr @df.mt.dart$3acore.UnsupportedError$d
}
@df.mt.dart$3acore.UnimplementedError$d = private unnamed_addr constant { i64, i64 } { i64 623, i64 0 }
define ptr @df.mt.dart$3acore.UnimplementedError() {
b0:
  ret ptr @df.mt.dart$3acore.UnimplementedError$d
}
@df.mt.dart$3acore.StateError$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 615, i64 10, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8460972710066630285, ptr @df.dart$3acore.StateError.message$g, i64 -4713017734788692867, ptr @df.dart$3acore.Error.stackTrace$g, i64 -3445551396850951156, ptr @df.dart$3acore.StateError.toString$c, i64 -2772688926328976598, ptr @df.dart$3acore.Error._stackTrace$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore.StateError() {
b0:
  ret ptr @df.mt.dart$3acore.StateError$d
}
@df.mt.dart$3acore.ConcurrentModificationError$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 581, i64 10, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -4713017734788692867, ptr @df.dart$3acore.Error.stackTrace$g, i64 -3445551396850951156, ptr @df.dart$3acore.ConcurrentModificationError.toString$c, i64 -2772688926328976598, ptr @df.dart$3acore.Error._stackTrace$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -705102976316160808, ptr @df.dart$3acore.ConcurrentModificationError.modifiedObject$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore.ConcurrentModificationError() {
b0:
  ret ptr @df.mt.dart$3acore.ConcurrentModificationError$d
}
@df.mt.dart$3acore.OutOfMemoryError$d = private unnamed_addr constant { i64, i64 } { i64 603, i64 0 }
define ptr @df.mt.dart$3acore.OutOfMemoryError() {
b0:
  ret ptr @df.mt.dart$3acore.OutOfMemoryError$d
}
@df.mt.dart$3acore.StackOverflowError$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 613, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -4713017734788692867, ptr @df.dart$3acore.StackOverflowError.stackTrace$g, i64 -3445551396850951156, ptr @df.dart$3acore.StackOverflowError.toString$c, i64 -2772688926328976598, ptr @df.dart$3acore.StackOverflowError._stackTrace$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore.StackOverflowError() {
b0:
  ret ptr @df.mt.dart$3acore.StackOverflowError$d
}
@df.mt.dart$3acore._Exception$d = private unnamed_addr constant { i64, i64 } { i64 643, i64 0 }
define ptr @df.mt.dart$3acore._Exception() {
b0:
  ret ptr @df.mt.dart$3acore._Exception$d
}
@df.mt.dart$3acore.FormatException$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 590, i64 10, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8473324130411775375, ptr @df.dart$3acore.FormatException.source$g, i64 -8460972710066630285, ptr @df.dart$3acore.FormatException.message$g, i64 -7649473588204813841, ptr @df.dart$3acore.FormatException.offset$g, i64 -3445551396850951156, ptr @df.dart$3acore.FormatException.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore.FormatException() {
b0:
  ret ptr @df.mt.dart$3acore.FormatException$d
}
@df.mt.dart$3acore.IntegerDivisionByZeroException$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 593, i64 10, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8460972710066630285, ptr @df.dart$3acore.IntegerDivisionByZeroException.message$g, i64 -4713017734788692867, ptr @df.dart$3acore.IntegerDivisionByZeroException.stackTrace$g, i64 -3445551396850951156, ptr @df.dart$3acore.IntegerDivisionByZeroException.toString$c, i64 -2772688926328976598, ptr @df.dart$3acore.IntegerDivisionByZeroException._stackTrace$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore.IntegerDivisionByZeroException() {
b0:
  ret ptr @df.mt.dart$3acore.IntegerDivisionByZeroException$d
}
@df.mt.dart$3acore._Invocation$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 649, i64 13, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -4104913465868088123, ptr @df.dart$3acore._Invocation.memberName$g, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -759841063424813160, ptr @df.dart$3acore._Invocation.typeArguments$g, i64 -76152458149938894, ptr @df.dart$3acore._Invocation.positionalArguments$g, i64 799965402112803395, ptr @df.dart$3acore._Invocation.namedArguments$g, i64 2865099812964054563, ptr @df.dart$3acore._Invocation.isGetter$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5162025842567131371, ptr @df.dart$3acore._Invocation.isAccessor$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore._Invocation() {
b0:
  ret ptr @df.mt.dart$3acore._Invocation$d
}
@df.mt.dart$3acore._GeneratorIterable$d = private unnamed_addr constant { i64, i64 } { i64 646, i64 0 }
define ptr @df.mt.dart$3acore._GeneratorIterable() {
b0:
  ret ptr @df.mt.dart$3acore._GeneratorIterable$d
}
@df.mt.dart$3acore.MapEntry$d = private unnamed_addr constant { i64, i64 } { i64 599, i64 0 }
define ptr @df.mt.dart$3acore.MapEntry() {
b0:
  ret ptr @df.mt.dart$3acore.MapEntry$d
}
@df.mt.dart$3acore.Null$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 1, i64 7, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Null.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Null.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Null._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore.Null() {
b0:
  ret ptr @df.mt.dart$3acore.Null$d
}
@df.mt.dart$3acore.num$d = private unnamed_addr constant { i64, i64 } { i64 675, i64 0 }
define ptr @df.mt.dart$3acore.num() {
b0:
  ret ptr @df.mt.dart$3acore.num$d
}
@df.mt.dart$3acore.Object$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 602, i64 7, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore.Object() {
b0:
  ret ptr @df.mt.dart$3acore.Object$d
}
@df.mt.dart$3acore._StringStackTrace$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 665, i64 7, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore._StringStackTrace.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore._StringStackTrace() {
b0:
  ret ptr @df.mt.dart$3acore._StringStackTrace$d
}
@df.mt.dart$3acore.Stopwatch$d = private unnamed_addr constant { i64, i64 } { i64 616, i64 0 }
define ptr @df.mt.dart$3acore.Stopwatch() {
b0:
  ret ptr @df.mt.dart$3acore.Stopwatch$d
}
@df.mt.dart$3acore.Runes$d = private unnamed_addr constant { i64, i64 } { i64 610, i64 0 }
define ptr @df.mt.dart$3acore.Runes() {
b0:
  ret ptr @df.mt.dart$3acore.Runes$d
}
@df.mt.dart$3acore.RuneIterator$d = private unnamed_addr constant { i64, i64 } { i64 609, i64 0 }
define ptr @df.mt.dart$3acore.RuneIterator() {
b0:
  ret ptr @df.mt.dart$3acore.RuneIterator$d
}
@df.mt.dart$3acore.StringBuffer$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 618, i64 15, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8727612037632705424, ptr @df.dart$3acore.StringBuffer.writeAll$tc, i64 -8386400421705638073, ptr @df.dart$3acore.StringBuffer.write$c, i64 -7031269532819067186, ptr @df.dart$3acore.StringBuffer.writeCharCode$c, i64 -6565620648322651272, ptr @df.dart$3acore.StringBuffer.length$g, i64 -6065592078353237928, ptr @df.dart$3acore.StringBuffer.writeCharCode$tc, i64 -3445551396850951156, ptr @df.dart$3acore.StringBuffer.toString$c, i64 -3444103220339216083, ptr @df.dart$3acore.StringBuffer.isEmpty$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 325461861810005922, ptr @df.dart$3acore.StringBuffer.writeAll$c, i64 1309726782632086582, ptr @df.dart$3acore.StringBuffer.isNotEmpty$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore.StringBuffer() {
b0:
  ret ptr @df.mt.dart$3acore.StringBuffer$d
}
@df.mt.dart$3acore._PlatformUri$d = private unnamed_addr constant { i64, i64 } { i64 654, i64 0 }
define ptr @df.mt.dart$3acore._PlatformUri() {
b0:
  ret ptr @df.mt.dart$3acore._PlatformUri$d
}
@df.mt.dart$3acore._Uri$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 670, i64 26, i64 -9163797671095228218, ptr @df.dart$3acore._Uri.$3d$3d$c, i64 -8778009224422430729, ptr @df.dart$3acore._Uri.isScheme$c, i64 -8329813300488775804, ptr @df.dart$3acore._Uri.hasFragment$g, i64 -7211463475460705446, ptr @df.dart$3acore._Uri.replace$tc, i64 -6782593887510583890, ptr @df.dart$3acore._Uri.resolveUri$c, i64 -6545237696690669517, ptr @df.dart$3acore._Uri.userInfo$g, i64 -6456075568128440506, ptr @df.dart$3acore._Uri.host$g, i64 -4034584598075232417, ptr @df.dart$3acore._Uri.port$g, i64 -3847546679745275184, ptr @df.dart$3acore._Uri.replace$c, i64 -3445551396850951156, ptr @df.dart$3acore._Uri.toString$c, i64 -3437466944945781377, ptr @df.dart$3acore._Uri.hasPort$g, i64 -2471375648839540890, ptr @df.dart$3acore._Uri.hasEmptyPath$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1240726684174744861, ptr @df.dart$3acore._Uri.scheme$g, i64 -789934070429309679, ptr @df.dart$3acore._Uri.hasAuthority$g, i64 -10179980336060438, ptr @df.dart$3acore._Uri.hasAbsolutePath$g, i64 2201403351817896611, ptr @df.dart$3acore._Uri.path$g, i64 3485674878502973057, ptr @df.dart$3acore._Uri.isScheme$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore._Uri.hashCode$g, i64 4340587159967341008, ptr @df.dart$3acore._Uri.hasQuery$g, i64 4386004279140518960, ptr @df.dart$3acore._Uri.query$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5754895719035186276, ptr @df.dart$3acore._Uri.fragment$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 8658569877238363456, ptr @df.dart$3acore._Uri.resolveUri$tc }
define ptr @df.mt.dart$3acore._Uri() {
b0:
  ret ptr @df.mt.dart$3acore._Uri$d
}
@df.mt.dart$3acore.UriData$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 626, i64 8, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -5831654267004812466, ptr @df.dart$3acore.UriData.uri$g, i64 -3445551396850951156, ptr @df.dart$3acore.UriData.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore.UriData() {
b0:
  ret ptr @df.mt.dart$3acore.UriData$d
}
@df.mt.dart$3acore._SimpleUri$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 659, i64 24, i64 -9163797671095228218, ptr @df.dart$3acore._SimpleUri.$3d$3d$c, i64 -8329813300488775804, ptr @df.dart$3acore._SimpleUri.hasFragment$g, i64 -7211463475460705446, ptr @df.dart$3acore._SimpleUri.replace$tc, i64 -6782593887510583890, ptr @df.dart$3acore._SimpleUri.resolveUri$c, i64 -6545237696690669517, ptr @df.dart$3acore._SimpleUri.userInfo$g, i64 -6456075568128440506, ptr @df.dart$3acore._SimpleUri.host$g, i64 -4034584598075232417, ptr @df.dart$3acore._SimpleUri.port$g, i64 -3847546679745275184, ptr @df.dart$3acore._SimpleUri.replace$c, i64 -3445551396850951156, ptr @df.dart$3acore._SimpleUri.toString$c, i64 -3437466944945781377, ptr @df.dart$3acore._SimpleUri.hasPort$g, i64 -2471375648839540890, ptr @df.dart$3acore._SimpleUri.hasEmptyPath$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1240726684174744861, ptr @df.dart$3acore._SimpleUri.scheme$g, i64 -789934070429309679, ptr @df.dart$3acore._SimpleUri.hasAuthority$g, i64 -10179980336060438, ptr @df.dart$3acore._SimpleUri.hasAbsolutePath$g, i64 2201403351817896611, ptr @df.dart$3acore._SimpleUri.path$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore._SimpleUri.hashCode$g, i64 4340587159967341008, ptr @df.dart$3acore._SimpleUri.hasQuery$g, i64 4386004279140518960, ptr @df.dart$3acore._SimpleUri.query$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5754895719035186276, ptr @df.dart$3acore._SimpleUri.fragment$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 8658569877238363456, ptr @df.dart$3acore._SimpleUri.resolveUri$tc }
define ptr @df.mt.dart$3acore._SimpleUri() {
b0:
  ret ptr @df.mt.dart$3acore._SimpleUri$d
}
@df.mt.dart$3acore._DataUri$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 639, i64 26, i64 -9163797671095228218, ptr @df.dart$3acore._Uri.$3d$3d$c, i64 -8778009224422430729, ptr @df.dart$3acore._Uri.isScheme$c, i64 -8329813300488775804, ptr @df.dart$3acore._Uri.hasFragment$g, i64 -7211463475460705446, ptr @df.dart$3acore._Uri.replace$tc, i64 -6782593887510583890, ptr @df.dart$3acore._Uri.resolveUri$c, i64 -6545237696690669517, ptr @df.dart$3acore._Uri.userInfo$g, i64 -6456075568128440506, ptr @df.dart$3acore._Uri.host$g, i64 -4034584598075232417, ptr @df.dart$3acore._Uri.port$g, i64 -3847546679745275184, ptr @df.dart$3acore._Uri.replace$c, i64 -3445551396850951156, ptr @df.dart$3acore._Uri.toString$c, i64 -3437466944945781377, ptr @df.dart$3acore._Uri.hasPort$g, i64 -2471375648839540890, ptr @df.dart$3acore._Uri.hasEmptyPath$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1240726684174744861, ptr @df.dart$3acore._Uri.scheme$g, i64 -789934070429309679, ptr @df.dart$3acore._Uri.hasAuthority$g, i64 -10179980336060438, ptr @df.dart$3acore._Uri.hasAbsolutePath$g, i64 2201403351817896611, ptr @df.dart$3acore._Uri.path$g, i64 3485674878502973057, ptr @df.dart$3acore._Uri.isScheme$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore._Uri.hashCode$g, i64 4340587159967341008, ptr @df.dart$3acore._Uri.hasQuery$g, i64 4386004279140518960, ptr @df.dart$3acore._Uri.query$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5754895719035186276, ptr @df.dart$3acore._Uri.fragment$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 8658569877238363456, ptr @df.dart$3acore._Uri.resolveUri$tc }
define ptr @df.mt.dart$3acore._DataUri() {
b0:
  ret ptr @df.mt.dart$3acore._DataUri$d
}
@df.mt.dart$3acore.Expando$d = private unnamed_addr constant { i64, i64 } { i64 588, i64 0 }
define ptr @df.mt.dart$3acore.Expando() {
b0:
  ret ptr @df.mt.dart$3acore.Expando$d
}
@df.mt.dart$3acore._BigIntImpl$d = private unnamed_addr constant { i64, i64 } { i64 635, i64 0 }
define ptr @df.mt.dart$3acore._BigIntImpl() {
b0:
  ret ptr @df.mt.dart$3acore._BigIntImpl$d
}
@df.mt.dart$3acore._BigIntMontgomeryReduction$d = private unnamed_addr constant { i64, i64 } { i64 636, i64 0 }
define ptr @df.mt.dart$3acore._BigIntMontgomeryReduction() {
b0:
  ret ptr @df.mt.dart$3acore._BigIntMontgomeryReduction$d
}
@df.mt.dart$3acore._BigIntClassicReduction$d = private unnamed_addr constant { i64, i64 } { i64 634, i64 0 }
define ptr @df.mt.dart$3acore._BigIntClassicReduction() {
b0:
  ret ptr @df.mt.dart$3acore._BigIntClassicReduction$d
}
@df.mt.dart$3acore._List$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 8, i64 39, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8971153493902442575, ptr @df.dart$3acore._List.$5b$5d$3d$tc, i64 -7142806495848668844, ptr @df.dart$3acore._Array.last$g, i64 -7048868133546680485, ptr @df.dart$3acore._Array.toList$tc, i64 -6880024560892829041, ptr @df.dart$3acollection.ListBase.skip$c, i64 -6565620648322651272, ptr @df.dart$3acore._Array.length$g, i64 -6455655928913991845, ptr @df.dart$3acollection.ListBase.take$c, i64 -5476269667379286226, ptr @df.dart$3acore._Array.iterator$g, i64 -4183823290162052582, ptr @df.dart$3acollection.ListBase.join$tc, i64 -3445551396850951156, ptr @df.dart$3acollection.ListBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3acollection.ListBase.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3acollection.ListBase.elementAt$c, i64 -2865225933037962029, ptr @df.dart$3acollection.ListBase.indexOf$tc, i64 -2322265645133230011, ptr @df.dart$3acollection.ListBase.skip$tc, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3a_internal.FixedLengthListMixin.remove$c, i64 -921892303864442672, ptr @df.dart$3a_internal.FixedLengthListMixin.removeLast$c, i64 -730073319095210781, ptr @df.dart$3acollection.ListBase.elementAt$tc, i64 -677989548411720471, ptr @df.dart$3acollection.ListBase.$2b$c, i64 -503246348505971594, ptr @df.dart$3acollection.ListBase.fillRange$c, i64 590583546444750725, ptr @df.dart$3acollection.ListBase.take$tc, i64 1309726782632086582, ptr @df.dart$3acollection.ListBase.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3acore._Array.toList$c, i64 1890975232377856814, ptr @df.dart$3acollection.ListBase.map$c, i64 2870274114568068918, ptr @df.dart$3acore._Array.$5b$5d$tc, i64 3251101298082571214, ptr @df.dart$3acore._Array.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4270166662586539371, ptr @df.dart$3a_internal.FixedLengthListMixin.add$c, i64 4584568332005005361, ptr @df.dart$3acollection.ListBase.contains$c, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3acollection.ListBase.join$c, i64 5816122436118806360, ptr @df.dart$3acollection.ListBase.fillRange$tc, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7293158726991237507, ptr @df.dart$3acore._List.setRange$tc, i64 7526586947604351043, ptr @df.dart$3acore._List.$5b$5d$3d$c, i64 7800396592418680749, ptr @df.dart$3acore._List.setRange$c, i64 8310139465989025733, ptr @df.dart$3acollection.ListBase.indexOf$c, i64 9189246021676726028, ptr @df.dart$3acore._Array.$5b$5d$c }
define ptr @df.mt.dart$3acore._List() {
b0:
  ret ptr @df.mt.dart$3acore._List$d
}
@df.mt.dart$3acore._ImmutableList$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 9, i64 39, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8971153493902442575, ptr @df.dart$3a_internal.UnmodifiableListMixin.$5b$5d$3d$tc, i64 -7142806495848668844, ptr @df.dart$3acore._Array.last$g, i64 -7048868133546680485, ptr @df.dart$3acore._Array.toList$tc, i64 -6880024560892829041, ptr @df.dart$3acollection.ListBase.skip$c, i64 -6565620648322651272, ptr @df.dart$3acore._Array.length$g, i64 -6455655928913991845, ptr @df.dart$3acollection.ListBase.take$c, i64 -5476269667379286226, ptr @df.dart$3acore._Array.iterator$g, i64 -4183823290162052582, ptr @df.dart$3acollection.ListBase.join$tc, i64 -3445551396850951156, ptr @df.dart$3acollection.ListBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3acollection.ListBase.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3acollection.ListBase.elementAt$c, i64 -2865225933037962029, ptr @df.dart$3acollection.ListBase.indexOf$tc, i64 -2322265645133230011, ptr @df.dart$3acollection.ListBase.skip$tc, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3a_internal.UnmodifiableListMixin.remove$c, i64 -921892303864442672, ptr @df.dart$3a_internal.UnmodifiableListMixin.removeLast$c, i64 -730073319095210781, ptr @df.dart$3acollection.ListBase.elementAt$tc, i64 -677989548411720471, ptr @df.dart$3acollection.ListBase.$2b$c, i64 -503246348505971594, ptr @df.dart$3a_internal.UnmodifiableListMixin.fillRange$c, i64 590583546444750725, ptr @df.dart$3acollection.ListBase.take$tc, i64 1309726782632086582, ptr @df.dart$3acollection.ListBase.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3acore._Array.toList$c, i64 1890975232377856814, ptr @df.dart$3acollection.ListBase.map$c, i64 2870274114568068918, ptr @df.dart$3acore._Array.$5b$5d$tc, i64 3251101298082571214, ptr @df.dart$3acore._Array.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4270166662586539371, ptr @df.dart$3a_internal.UnmodifiableListMixin.add$c, i64 4584568332005005361, ptr @df.dart$3acollection.ListBase.contains$c, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3acollection.ListBase.join$c, i64 5816122436118806360, ptr @df.dart$3a_internal.UnmodifiableListMixin.fillRange$tc, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7293158726991237507, ptr @df.dart$3a_internal.UnmodifiableListMixin.setRange$tc, i64 7526586947604351043, ptr @df.dart$3a_internal.UnmodifiableListMixin.$5b$5d$3d$c, i64 7800396592418680749, ptr @df.dart$3a_internal.UnmodifiableListMixin.setRange$c, i64 8310139465989025733, ptr @df.dart$3acollection.ListBase.indexOf$c, i64 9189246021676726028, ptr @df.dart$3acore._Array.$5b$5d$c }
define ptr @df.mt.dart$3acore._ImmutableList() {
b0:
  ret ptr @df.mt.dart$3acore._ImmutableList$d
}
@df.mt.dart$3acore._ArrayIterator$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 632, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -5038376148439920376, ptr @df.dart$3acore._ArrayIterator.moveNext$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 1052728634250411761, ptr @df.dart$3acore._ArrayIterator.current$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore._ArrayIterator() {
b0:
  ret ptr @df.mt.dart$3acore._ArrayIterator$d
}
@df.mt.dart$3acore._Double$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 4, i64 44, i64 -9163797671095228218, ptr @df.dart$3acore._Double.$3d$3d$c, i64 -8237661618964817018, ptr @df.dart$3acore._Double._addFromInteger$tc, i64 -7706065890611529093, ptr @df.dart$3acore._Double.isNegative$g, i64 -7599129895765617744, ptr @df.dart$3acore._Double._remainderFromInteger$c, i64 -7095062371641373373, ptr @df.dart$3acore._Double.isFinite$g, i64 -5612894578032499650, ptr @df.dart$3acore._Double._equalToInteger$c, i64 -5179915397299019584, ptr @df.dart$3acore._Double._greaterThanFromInteger$tc, i64 -4318155389668546510, ptr @df.dart$3acore._Double.truncate$c, i64 -4020828333918261805, ptr @df.dart$3acore._Double.$2f$tc, i64 -4020826134895005383, ptr @df.dart$3acore._Double.$2d$tc, i64 -4020825035383377172, ptr @df.dart$3acore._Double.$2a$tc, i64 -4020823935871748961, ptr @df.dart$3acore._Double.$2b$tc, i64 -4020811841243838640, ptr @df.dart$3acore._Double.$3e$tc, i64 -4020809642220582218, ptr @df.dart$3acore._Double.$3c$tc, i64 -3726519281940109379, ptr @df.dart$3acore._Double._subFromInteger$tc, i64 -3445551396850951156, ptr @df.dart$3acore._Double.toString$c, i64 -2936588468885866592, ptr @df.dart$3acore._Double._equalToInteger$tc, i64 -2649732211752220415, ptr @df.dart$3acore._Double._mulFromInteger$tc, i64 -2488972445746378804, ptr @df.dart$3acore._Double.toDouble$c, i64 -2369631776295608608, ptr @df.dart$3acore._Double.round$c, i64 -1610317686921045632, ptr @df.dart$3acore._Double._truncDivFromInteger$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -678006041086143636, ptr @df.dart$3acore._Double.$3c$c, i64 -678003842062887214, ptr @df.dart$3acore._Double.$3e$c, i64 -677990647923348682, ptr @df.dart$3acore._Double.$2a$c, i64 -677989548411720471, ptr @df.dart$3acore._Double.$2b$c, i64 -677987349388464049, ptr @df.dart$3acore._Double.$2d$c, i64 -677985150365207627, ptr @df.dart$3acore._Double.$2f$c, i64 -622352372757107330, ptr @df.dart$3acore._Double._truncDivFromInteger$tc, i64 203890848951367299, ptr @df.dart$3acore._Double._subFromInteger$c, i64 520291628328000545, ptr @df.dart$3acore._Double.isNaN$g, i64 1736290547201802069, ptr @df.dart$3acore._Double.remainder$tc, i64 2468567154877893166, ptr @df.dart$3acore._Double._remainderFromInteger$tc, i64 2896079652477072013, ptr @df.dart$3acore._Double.$7e$2f$tc, i64 3379649470273185486, ptr @df.dart$3acore._Double._greaterThanFromInteger$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore._Double.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore._Double._identityHashCode$g, i64 5852185211741937682, ptr @df.dart$3acore._Double.toInt$c, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7304002064172038551, ptr @df.dart$3acore._Double.remainder$c, i64 7594441835806680532, ptr @df.dart$3acore._Double._addFromInteger$c, i64 8321144794629309927, ptr @df.dart$3acore._Double._mulFromInteger$c, i64 9222726150749128103, ptr @df.dart$3acore._Double.$7e$2f$c }
define ptr @df.mt.dart$3acore._Double() {
b0:
  ret ptr @df.mt.dart$3acore._Double$d
}
@df.mt.dart$3acore._AssertionError$d = private unnamed_addr constant { i64, i64 } { i64 633, i64 0 }
define ptr @df.mt.dart$3acore._AssertionError() {
b0:
  ret ptr @df.mt.dart$3acore._AssertionError$d
}
@df.mt.dart$3acore._TypeError$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 667, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -4713017734788692867, ptr @df.dart$3acore.Error.stackTrace$g, i64 -3445551396850951156, ptr @df.dart$3acore._TypeError.toString$c, i64 -2772688926328976598, ptr @df.dart$3acore.Error._stackTrace$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore._TypeError() {
b0:
  ret ptr @df.mt.dart$3acore._TypeError$d
}
@df.mt.dart$3acore._InternalError$d = private unnamed_addr constant { i64, i64 } { i64 648, i64 0 }
define ptr @df.mt.dart$3acore._InternalError() {
b0:
  ret ptr @df.mt.dart$3acore._InternalError$d
}
@df.mt.dart$3acore._CompileTimeError$d = private unnamed_addr constant { i64, i64 } { i64 638, i64 0 }
define ptr @df.mt.dart$3acore._CompileTimeError() {
b0:
  ret ptr @df.mt.dart$3acore._CompileTimeError$d
}
@df.mt.dart$3acore._DuplicatedFieldInitializerError$d = private unnamed_addr constant { i64, i64 } { i64 641, i64 0 }
define ptr @df.mt.dart$3acore._DuplicatedFieldInitializerError() {
b0:
  ret ptr @df.mt.dart$3acore._DuplicatedFieldInitializerError$d
}
@df.mt.dart$3acore._WeakReference$d = private unnamed_addr constant { i64, i64 } { i64 672, i64 0 }
define ptr @df.mt.dart$3acore._WeakReference() {
b0:
  ret ptr @df.mt.dart$3acore._WeakReference$d
}
@df.mt.dart$3acore._FinalizerImpl$d = private unnamed_addr constant { i64, i64 } { i64 644, i64 0 }
define ptr @df.mt.dart$3acore._FinalizerImpl() {
b0:
  ret ptr @df.mt.dart$3acore._FinalizerImpl$d
}
@df.mt.dart$3acore._Closure$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 11, i64 8, i64 -9163797671095228218, ptr @df.dart$3acore._Closure.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -848235150779141096, ptr @df.dart$3acore._Closure.call$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore._Closure.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore._Closure() {
b0:
  ret ptr @df.mt.dart$3acore._Closure$d
}
@df.mt.dart$3acore._GrowableList$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 10, i64 40, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8971153493902442575, ptr @df.dart$3acore._GrowableList.$5b$5d$3d$tc, i64 -7142806495848668844, ptr @df.dart$3acore._GrowableList.last$g, i64 -7048868133546680485, ptr @df.dart$3acore._GrowableList.toList$tc, i64 -6880024560892829041, ptr @df.dart$3acollection.ListBase.skip$c, i64 -6565620648322651272, ptr @df.dart$3acore._GrowableList.length$g, i64 -6455655928913991845, ptr @df.dart$3acollection.ListBase.take$c, i64 -5476269667379286226, ptr @df.dart$3acore._GrowableList.iterator$g, i64 -4183823290162052582, ptr @df.dart$3acore._GrowableList.join$tc, i64 -3445551396850951156, ptr @df.dart$3acore._GrowableList.toString$c, i64 -3444103220339216083, ptr @df.dart$3acore._GrowableList.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3acore._GrowableList.elementAt$c, i64 -2865225933037962029, ptr @df.dart$3acollection.ListBase.indexOf$tc, i64 -2322265645133230011, ptr @df.dart$3acollection.ListBase.skip$tc, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3acore._GrowableList.remove$c, i64 -921892303864442672, ptr @df.dart$3acore._GrowableList.removeLast$c, i64 -730073319095210781, ptr @df.dart$3acore._GrowableList.elementAt$tc, i64 -677989548411720471, ptr @df.dart$3acollection.ListBase.$2b$c, i64 -503246348505971594, ptr @df.dart$3acollection.ListBase.fillRange$c, i64 590583546444750725, ptr @df.dart$3acollection.ListBase.take$tc, i64 1309726782632086582, ptr @df.dart$3acore._GrowableList.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3acore._GrowableList.toList$c, i64 1890975232377856814, ptr @df.dart$3acollection.ListBase.map$c, i64 2870274114568068918, ptr @df.dart$3acore._GrowableList.$5b$5d$tc, i64 3251101298082571214, ptr @df.dart$3acore._GrowableList.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4270166662586539371, ptr @df.dart$3acore._GrowableList.add$c, i64 4584568332005005361, ptr @df.dart$3acollection.ListBase.contains$c, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3acore._GrowableList.join$c, i64 5816122436118806360, ptr @df.dart$3acollection.ListBase.fillRange$tc, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7293158726991237507, ptr @df.dart$3acollection.ListBase.setRange$tc, i64 7526586947604351043, ptr @df.dart$3acore._GrowableList.$5b$5d$3d$c, i64 7800396592418680749, ptr @df.dart$3acollection.ListBase.setRange$c, i64 8310139465989025733, ptr @df.dart$3acollection.ListBase.indexOf$c, i64 8697599699833847726, ptr @df.dart$3acore._GrowableList.addAll$c, i64 9189246021676726028, ptr @df.dart$3acore._GrowableList.$5b$5d$c }
define ptr @df.mt.dart$3acore._GrowableList() {
b0:
  ret ptr @df.mt.dart$3acore._GrowableList$d
}
@df.mt.dart$3acore._Smi$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 2, i64 48, i64 -9163797671095228218, ptr @df.dart$3acore._IntegerImplementation.$3d$3d$c, i64 -9075490628995950738, ptr @df.dart$3acore._IntegerImplementation.unary$2d$c, i64 -8237661618964817018, ptr @df.dart$3acore._IntegerImplementation._addFromInteger$tc, i64 -7706065890611529093, ptr @df.dart$3acore._IntegerImplementation.isNegative$g, i64 -7599129895765617744, ptr @df.dart$3acore._IntegerImplementation._remainderFromInteger$c, i64 -7095062371641373373, ptr @df.dart$3acore._IntegerImplementation.isFinite$g, i64 -5612894578032499650, ptr @df.dart$3acore._IntegerImplementation._equalToInteger$c, i64 -5179915397299019584, ptr @df.dart$3acore._IntegerImplementation._greaterThanFromInteger$tc, i64 -4318155389668546510, ptr @df.dart$3acore._IntegerImplementation.truncate$c, i64 -4020828333918261805, ptr @df.dart$3acore._IntegerImplementation.$2f$tc, i64 -4020826134895005383, ptr @df.dart$3acore._IntegerImplementation.$2d$tc, i64 -4020825035383377172, ptr @df.dart$3acore._IntegerImplementation.$2a$tc, i64 -4020823935871748961, ptr @df.dart$3acore._IntegerImplementation.$2b$tc, i64 -4020820637336864328, ptr @df.dart$3acore._IntegerImplementation.$26$tc, i64 -4020811841243838640, ptr @df.dart$3acore._IntegerImplementation.$3e$tc, i64 -4020809642220582218, ptr @df.dart$3acore._IntegerImplementation.$3c$tc, i64 -3726519281940109379, ptr @df.dart$3acore._IntegerImplementation._subFromInteger$tc, i64 -3445551396850951156, ptr @df.dart$3acore._Smi.toString$c, i64 -2936588468885866592, ptr @df.dart$3acore._IntegerImplementation._equalToInteger$tc, i64 -2649732211752220415, ptr @df.dart$3acore._IntegerImplementation._mulFromInteger$tc, i64 -2488972445746378804, ptr @df.dart$3acore._IntegerImplementation.toDouble$c, i64 -2369631776295608608, ptr @df.dart$3acore._IntegerImplementation.round$c, i64 -1610317686921045632, ptr @df.dart$3acore._IntegerImplementation._truncDivFromInteger$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -678006041086143636, ptr @df.dart$3acore._IntegerImplementation.$3c$c, i64 -678003842062887214, ptr @df.dart$3acore._IntegerImplementation.$3e$c, i64 -677990647923348682, ptr @df.dart$3acore._IntegerImplementation.$2a$c, i64 -677989548411720471, ptr @df.dart$3acore._IntegerImplementation.$2b$c, i64 -677987349388464049, ptr @df.dart$3acore._IntegerImplementation.$2d$c, i64 -677985150365207627, ptr @df.dart$3acore._IntegerImplementation.$2f$c, i64 -677977453783810150, ptr @df.dart$3acore._IntegerImplementation.$26$c, i64 -622352372757107330, ptr @df.dart$3acore._IntegerImplementation._truncDivFromInteger$tc, i64 203890848951367299, ptr @df.dart$3acore._IntegerImplementation._subFromInteger$c, i64 520291628328000545, ptr @df.dart$3acore._IntegerImplementation.isNaN$g, i64 1736290547201802069, ptr @df.dart$3acore._IntegerImplementation.remainder$tc, i64 2468567154877893166, ptr @df.dart$3acore._IntegerImplementation._remainderFromInteger$tc, i64 2555306592430875535, ptr @df.dart$3acore._Smi.bitLength$g, i64 2896079652477072013, ptr @df.dart$3acore._IntegerImplementation.$7e$2f$tc, i64 3379649470273185486, ptr @df.dart$3acore._IntegerImplementation._greaterThanFromInteger$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore._Smi.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore._Smi._identityHashCode$g, i64 5852185211741937682, ptr @df.dart$3acore._IntegerImplementation.toInt$c, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7304002064172038551, ptr @df.dart$3acore._IntegerImplementation.remainder$c, i64 7594441835806680532, ptr @df.dart$3acore._IntegerImplementation._addFromInteger$c, i64 8321144794629309927, ptr @df.dart$3acore._IntegerImplementation._mulFromInteger$c, i64 9222726150749128103, ptr @df.dart$3acore._IntegerImplementation.$7e$2f$c }
define ptr @df.mt.dart$3acore._Smi() {
b0:
  ret ptr @df.mt.dart$3acore._Smi$d
}
@df.mt.dart$3acore._Mint$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 3, i64 48, i64 -9163797671095228218, ptr @df.dart$3acore._IntegerImplementation.$3d$3d$c, i64 -9075490628995950738, ptr @df.dart$3acore._IntegerImplementation.unary$2d$c, i64 -8237661618964817018, ptr @df.dart$3acore._IntegerImplementation._addFromInteger$tc, i64 -7706065890611529093, ptr @df.dart$3acore._IntegerImplementation.isNegative$g, i64 -7599129895765617744, ptr @df.dart$3acore._IntegerImplementation._remainderFromInteger$c, i64 -7095062371641373373, ptr @df.dart$3acore._IntegerImplementation.isFinite$g, i64 -5612894578032499650, ptr @df.dart$3acore._IntegerImplementation._equalToInteger$c, i64 -5179915397299019584, ptr @df.dart$3acore._IntegerImplementation._greaterThanFromInteger$tc, i64 -4318155389668546510, ptr @df.dart$3acore._IntegerImplementation.truncate$c, i64 -4020828333918261805, ptr @df.dart$3acore._IntegerImplementation.$2f$tc, i64 -4020826134895005383, ptr @df.dart$3acore._IntegerImplementation.$2d$tc, i64 -4020825035383377172, ptr @df.dart$3acore._IntegerImplementation.$2a$tc, i64 -4020823935871748961, ptr @df.dart$3acore._IntegerImplementation.$2b$tc, i64 -4020820637336864328, ptr @df.dart$3acore._IntegerImplementation.$26$tc, i64 -4020811841243838640, ptr @df.dart$3acore._IntegerImplementation.$3e$tc, i64 -4020809642220582218, ptr @df.dart$3acore._IntegerImplementation.$3c$tc, i64 -3726519281940109379, ptr @df.dart$3acore._IntegerImplementation._subFromInteger$tc, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -2936588468885866592, ptr @df.dart$3acore._IntegerImplementation._equalToInteger$tc, i64 -2649732211752220415, ptr @df.dart$3acore._IntegerImplementation._mulFromInteger$tc, i64 -2488972445746378804, ptr @df.dart$3acore._IntegerImplementation.toDouble$c, i64 -2369631776295608608, ptr @df.dart$3acore._IntegerImplementation.round$c, i64 -1610317686921045632, ptr @df.dart$3acore._IntegerImplementation._truncDivFromInteger$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -678006041086143636, ptr @df.dart$3acore._IntegerImplementation.$3c$c, i64 -678003842062887214, ptr @df.dart$3acore._IntegerImplementation.$3e$c, i64 -677990647923348682, ptr @df.dart$3acore._IntegerImplementation.$2a$c, i64 -677989548411720471, ptr @df.dart$3acore._IntegerImplementation.$2b$c, i64 -677987349388464049, ptr @df.dart$3acore._IntegerImplementation.$2d$c, i64 -677985150365207627, ptr @df.dart$3acore._IntegerImplementation.$2f$c, i64 -677977453783810150, ptr @df.dart$3acore._IntegerImplementation.$26$c, i64 -622352372757107330, ptr @df.dart$3acore._IntegerImplementation._truncDivFromInteger$tc, i64 203890848951367299, ptr @df.dart$3acore._IntegerImplementation._subFromInteger$c, i64 520291628328000545, ptr @df.dart$3acore._IntegerImplementation.isNaN$g, i64 1736290547201802069, ptr @df.dart$3acore._IntegerImplementation.remainder$tc, i64 2468567154877893166, ptr @df.dart$3acore._IntegerImplementation._remainderFromInteger$tc, i64 2555306592430875535, ptr @df.dart$3acore._Mint.bitLength$g, i64 2896079652477072013, ptr @df.dart$3acore._IntegerImplementation.$7e$2f$tc, i64 3379649470273185486, ptr @df.dart$3acore._IntegerImplementation._greaterThanFromInteger$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore._Mint.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore._Mint._identityHashCode$g, i64 5852185211741937682, ptr @df.dart$3acore._IntegerImplementation.toInt$c, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7304002064172038551, ptr @df.dart$3acore._IntegerImplementation.remainder$c, i64 7594441835806680532, ptr @df.dart$3acore._IntegerImplementation._addFromInteger$c, i64 8321144794629309927, ptr @df.dart$3acore._IntegerImplementation._mulFromInteger$c, i64 9222726150749128103, ptr @df.dart$3acore._IntegerImplementation.$7e$2f$c }
define ptr @df.mt.dart$3acore._Mint() {
b0:
  ret ptr @df.mt.dart$3acore._Mint$d
}
@df.mt.dart$3acore._InvocationMirror$d = private unnamed_addr constant { i64, i64 } { i64 650, i64 0 }
define ptr @df.mt.dart$3acore._InvocationMirror() {
b0:
  ret ptr @df.mt.dart$3acore._InvocationMirror$d
}
@df.mt.dart$3acore._LibraryPrefix$d = private unnamed_addr constant { i64, i64 } { i64 651, i64 0 }
define ptr @df.mt.dart$3acore._LibraryPrefix() {
b0:
  ret ptr @df.mt.dart$3acore._LibraryPrefix$d
}
@df.mt.dart$3acore._DeferredNotLoadedError$d = private unnamed_addr constant { i64, i64 } { i64 640, i64 0 }
define ptr @df.mt.dart$3acore._DeferredNotLoadedError() {
b0:
  ret ptr @df.mt.dart$3acore._DeferredNotLoadedError$d
}
@df.mt.dart$3acore._Record$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 12, i64 7, i64 -9163797671095228218, ptr @df.dart$3acore._Record.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore._Record.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore._Record.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore._Record() {
b0:
  ret ptr @df.mt.dart$3acore._Record$d
}
@df.mt.dart$3acore._RegExpMatch$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 657, i64 11, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 491505953491204280, ptr @df.dart$3acore._RegExpMatch.start$g, i64 2870274114568068918, ptr @df.dart$3acore._RegExpMatch.$5b$5d$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4304133201855208329, ptr @df.dart$3acore._RegExpMatch.end$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 9189246021676726028, ptr @df.dart$3acore._RegExpMatch.$5b$5d$c }
define ptr @df.mt.dart$3acore._RegExpMatch() {
b0:
  ret ptr @df.mt.dart$3acore._RegExpMatch$d
}
@df.mt.dart$3acore._RegExp$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 656, i64 12, i64 -9163797671095228218, ptr @df.dart$3acore._RegExp.$3d$3d$c, i64 -8669037509631859899, ptr @df.dart$3acore._RegExp.matchAsPrefix$c, i64 -5479526956205607321, ptr @df.dart$3acore._RegExp.matchAsPrefix$tc, i64 -4017474322469257098, ptr @df.dart$3acore._RegExp.allMatches$tc, i64 -3445551396850951156, ptr @df.dart$3acore._RegExp.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -795752144854854472, ptr @df.dart$3acore._RegExp.allMatches$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore._RegExp.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7082680721419594633, ptr @df.dart$3acore._RegExp._groupCount$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore._RegExp() {
b0:
  ret ptr @df.mt.dart$3acore._RegExp$d
}
@df.mt.dart$3acore._AllMatchesIterable$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 629, i64 25, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -7142806495848668844, ptr @df.dart$3acore.Iterable.last$g, i64 -7048868133546680485, ptr @df.dart$3acore.Iterable.toList$tc, i64 -6880024560892829041, ptr @df.dart$3acore.Iterable.skip$c, i64 -6565620648322651272, ptr @df.dart$3acore.Iterable.length$g, i64 -6455655928913991845, ptr @df.dart$3acore.Iterable.take$c, i64 -5476269667379286226, ptr @df.dart$3acore._AllMatchesIterable.iterator$g, i64 -4183823290162052582, ptr @df.dart$3acore.Iterable.join$tc, i64 -3445551396850951156, ptr @df.dart$3acore.Iterable.toString$c, i64 -3444103220339216083, ptr @df.dart$3acore.Iterable.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3acore.Iterable.elementAt$c, i64 -2322265645133230011, ptr @df.dart$3acore.Iterable.skip$tc, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -730073319095210781, ptr @df.dart$3acore.Iterable.elementAt$tc, i64 590583546444750725, ptr @df.dart$3acore.Iterable.take$tc, i64 1309726782632086582, ptr @df.dart$3acore.Iterable.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3acore.Iterable.toList$c, i64 1890975232377856814, ptr @df.dart$3acore.Iterable.map$c, i64 3251101298082571214, ptr @df.dart$3acore.Iterable.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4584568332005005361, ptr @df.dart$3acore.Iterable.contains$c, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3acore.Iterable.join$c, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore._AllMatchesIterable() {
b0:
  ret ptr @df.mt.dart$3acore._AllMatchesIterable$d
}
@df.mt.dart$3acore._AllMatchesIterator$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 630, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -5038376148439920376, ptr @df.dart$3acore._AllMatchesIterator.moveNext$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 1052728634250411761, ptr @df.dart$3acore._AllMatchesIterator.current$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore._AllMatchesIterator() {
b0:
  ret ptr @df.mt.dart$3acore._AllMatchesIterator$d
}
@df.mt.dart$3acore._StackTrace$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 660, i64 7, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.$stackTrace.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore._StackTrace() {
b0:
  ret ptr @df.mt.dart$3acore._StackTrace$d
}
@df.mt.dart$3acore._OneByteString$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 6, i64 34, i64 -9163797671095228218, ptr @df.dart$3acore._OneByteString.$3d$3d$c, i64 -8891568347670967194, ptr @df.dart$3acore._OneByteString.split$tc, i64 -8669037509631859899, ptr @df.dart$3acore._StringBase.matchAsPrefix$c, i64 -7350593622243868905, ptr @df.dart$3acore._OneByteString.toUpperCase$c, i64 -6565620648322651272, ptr @df.dart$3acore._StringBase.length$g, i64 -5701173819125916357, ptr @df.dart$3acore._OneByteString._substringUncheckedNative$tc, i64 -5479526956205607321, ptr @df.dart$3acore._StringBase.matchAsPrefix$tc, i64 -4316626677512209454, ptr @df.dart$3acore._OneByteString.toLowerCase$c, i64 -4160647668805903014, ptr @df.dart$3acore._OneByteString._isWhitespace$c, i64 -4020825035383377172, ptr @df.dart$3acore._OneByteString.$2a$tc, i64 -4020823935871748961, ptr @df.dart$3acore._StringBase.$2b$tc, i64 -4017474322469257098, ptr @df.dart$3acore._StringBase.allMatches$tc, i64 -3602276410357773240, ptr @df.dart$3acore._OneByteString.split$c, i64 -3445551396850951156, ptr @df.dart$3acore._StringBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3acore._StringBase.isEmpty$g, i64 -2865225933037962029, ptr @df.dart$3acore._OneByteString.indexOf$tc, i64 -1529224528304438008, ptr @df.dart$3acore._OneByteString.padLeft$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -795752144854854472, ptr @df.dart$3acore._StringBase.allMatches$c, i64 -677990647923348682, ptr @df.dart$3acore._OneByteString.$2a$c, i64 -677989548411720471, ptr @df.dart$3acore._StringBase.$2b$c, i64 1309726782632086582, ptr @df.dart$3acore._StringBase.isNotEmpty$g, i64 2870274114568068918, ptr @df.dart$3acore._StringBase.$5b$5d$tc, i64 3588872179274499044, ptr @df.dart$3acore._OneByteString._isWhitespace$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore._OneByteString.hashCode$g, i64 4584568332005005361, ptr @df.dart$3acore._OneByteString.contains$c, i64 5306504273795186908, ptr @df.dart$3acore._StringBase._identityHashCode$g, i64 5905964234576562817, ptr @df.dart$3acore._OneByteString._substringUncheckedNative$c, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7370894814644876091, ptr @df.dart$3acore._OneByteString.contains$tc, i64 8310139465989025733, ptr @df.dart$3acore._OneByteString.indexOf$c, i64 8467087382862072950, ptr @df.dart$3acore._OneByteString.padLeft$tc, i64 9189246021676726028, ptr @df.dart$3acore._StringBase.$5b$5d$c }
define ptr @df.mt.dart$3acore._OneByteString() {
b0:
  ret ptr @df.mt.dart$3acore._OneByteString$d
}
@df.mt.dart$3acore._TwoByteString$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 7, i64 34, i64 -9163797671095228218, ptr @df.dart$3acore._TwoByteString.$3d$3d$c, i64 -8891568347670967194, ptr @df.dart$3acore._StringBase.split$tc, i64 -8669037509631859899, ptr @df.dart$3acore._StringBase.matchAsPrefix$c, i64 -7350593622243868905, ptr @df.dart$3acore._StringBase.toUpperCase$c, i64 -6565620648322651272, ptr @df.dart$3acore._StringBase.length$g, i64 -5701173819125916357, ptr @df.dart$3acore._StringBase._substringUncheckedNative$tc, i64 -5479526956205607321, ptr @df.dart$3acore._StringBase.matchAsPrefix$tc, i64 -4316626677512209454, ptr @df.dart$3acore._StringBase.toLowerCase$c, i64 -4160647668805903014, ptr @df.dart$3acore._TwoByteString._isWhitespace$c, i64 -4020825035383377172, ptr @df.dart$3acore._TwoByteString.$2a$tc, i64 -4020823935871748961, ptr @df.dart$3acore._StringBase.$2b$tc, i64 -4017474322469257098, ptr @df.dart$3acore._StringBase.allMatches$tc, i64 -3602276410357773240, ptr @df.dart$3acore._StringBase.split$c, i64 -3445551396850951156, ptr @df.dart$3acore._StringBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3acore._StringBase.isEmpty$g, i64 -2865225933037962029, ptr @df.dart$3acore._StringBase.indexOf$tc, i64 -1529224528304438008, ptr @df.dart$3acore._StringBase.padLeft$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -795752144854854472, ptr @df.dart$3acore._StringBase.allMatches$c, i64 -677990647923348682, ptr @df.dart$3acore._TwoByteString.$2a$c, i64 -677989548411720471, ptr @df.dart$3acore._StringBase.$2b$c, i64 1309726782632086582, ptr @df.dart$3acore._StringBase.isNotEmpty$g, i64 2870274114568068918, ptr @df.dart$3acore._StringBase.$5b$5d$tc, i64 3588872179274499044, ptr @df.dart$3acore._TwoByteString._isWhitespace$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore._StringBase.hashCode$g, i64 4584568332005005361, ptr @df.dart$3acore._StringBase.contains$c, i64 5306504273795186908, ptr @df.dart$3acore._StringBase._identityHashCode$g, i64 5905964234576562817, ptr @df.dart$3acore._StringBase._substringUncheckedNative$c, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7370894814644876091, ptr @df.dart$3acore._StringBase.contains$tc, i64 8310139465989025733, ptr @df.dart$3acore._StringBase.indexOf$c, i64 8467087382862072950, ptr @df.dart$3acore._StringBase.padLeft$tc, i64 9189246021676726028, ptr @df.dart$3acore._StringBase.$5b$5d$c }
define ptr @df.mt.dart$3acore._TwoByteString() {
b0:
  ret ptr @df.mt.dart$3acore._TwoByteString$d
}
@df.mt.dart$3acore._StringMatch$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 664, i64 11, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 491505953491204280, ptr @df.dart$3acore._StringMatch.start$g, i64 2870274114568068918, ptr @df.dart$3acore._StringMatch.$5b$5d$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4304133201855208329, ptr @df.dart$3acore._StringMatch.end$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 9189246021676726028, ptr @df.dart$3acore._StringMatch.$5b$5d$c }
define ptr @df.mt.dart$3acore._StringMatch() {
b0:
  ret ptr @df.mt.dart$3acore._StringMatch$d
}
@df.mt.dart$3acore._StringAllMatchesIterable$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 661, i64 25, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -7142806495848668844, ptr @df.dart$3acore.Iterable.last$g, i64 -7048868133546680485, ptr @df.dart$3acore.Iterable.toList$tc, i64 -6880024560892829041, ptr @df.dart$3acore.Iterable.skip$c, i64 -6565620648322651272, ptr @df.dart$3acore.Iterable.length$g, i64 -6455655928913991845, ptr @df.dart$3acore.Iterable.take$c, i64 -5476269667379286226, ptr @df.dart$3acore._StringAllMatchesIterable.iterator$g, i64 -4183823290162052582, ptr @df.dart$3acore.Iterable.join$tc, i64 -3445551396850951156, ptr @df.dart$3acore.Iterable.toString$c, i64 -3444103220339216083, ptr @df.dart$3acore.Iterable.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3acore.Iterable.elementAt$c, i64 -2322265645133230011, ptr @df.dart$3acore.Iterable.skip$tc, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -730073319095210781, ptr @df.dart$3acore.Iterable.elementAt$tc, i64 590583546444750725, ptr @df.dart$3acore.Iterable.take$tc, i64 1309726782632086582, ptr @df.dart$3acore.Iterable.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3acore.Iterable.toList$c, i64 1890975232377856814, ptr @df.dart$3acore.Iterable.map$c, i64 3251101298082571214, ptr @df.dart$3acore.Iterable.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4584568332005005361, ptr @df.dart$3acore.Iterable.contains$c, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3acore.Iterable.join$c, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore._StringAllMatchesIterable() {
b0:
  ret ptr @df.mt.dart$3acore._StringAllMatchesIterable$d
}
@df.mt.dart$3acore._StringAllMatchesIterator$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 662, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -5038376148439920376, ptr @df.dart$3acore._StringAllMatchesIterator.moveNext$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 1052728634250411761, ptr @df.dart$3acore._StringAllMatchesIterator.current$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acore._StringAllMatchesIterator() {
b0:
  ret ptr @df.mt.dart$3acore._StringAllMatchesIterator$d
}
@df.mt.dart$3acore._Type$d = private unnamed_addr constant { i64, i64 } { i64 666, i64 0 }
define ptr @df.mt.dart$3acore._Type() {
b0:
  ret ptr @df.mt.dart$3acore._Type$d
}
@df.mt.dart$3acore._FunctionType$d = private unnamed_addr constant { i64, i64 } { i64 645, i64 0 }
define ptr @df.mt.dart$3acore._FunctionType() {
b0:
  ret ptr @df.mt.dart$3acore._FunctionType$d
}
@df.mt.dart$3acore._RecordType$d = private unnamed_addr constant { i64, i64 } { i64 655, i64 0 }
define ptr @df.mt.dart$3acore._RecordType() {
b0:
  ret ptr @df.mt.dart$3acore._RecordType$d
}
@df.mt.dart$3acore._TypeRef$d = private unnamed_addr constant { i64, i64 } { i64 669, i64 0 }
define ptr @df.mt.dart$3acore._TypeRef() {
b0:
  ret ptr @df.mt.dart$3acore._TypeRef$d
}
@df.mt.dart$3acore._TypeParameter$d = private unnamed_addr constant { i64, i64 } { i64 668, i64 0 }
define ptr @df.mt.dart$3acore._TypeParameter() {
b0:
  ret ptr @df.mt.dart$3acore._TypeParameter$d
}
@df.mt.dart$3acore._WeakProperty$d = private unnamed_addr constant { i64, i64 } { i64 671, i64 0 }
define ptr @df.mt.dart$3acore._WeakProperty() {
b0:
  ret ptr @df.mt.dart$3acore._WeakProperty$d
}
@df.mt.dart$3a_compact_hash._Map$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 151, i64 33, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8432336653232598456, ptr @df.dart$3a_compact_hash._OperatorEqualsAndHashCode._hashCode$c, i64 -6944993272148414929, ptr @df.dart$3a_compact_hash._HashVMBase._hashMask$s, i64 -6670340918992855251, ptr @df.dart$3a_compact_hash._HashVMBase._index$g, i64 -6565620648322651272, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.length$g, i64 -4973719782432882445, ptr @df.dart$3a_compact_hash._HashVMBase._data$g, i64 -4486021567115414408, ptr @df.dart$3a_compact_hash._HashVMBase._usedData$s, i64 -3866235685779022111, ptr @df.dart$3a_compact_hash._HashVMBase._index$3d$s, i64 -3537589580134995272, ptr @df.dart$3a_compact_hash._Map.containsKey$c, i64 -3445551396850951156, ptr @df.dart$3acollection.MapBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.isEmpty$g, i64 -2576910519837881863, ptr @df.dart$3a_compact_hash._Map._init$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.remove$c, i64 -1023378618551812672, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.keys$g, i64 -857921570071973898, ptr @df.dart$3a_compact_hash._HashVMBase._deletedKeys$g, i64 -193244862529815473, ptr @df.dart$3a_compact_hash._Map._init$tc, i64 800168990514156231, ptr @df.dart$3a_compact_hash._HashVMBase._data$s, i64 1309726782632086582, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.isNotEmpty$g, i64 1523406778913696467, ptr @df.dart$3a_compact_hash._HashVMBase._hashMask$g, i64 1846483113803001778, ptr @df.dart$3a_compact_hash._HashVMBase._deletedKeys$s, i64 1890975232377856814, ptr @df.dart$3acollection.MapBase.map$c, i64 3251101298082571214, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 6614220702253890234, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.values$g, i64 6703568105477591687, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin._regenerateIndex$c, i64 6905165401198100684, ptr @df.dart$3a_compact_hash._HashVMBase._usedData$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7526586947604351043, ptr @df.dart$3a_compact_hash._Map.$5b$5d$3d$c, i64 7962571414437758820, ptr @df.dart$3a_compact_hash._OperatorEqualsAndHashCode._equals$c, i64 9189246021676726028, ptr @df.dart$3a_compact_hash._Map.$5b$5d$c }
define ptr @df.mt.dart$3a_compact_hash._Map() {
b0:
  ret ptr @df.mt.dart$3a_compact_hash._Map$d
}
@df.mt.dart$3a_compact_hash._ConstMap$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 136, i64 34, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8432336653232598456, ptr @df.dart$3a_compact_hash._OperatorEqualsAndCanonicalHashCode._hashCode$c, i64 -6944993272148414929, ptr @df.dart$3a_compact_hash._HashVMBase._hashMask$s, i64 -6670340918992855251, ptr @df.dart$3a_compact_hash._HashVMImmutableBase._index$g, i64 -6565620648322651272, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.length$g, i64 -4973719782432882445, ptr @df.dart$3a_compact_hash._HashVMBase._data$g, i64 -4486021567115414408, ptr @df.dart$3a_compact_hash._HashVMBase._usedData$s, i64 -3866235685779022111, ptr @df.dart$3a_compact_hash._HashVMBase._index$3d$s, i64 -3537589580134995272, ptr @df.dart$3a_compact_hash._ImmutableLinkedHashMapMixin.containsKey$c, i64 -3445551396850951156, ptr @df.dart$3acollection.MapBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.isEmpty$g, i64 -2576910519837881863, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin._init$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3a_compact_hash._UnmodifiableMapMixin.remove$c, i64 -1023378618551812672, ptr @df.dart$3a_compact_hash._ImmutableLinkedHashMapMixin.keys$g, i64 -857921570071973898, ptr @df.dart$3a_compact_hash._HashVMBase._deletedKeys$g, i64 -193244862529815473, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin._init$tc, i64 800168990514156231, ptr @df.dart$3a_compact_hash._HashVMBase._data$s, i64 1309726782632086582, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.isNotEmpty$g, i64 1523406778913696467, ptr @df.dart$3a_compact_hash._HashVMBase._hashMask$g, i64 1846483113803001778, ptr @df.dart$3a_compact_hash._HashVMBase._deletedKeys$s, i64 1890975232377856814, ptr @df.dart$3acollection.MapBase.map$c, i64 3251101298082571214, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 6614220702253890234, ptr @df.dart$3a_compact_hash._ImmutableLinkedHashMapMixin.values$g, i64 6703568105477591687, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin._regenerateIndex$c, i64 6905165401198100684, ptr @df.dart$3a_compact_hash._HashVMBase._usedData$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7526586947604351043, ptr @df.dart$3a_compact_hash._UnmodifiableMapMixin.$5b$5d$3d$c, i64 7962571414437758820, ptr @df.dart$3a_compact_hash._OperatorEqualsAndCanonicalHashCode._equals$c, i64 8699137859310292346, ptr @df.dart$3a_compact_hash._HashVMImmutableBase._indexNullable$g, i64 9189246021676726028, ptr @df.dart$3a_compact_hash._ImmutableLinkedHashMapMixin.$5b$5d$c }
define ptr @df.mt.dart$3a_compact_hash._ConstMap() {
b0:
  ret ptr @df.mt.dart$3a_compact_hash._ConstMap$d
}
@df.mt.dart$3a_compact_hash.CompactLinkedIdentityHashMap$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 130, i64 33, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8432336653232598456, ptr @df.dart$3a_compact_hash._IdenticalAndIdentityHashCode._hashCode$c, i64 -6944993272148414929, ptr @df.dart$3a_compact_hash._HashFieldBase._hashMask$s, i64 -6670340918992855251, ptr @df.dart$3a_compact_hash._HashFieldBase._index$g, i64 -6565620648322651272, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.length$g, i64 -4973719782432882445, ptr @df.dart$3a_compact_hash._HashFieldBase._data$g, i64 -4486021567115414408, ptr @df.dart$3a_compact_hash._HashFieldBase._usedData$s, i64 -3866235685779022111, ptr @df.dart$3a_compact_hash._HashFieldBase._index$3d$s, i64 -3537589580134995272, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.containsKey$c, i64 -3445551396850951156, ptr @df.dart$3acollection.MapBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.isEmpty$g, i64 -2576910519837881863, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin._init$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.remove$c, i64 -1023378618551812672, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.keys$g, i64 -857921570071973898, ptr @df.dart$3a_compact_hash._HashFieldBase._deletedKeys$g, i64 -193244862529815473, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin._init$tc, i64 800168990514156231, ptr @df.dart$3a_compact_hash._HashFieldBase._data$s, i64 1309726782632086582, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.isNotEmpty$g, i64 1523406778913696467, ptr @df.dart$3a_compact_hash._HashFieldBase._hashMask$g, i64 1846483113803001778, ptr @df.dart$3a_compact_hash._HashFieldBase._deletedKeys$s, i64 1890975232377856814, ptr @df.dart$3acollection.MapBase.map$c, i64 3251101298082571214, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 6614220702253890234, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.values$g, i64 6703568105477591687, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin._regenerateIndex$c, i64 6905165401198100684, ptr @df.dart$3a_compact_hash._HashFieldBase._usedData$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7526586947604351043, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.$5b$5d$3d$c, i64 7962571414437758820, ptr @df.dart$3a_compact_hash._IdenticalAndIdentityHashCode._equals$c, i64 9189246021676726028, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.$5b$5d$c }
define ptr @df.mt.dart$3a_compact_hash.CompactLinkedIdentityHashMap() {
b0:
  ret ptr @df.mt.dart$3a_compact_hash.CompactLinkedIdentityHashMap$d
}
@df.mt.dart$3a_compact_hash.CompactLinkedCustomHashMap$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 128, i64 35, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8432336653232598456, ptr @df.dart$3a_compact_hash._CustomEqualsAndHashCode._hashCode$c, i64 -6944993272148414929, ptr @df.dart$3a_compact_hash._HashFieldBase._hashMask$s, i64 -6844096556131571217, ptr @df.dart$3a_compact_hash.CompactLinkedCustomHashMap._equality$g, i64 -6670340918992855251, ptr @df.dart$3a_compact_hash._HashFieldBase._index$g, i64 -6565620648322651272, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.length$g, i64 -4973719782432882445, ptr @df.dart$3a_compact_hash._HashFieldBase._data$g, i64 -4486021567115414408, ptr @df.dart$3a_compact_hash._HashFieldBase._usedData$s, i64 -3866235685779022111, ptr @df.dart$3a_compact_hash._HashFieldBase._index$3d$s, i64 -3537589580134995272, ptr @df.dart$3a_compact_hash.CompactLinkedCustomHashMap.containsKey$c, i64 -3445551396850951156, ptr @df.dart$3acollection.MapBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.isEmpty$g, i64 -2576910519837881863, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin._init$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3a_compact_hash.CompactLinkedCustomHashMap.remove$c, i64 -1023378618551812672, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.keys$g, i64 -857921570071973898, ptr @df.dart$3a_compact_hash._HashFieldBase._deletedKeys$g, i64 -193244862529815473, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin._init$tc, i64 800168990514156231, ptr @df.dart$3a_compact_hash._HashFieldBase._data$s, i64 1309726782632086582, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.isNotEmpty$g, i64 1523406778913696467, ptr @df.dart$3a_compact_hash._HashFieldBase._hashMask$g, i64 1846483113803001778, ptr @df.dart$3a_compact_hash._HashFieldBase._deletedKeys$s, i64 1890975232377856814, ptr @df.dart$3acollection.MapBase.map$c, i64 3251101298082571214, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4091523715276164666, ptr @df.dart$3a_compact_hash.CompactLinkedCustomHashMap._hasher$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 6614220702253890234, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.values$g, i64 6703568105477591687, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin._regenerateIndex$c, i64 6905165401198100684, ptr @df.dart$3a_compact_hash._HashFieldBase._usedData$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7526586947604351043, ptr @df.dart$3a_compact_hash._LinkedHashMapMixin.$5b$5d$3d$c, i64 7962571414437758820, ptr @df.dart$3a_compact_hash._CustomEqualsAndHashCode._equals$c, i64 9189246021676726028, ptr @df.dart$3a_compact_hash.CompactLinkedCustomHashMap.$5b$5d$c }
define ptr @df.mt.dart$3a_compact_hash.CompactLinkedCustomHashMap() {
b0:
  ret ptr @df.mt.dart$3a_compact_hash.CompactLinkedCustomHashMap$d
}
@df.mt.dart$3a_compact_hash._CompactIterable$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 132, i64 25, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -7142806495848668844, ptr @df.dart$3acore.Iterable.last$g, i64 -7048868133546680485, ptr @df.dart$3acore.Iterable.toList$tc, i64 -6880024560892829041, ptr @df.dart$3acore.Iterable.skip$c, i64 -6565620648322651272, ptr @df.dart$3a_compact_hash._CompactIterable.length$g, i64 -6455655928913991845, ptr @df.dart$3acore.Iterable.take$c, i64 -5476269667379286226, ptr @df.dart$3a_compact_hash._CompactIterable.iterator$g, i64 -4183823290162052582, ptr @df.dart$3acore.Iterable.join$tc, i64 -3445551396850951156, ptr @df.dart$3acore.Iterable.toString$c, i64 -3444103220339216083, ptr @df.dart$3a_compact_hash._CompactIterable.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3acore.Iterable.elementAt$c, i64 -2322265645133230011, ptr @df.dart$3acore.Iterable.skip$tc, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -730073319095210781, ptr @df.dart$3acore.Iterable.elementAt$tc, i64 590583546444750725, ptr @df.dart$3acore.Iterable.take$tc, i64 1309726782632086582, ptr @df.dart$3a_compact_hash._CompactIterable.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3acore.Iterable.toList$c, i64 1890975232377856814, ptr @df.dart$3acore.Iterable.map$c, i64 3251101298082571214, ptr @df.dart$3acore.Iterable.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4584568332005005361, ptr @df.dart$3acore.Iterable.contains$c, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3acore.Iterable.join$c, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3a_compact_hash._CompactIterable() {
b0:
  ret ptr @df.mt.dart$3a_compact_hash._CompactIterable$d
}
@df.mt.dart$3a_compact_hash._CompactIterator$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 134, i64 10, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -5038376148439920376, ptr @df.dart$3a_compact_hash._CompactIterator.moveNext$c, i64 -4973719782432882445, ptr @df.dart$3a_compact_hash._CompactIterator._data$g, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 1052728634250411761, ptr @df.dart$3a_compact_hash._CompactIterator.current$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3a_compact_hash._CompactIterator() {
b0:
  ret ptr @df.mt.dart$3a_compact_hash._CompactIterator$d
}
@df.mt.dart$3a_compact_hash._CompactIterableImmutable$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 133, i64 26, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -7142806495848668844, ptr @df.dart$3acore.Iterable.last$g, i64 -7048868133546680485, ptr @df.dart$3acore.Iterable.toList$tc, i64 -6880024560892829041, ptr @df.dart$3acore.Iterable.skip$c, i64 -6565620648322651272, ptr @df.dart$3a_compact_hash._CompactIterableImmutable.length$g, i64 -6455655928913991845, ptr @df.dart$3acore.Iterable.take$c, i64 -5476269667379286226, ptr @df.dart$3a_compact_hash._CompactIterableImmutable.iterator$g, i64 -4973719782432882445, ptr @df.dart$3a_compact_hash._CompactIterableImmutable._data$g, i64 -4183823290162052582, ptr @df.dart$3acore.Iterable.join$tc, i64 -3445551396850951156, ptr @df.dart$3acore.Iterable.toString$c, i64 -3444103220339216083, ptr @df.dart$3a_compact_hash._CompactIterableImmutable.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3acore.Iterable.elementAt$c, i64 -2322265645133230011, ptr @df.dart$3acore.Iterable.skip$tc, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -730073319095210781, ptr @df.dart$3acore.Iterable.elementAt$tc, i64 590583546444750725, ptr @df.dart$3acore.Iterable.take$tc, i64 1309726782632086582, ptr @df.dart$3a_compact_hash._CompactIterableImmutable.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3acore.Iterable.toList$c, i64 1890975232377856814, ptr @df.dart$3acore.Iterable.map$c, i64 3251101298082571214, ptr @df.dart$3acore.Iterable.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4584568332005005361, ptr @df.dart$3acore.Iterable.contains$c, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3acore.Iterable.join$c, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3a_compact_hash._CompactIterableImmutable() {
b0:
  ret ptr @df.mt.dart$3a_compact_hash._CompactIterableImmutable$d
}
@df.mt.dart$3a_compact_hash._CompactIteratorImmutable$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 135, i64 10, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -5038376148439920376, ptr @df.dart$3a_compact_hash._CompactIteratorImmutable.moveNext$c, i64 -4973719782432882445, ptr @df.dart$3a_compact_hash._CompactIteratorImmutable._data$g, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 1052728634250411761, ptr @df.dart$3a_compact_hash._CompactIteratorImmutable.current$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3a_compact_hash._CompactIteratorImmutable() {
b0:
  ret ptr @df.mt.dart$3a_compact_hash._CompactIteratorImmutable$d
}
@df.mt.dart$3a_compact_hash._Set$d = private unnamed_addr constant { i64, i64 } { i64 154, i64 0 }
define ptr @df.mt.dart$3a_compact_hash._Set() {
b0:
  ret ptr @df.mt.dart$3a_compact_hash._Set$d
}
@df.mt.dart$3a_compact_hash._ConstSet$d = private unnamed_addr constant { i64, i64 } { i64 137, i64 0 }
define ptr @df.mt.dart$3a_compact_hash._ConstSet() {
b0:
  ret ptr @df.mt.dart$3a_compact_hash._ConstSet$d
}
@df.mt.dart$3a_compact_hash.CompactLinkedIdentityHashSet$d = private unnamed_addr constant { i64, i64 } { i64 131, i64 0 }
define ptr @df.mt.dart$3a_compact_hash.CompactLinkedIdentityHashSet() {
b0:
  ret ptr @df.mt.dart$3a_compact_hash.CompactLinkedIdentityHashSet$d
}
@df.mt.dart$3a_compact_hash.CompactLinkedCustomHashSet$d = private unnamed_addr constant { i64, i64 } { i64 129, i64 0 }
define ptr @df.mt.dart$3a_compact_hash.CompactLinkedCustomHashSet() {
b0:
  ret ptr @df.mt.dart$3a_compact_hash.CompactLinkedCustomHashSet$d
}
@df.mt.dart$3acollection.UnmodifiableListView$d = private unnamed_addr constant { i64, i64 } { i64 453, i64 0 }
define ptr @df.mt.dart$3acollection.UnmodifiableListView() {
b0:
  ret ptr @df.mt.dart$3acollection.UnmodifiableListView$d
}
@df.mt.dart$3acollection.HasNextIterator$d = private unnamed_addr constant { i64, i64 } { i64 438, i64 0 }
define ptr @df.mt.dart$3acollection.HasNextIterator() {
b0:
  ret ptr @df.mt.dart$3acollection.HasNextIterator$d
}
@df.mt.dart$3acollection.LinkedList$d = private unnamed_addr constant { i64, i64 } { i64 443, i64 0 }
define ptr @df.mt.dart$3acollection.LinkedList() {
b0:
  ret ptr @df.mt.dart$3acollection.LinkedList$d
}
@df.mt.dart$3acollection._LinkedListIterator$d = private unnamed_addr constant { i64, i64 } { i64 476, i64 0 }
define ptr @df.mt.dart$3acollection._LinkedListIterator() {
b0:
  ret ptr @df.mt.dart$3acollection._LinkedListIterator$d
}
@df.mt.dart$3acollection._MapBaseValueIterable$d = private unnamed_addr constant { i64, i64 } { i64 478, i64 0 }
define ptr @df.mt.dart$3acollection._MapBaseValueIterable() {
b0:
  ret ptr @df.mt.dart$3acollection._MapBaseValueIterable$d
}
@df.mt.dart$3acollection._MapBaseValueIterator$d = private unnamed_addr constant { i64, i64 } { i64 479, i64 0 }
define ptr @df.mt.dart$3acollection._MapBaseValueIterator() {
b0:
  ret ptr @df.mt.dart$3acollection._MapBaseValueIterator$d
}
@df.mt.dart$3acollection.MapView$d = private unnamed_addr constant { i64, i64 } { i64 448, i64 0 }
define ptr @df.mt.dart$3acollection.MapView() {
b0:
  ret ptr @df.mt.dart$3acollection.MapView$d
}
@df.mt.dart$3acollection.UnmodifiableMapView$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 455, i64 18, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -6565620648322651272, ptr @df.dart$3acollection.MapView.length$g, i64 -3537589580134995272, ptr @df.dart$3acollection.MapView.containsKey$c, i64 -3445551396850951156, ptr @df.dart$3acollection.MapView.toString$c, i64 -3444103220339216083, ptr @df.dart$3acollection.MapView.isEmpty$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3acollection._UnmodifiableMapMixin.remove$c, i64 -1023378618551812672, ptr @df.dart$3acollection.MapView.keys$g, i64 1309726782632086582, ptr @df.dart$3acollection.MapView.isNotEmpty$g, i64 1890975232377856814, ptr @df.dart$3acollection.MapView.map$c, i64 3251101298082571214, ptr @df.dart$3acollection.MapView.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 6614220702253890234, ptr @df.dart$3acollection.MapView.values$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7526586947604351043, ptr @df.dart$3acollection._UnmodifiableMapMixin.$5b$5d$3d$c, i64 9189246021676726028, ptr @df.dart$3acollection.MapView.$5b$5d$c }
define ptr @df.mt.dart$3acollection.UnmodifiableMapView() {
b0:
  ret ptr @df.mt.dart$3acollection.UnmodifiableMapView$d
}
@df.mt.dart$3acollection._DoubleLinkedQueueElement$d = private unnamed_addr constant { i64, i64 } { i64 459, i64 0 }
define ptr @df.mt.dart$3acollection._DoubleLinkedQueueElement() {
b0:
  ret ptr @df.mt.dart$3acollection._DoubleLinkedQueueElement$d
}
@df.mt.dart$3acollection._DoubleLinkedQueueSentinel$d = private unnamed_addr constant { i64, i64 } { i64 462, i64 0 }
define ptr @df.mt.dart$3acollection._DoubleLinkedQueueSentinel() {
b0:
  ret ptr @df.mt.dart$3acollection._DoubleLinkedQueueSentinel$d
}
@df.mt.dart$3acollection.DoubleLinkedQueue$d = private unnamed_addr constant { i64, i64 } { i64 437, i64 0 }
define ptr @df.mt.dart$3acollection.DoubleLinkedQueue() {
b0:
  ret ptr @df.mt.dart$3acollection.DoubleLinkedQueue$d
}
@df.mt.dart$3acollection._DoubleLinkedQueueIterator$d = private unnamed_addr constant { i64, i64 } { i64 461, i64 0 }
define ptr @df.mt.dart$3acollection._DoubleLinkedQueueIterator() {
b0:
  ret ptr @df.mt.dart$3acollection._DoubleLinkedQueueIterator$d
}
@df.mt.dart$3acollection.ListQueue$d = private unnamed_addr constant { i64, i64 } { i64 446, i64 0 }
define ptr @df.mt.dart$3acollection.ListQueue() {
b0:
  ret ptr @df.mt.dart$3acollection.ListQueue$d
}
@df.mt.dart$3acollection._ListQueueIterator$d = private unnamed_addr constant { i64, i64 } { i64 477, i64 0 }
define ptr @df.mt.dart$3acollection._ListQueueIterator() {
b0:
  ret ptr @df.mt.dart$3acollection._ListQueueIterator$d
}
@df.mt.dart$3acollection._UnmodifiableSet$d = private unnamed_addr constant { i64, i64 } { i64 494, i64 0 }
define ptr @df.mt.dart$3acollection._UnmodifiableSet() {
b0:
  ret ptr @df.mt.dart$3acollection._UnmodifiableSet$d
}
@df.mt.dart$3acollection.UnmodifiableSetView$d = private unnamed_addr constant { i64, i64 } { i64 456, i64 0 }
define ptr @df.mt.dart$3acollection.UnmodifiableSetView() {
b0:
  ret ptr @df.mt.dart$3acollection.UnmodifiableSetView$d
}
@df.mt.dart$3acollection._SplayTreeNode$d = private unnamed_addr constant { i64, i64 } { i64 489, i64 0 }
define ptr @df.mt.dart$3acollection._SplayTreeNode() {
b0:
  ret ptr @df.mt.dart$3acollection._SplayTreeNode$d
}
@df.mt.dart$3acollection._SplayTreeSetNode$d = private unnamed_addr constant { i64, i64 } { i64 490, i64 0 }
define ptr @df.mt.dart$3acollection._SplayTreeSetNode() {
b0:
  ret ptr @df.mt.dart$3acollection._SplayTreeSetNode$d
}
@df.mt.dart$3acollection._SplayTreeMapNode$d = private unnamed_addr constant { i64, i64 } { i64 488, i64 0 }
define ptr @df.mt.dart$3acollection._SplayTreeMapNode() {
b0:
  ret ptr @df.mt.dart$3acollection._SplayTreeMapNode$d
}
@df.mt.dart$3acollection.SplayTreeMap$d = private unnamed_addr constant { i64, i64 } { i64 451, i64 0 }
define ptr @df.mt.dart$3acollection.SplayTreeMap() {
b0:
  ret ptr @df.mt.dart$3acollection.SplayTreeMap$d
}
@df.mt.dart$3acollection._SplayTreeKeyIterable$d = private unnamed_addr constant { i64, i64 } { i64 484, i64 0 }
define ptr @df.mt.dart$3acollection._SplayTreeKeyIterable() {
b0:
  ret ptr @df.mt.dart$3acollection._SplayTreeKeyIterable$d
}
@df.mt.dart$3acollection._SplayTreeValueIterable$d = private unnamed_addr constant { i64, i64 } { i64 491, i64 0 }
define ptr @df.mt.dart$3acollection._SplayTreeValueIterable() {
b0:
  ret ptr @df.mt.dart$3acollection._SplayTreeValueIterable$d
}
@df.mt.dart$3acollection._SplayTreeMapEntryIterable$d = private unnamed_addr constant { i64, i64 } { i64 486, i64 0 }
define ptr @df.mt.dart$3acollection._SplayTreeMapEntryIterable() {
b0:
  ret ptr @df.mt.dart$3acollection._SplayTreeMapEntryIterable$d
}
@df.mt.dart$3acollection._SplayTreeKeyIterator$d = private unnamed_addr constant { i64, i64 } { i64 485, i64 0 }
define ptr @df.mt.dart$3acollection._SplayTreeKeyIterator() {
b0:
  ret ptr @df.mt.dart$3acollection._SplayTreeKeyIterator$d
}
@df.mt.dart$3acollection._SplayTreeValueIterator$d = private unnamed_addr constant { i64, i64 } { i64 492, i64 0 }
define ptr @df.mt.dart$3acollection._SplayTreeValueIterator() {
b0:
  ret ptr @df.mt.dart$3acollection._SplayTreeValueIterator$d
}
@df.mt.dart$3acollection._SplayTreeMapEntryIterator$d = private unnamed_addr constant { i64, i64 } { i64 487, i64 0 }
define ptr @df.mt.dart$3acollection._SplayTreeMapEntryIterator() {
b0:
  ret ptr @df.mt.dart$3acollection._SplayTreeMapEntryIterator$d
}
@df.mt.dart$3acollection.SplayTreeSet$d = private unnamed_addr constant { i64, i64 } { i64 452, i64 0 }
define ptr @df.mt.dart$3acollection.SplayTreeSet() {
b0:
  ret ptr @df.mt.dart$3acollection.SplayTreeSet$d
}
@df.mt.dart$3acollection._HashMap$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 463, i64 18, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -6565620648322651272, ptr @df.dart$3acollection._HashMap.length$g, i64 -3537589580134995272, ptr @df.dart$3acollection._HashMap.containsKey$c, i64 -3445551396850951156, ptr @df.dart$3acollection.MapBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3acollection._HashMap.isEmpty$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3acollection._HashMap.remove$c, i64 -1023378618551812672, ptr @df.dart$3acollection._HashMap.keys$g, i64 1309726782632086582, ptr @df.dart$3acollection._HashMap.isNotEmpty$g, i64 1890975232377856814, ptr @df.dart$3acollection.MapBase.map$c, i64 3251101298082571214, ptr @df.dart$3acollection._HashMap.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 6614220702253890234, ptr @df.dart$3acollection._HashMap.values$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7526586947604351043, ptr @df.dart$3acollection._HashMap.$5b$5d$3d$c, i64 9189246021676726028, ptr @df.dart$3acollection._HashMap.$5b$5d$c }
define ptr @df.mt.dart$3acollection._HashMap() {
b0:
  ret ptr @df.mt.dart$3acollection._HashMap$d
}
@df.mt.dart$3acollection._CustomHashMap$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 457, i64 18, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -6565620648322651272, ptr @df.dart$3acollection._HashMap.length$g, i64 -3537589580134995272, ptr @df.dart$3acollection._CustomHashMap.containsKey$c, i64 -3445551396850951156, ptr @df.dart$3acollection.MapBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3acollection._HashMap.isEmpty$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3acollection._CustomHashMap.remove$c, i64 -1023378618551812672, ptr @df.dart$3acollection._HashMap.keys$g, i64 1309726782632086582, ptr @df.dart$3acollection._HashMap.isNotEmpty$g, i64 1890975232377856814, ptr @df.dart$3acollection.MapBase.map$c, i64 3251101298082571214, ptr @df.dart$3acollection._HashMap.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 6614220702253890234, ptr @df.dart$3acollection._HashMap.values$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7526586947604351043, ptr @df.dart$3acollection._CustomHashMap.$5b$5d$3d$c, i64 9189246021676726028, ptr @df.dart$3acollection._CustomHashMap.$5b$5d$c }
define ptr @df.mt.dart$3acollection._CustomHashMap() {
b0:
  ret ptr @df.mt.dart$3acollection._CustomHashMap$d
}
@df.mt.dart$3acollection._IdentityHashMap$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 474, i64 18, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -6565620648322651272, ptr @df.dart$3acollection._HashMap.length$g, i64 -3537589580134995272, ptr @df.dart$3acollection._IdentityHashMap.containsKey$c, i64 -3445551396850951156, ptr @df.dart$3acollection.MapBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3acollection._HashMap.isEmpty$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3acollection._IdentityHashMap.remove$c, i64 -1023378618551812672, ptr @df.dart$3acollection._HashMap.keys$g, i64 1309726782632086582, ptr @df.dart$3acollection._HashMap.isNotEmpty$g, i64 1890975232377856814, ptr @df.dart$3acollection.MapBase.map$c, i64 3251101298082571214, ptr @df.dart$3acollection._HashMap.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 6614220702253890234, ptr @df.dart$3acollection._HashMap.values$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7526586947604351043, ptr @df.dart$3acollection._IdentityHashMap.$5b$5d$3d$c, i64 9189246021676726028, ptr @df.dart$3acollection._IdentityHashMap.$5b$5d$c }
define ptr @df.mt.dart$3acollection._IdentityHashMap() {
b0:
  ret ptr @df.mt.dart$3acollection._IdentityHashMap$d
}
@df.mt.dart$3acollection._HashMapEntry$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 464, i64 7, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acollection._HashMapEntry.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acollection._HashMapEntry() {
b0:
  ret ptr @df.mt.dart$3acollection._HashMapEntry$d
}
@df.mt.dart$3acollection._HashMapKeyIterable$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 467, i64 25, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -7142806495848668844, ptr @df.dart$3acore.Iterable.last$g, i64 -7048868133546680485, ptr @df.dart$3acore.Iterable.toList$tc, i64 -6880024560892829041, ptr @df.dart$3acore.Iterable.skip$c, i64 -6565620648322651272, ptr @df.dart$3acollection._HashMapIterable.length$g, i64 -6455655928913991845, ptr @df.dart$3acore.Iterable.take$c, i64 -5476269667379286226, ptr @df.dart$3acollection._HashMapKeyIterable.iterator$g, i64 -4183823290162052582, ptr @df.dart$3acore.Iterable.join$tc, i64 -3445551396850951156, ptr @df.dart$3acore.Iterable.toString$c, i64 -3444103220339216083, ptr @df.dart$3acollection._HashMapIterable.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3acore.Iterable.elementAt$c, i64 -2322265645133230011, ptr @df.dart$3acore.Iterable.skip$tc, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -730073319095210781, ptr @df.dart$3acore.Iterable.elementAt$tc, i64 590583546444750725, ptr @df.dart$3acore.Iterable.take$tc, i64 1309726782632086582, ptr @df.dart$3acollection._HashMapIterable.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3acore.Iterable.toList$c, i64 1890975232377856814, ptr @df.dart$3acore.Iterable.map$c, i64 3251101298082571214, ptr @df.dart$3acollection._HashMapKeyIterable.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4584568332005005361, ptr @df.dart$3acollection._HashMapKeyIterable.contains$c, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3acore.Iterable.join$c, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acollection._HashMapKeyIterable() {
b0:
  ret ptr @df.mt.dart$3acollection._HashMapKeyIterable$d
}
@df.mt.dart$3acollection._HashMapValueIterable$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 469, i64 25, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -7142806495848668844, ptr @df.dart$3acore.Iterable.last$g, i64 -7048868133546680485, ptr @df.dart$3acore.Iterable.toList$tc, i64 -6880024560892829041, ptr @df.dart$3acore.Iterable.skip$c, i64 -6565620648322651272, ptr @df.dart$3acollection._HashMapIterable.length$g, i64 -6455655928913991845, ptr @df.dart$3acore.Iterable.take$c, i64 -5476269667379286226, ptr @df.dart$3acollection._HashMapValueIterable.iterator$g, i64 -4183823290162052582, ptr @df.dart$3acore.Iterable.join$tc, i64 -3445551396850951156, ptr @df.dart$3acore.Iterable.toString$c, i64 -3444103220339216083, ptr @df.dart$3acollection._HashMapIterable.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3acore.Iterable.elementAt$c, i64 -2322265645133230011, ptr @df.dart$3acore.Iterable.skip$tc, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -730073319095210781, ptr @df.dart$3acore.Iterable.elementAt$tc, i64 590583546444750725, ptr @df.dart$3acore.Iterable.take$tc, i64 1309726782632086582, ptr @df.dart$3acollection._HashMapIterable.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3acore.Iterable.toList$c, i64 1890975232377856814, ptr @df.dart$3acore.Iterable.map$c, i64 3251101298082571214, ptr @df.dart$3acollection._HashMapValueIterable.forEach$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4584568332005005361, ptr @df.dart$3acollection._HashMapValueIterable.contains$c, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3acore.Iterable.join$c, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acollection._HashMapValueIterable() {
b0:
  ret ptr @df.mt.dart$3acollection._HashMapValueIterable$d
}
@df.mt.dart$3acollection._HashMapKeyIterator$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 468, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -5038376148439920376, ptr @df.dart$3acollection._HashMapIterator.moveNext$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 1052728634250411761, ptr @df.dart$3acollection._HashMapKeyIterator.current$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acollection._HashMapKeyIterator() {
b0:
  ret ptr @df.mt.dart$3acollection._HashMapKeyIterator$d
}
@df.mt.dart$3acollection._HashMapValueIterator$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 470, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -5038376148439920376, ptr @df.dart$3acollection._HashMapIterator.moveNext$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 1052728634250411761, ptr @df.dart$3acollection._HashMapValueIterator.current$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3acollection._HashMapValueIterator() {
b0:
  ret ptr @df.mt.dart$3acollection._HashMapValueIterator$d
}
@df.mt.dart$3acollection._HashSet$d = private unnamed_addr constant { i64, i64 } { i64 471, i64 0 }
define ptr @df.mt.dart$3acollection._HashSet() {
b0:
  ret ptr @df.mt.dart$3acollection._HashSet$d
}
@df.mt.dart$3acollection._IdentityHashSet$d = private unnamed_addr constant { i64, i64 } { i64 475, i64 0 }
define ptr @df.mt.dart$3acollection._IdentityHashSet() {
b0:
  ret ptr @df.mt.dart$3acollection._IdentityHashSet$d
}
@df.mt.dart$3acollection._CustomHashSet$d = private unnamed_addr constant { i64, i64 } { i64 458, i64 0 }
define ptr @df.mt.dart$3acollection._CustomHashSet() {
b0:
  ret ptr @df.mt.dart$3acollection._CustomHashSet$d
}
@df.mt.dart$3acollection._HashSetEntry$d = private unnamed_addr constant { i64, i64 } { i64 472, i64 0 }
define ptr @df.mt.dart$3acollection._HashSetEntry() {
b0:
  ret ptr @df.mt.dart$3acollection._HashSetEntry$d
}
@df.mt.dart$3acollection._HashSetIterator$d = private unnamed_addr constant { i64, i64 } { i64 473, i64 0 }
define ptr @df.mt.dart$3acollection._HashSetIterator() {
b0:
  ret ptr @df.mt.dart$3acollection._HashSetIterator$d
}
@df.mt.dart$3amath.Point$d = private unnamed_addr constant { i64, i64 } { i64 927, i64 0 }
define ptr @df.mt.dart$3amath.Point() {
b0:
  ret ptr @df.mt.dart$3amath.Point$d
}
@df.mt.dart$3amath.Rectangle$d = private unnamed_addr constant { i64, i64 } { i64 929, i64 0 }
define ptr @df.mt.dart$3amath.Rectangle() {
b0:
  ret ptr @df.mt.dart$3amath.Rectangle$d
}
@df.mt.dart$3amath.MutableRectangle$d = private unnamed_addr constant { i64, i64 } { i64 926, i64 0 }
define ptr @df.mt.dart$3amath.MutableRectangle() {
b0:
  ret ptr @df.mt.dart$3amath.MutableRectangle$d
}
@df.mt.dart$3amath._Random$d = private unnamed_addr constant { i64, i64 } { i64 930, i64 0 }
define ptr @df.mt.dart$3amath._Random() {
b0:
  ret ptr @df.mt.dart$3amath._Random$d
}
@df.mt.dart$3amath._SecureRandom$d = private unnamed_addr constant { i64, i64 } { i64 932, i64 0 }
define ptr @df.mt.dart$3amath._SecureRandom() {
b0:
  ret ptr @df.mt.dart$3amath._SecureRandom$d
}
@df.mt.dart$3aconvert.AsciiCodec$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 496, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -7321284671083058388, ptr @df.dart$3aconvert.AsciiCodec.encoder$g, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -2518386335229436526, ptr @df.dart$3aconvert.AsciiCodec.encode$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aconvert.AsciiCodec() {
b0:
  ret ptr @df.mt.dart$3aconvert.AsciiCodec$d
}
@df.mt.dart$3aconvert._UnicodeSubsetEncoder$d = private unnamed_addr constant { i64, i64 } { i64 569, i64 0 }
define ptr @df.mt.dart$3aconvert._UnicodeSubsetEncoder() {
b0:
  ret ptr @df.mt.dart$3aconvert._UnicodeSubsetEncoder$d
}
@df.mt.dart$3aconvert.AsciiEncoder$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 498, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1047269154501687337, ptr @df.dart$3aconvert._UnicodeSubsetEncoder.convert$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5181780973078530013, ptr @df.dart$3aconvert._UnicodeSubsetEncoder.convert$tc, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aconvert.AsciiEncoder() {
b0:
  ret ptr @df.mt.dart$3aconvert.AsciiEncoder$d
}
@df.mt.dart$3aconvert._UnicodeSubsetEncoderSink$d = private unnamed_addr constant { i64, i64 } { i64 570, i64 0 }
define ptr @df.mt.dart$3aconvert._UnicodeSubsetEncoderSink() {
b0:
  ret ptr @df.mt.dart$3aconvert._UnicodeSubsetEncoderSink$d
}
@df.mt.dart$3aconvert.AsciiDecoder$d = private unnamed_addr constant { i64, i64 } { i64 497, i64 0 }
define ptr @df.mt.dart$3aconvert.AsciiDecoder() {
b0:
  ret ptr @df.mt.dart$3aconvert.AsciiDecoder$d
}
@df.mt.dart$3aconvert._ErrorHandlingAsciiDecoderSink$d = private unnamed_addr constant { i64, i64 } { i64 535, i64 0 }
define ptr @df.mt.dart$3aconvert._ErrorHandlingAsciiDecoderSink() {
b0:
  ret ptr @df.mt.dart$3aconvert._ErrorHandlingAsciiDecoderSink$d
}
@df.mt.dart$3aconvert._SimpleAsciiDecoderSink$d = private unnamed_addr constant { i64, i64 } { i64 562, i64 0 }
define ptr @df.mt.dart$3aconvert._SimpleAsciiDecoderSink() {
b0:
  ret ptr @df.mt.dart$3aconvert._SimpleAsciiDecoderSink$d
}
@df.mt.dart$3aconvert.Base64Codec$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 499, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -7321284671083058388, ptr @df.dart$3aconvert.Base64Codec.encoder$g, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -2518386335229436526, ptr @df.dart$3aconvert.Codec.encode$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aconvert.Base64Codec() {
b0:
  ret ptr @df.mt.dart$3aconvert.Base64Codec$d
}
@df.mt.dart$3aconvert.Base64Encoder$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 501, i64 8, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1047269154501687337, ptr @df.dart$3aconvert.Base64Encoder.convert$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aconvert.Base64Encoder() {
b0:
  ret ptr @df.mt.dart$3aconvert.Base64Encoder$d
}
@df.mt.dart$3aconvert._Base64Encoder$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 527, i64 11, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -2518386335229436526, ptr @df.dart$3aconvert._Base64Encoder.encode$c, i64 -1806741269412004236, ptr @df.dart$3aconvert._Base64Encoder.createBuffer$tc, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 2484290407240458902, ptr @df.dart$3aconvert._Base64Encoder.createBuffer$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5250651764170184588, ptr @df.dart$3aconvert._Base64Encoder.encode$tc, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aconvert._Base64Encoder() {
b0:
  ret ptr @df.mt.dart$3aconvert._Base64Encoder$d
}
@df.mt.dart$3aconvert._BufferCachingBase64Encoder$d = private unnamed_addr constant { i64, i64 } { i64 529, i64 0 }
define ptr @df.mt.dart$3aconvert._BufferCachingBase64Encoder() {
b0:
  ret ptr @df.mt.dart$3aconvert._BufferCachingBase64Encoder$d
}
@df.mt.dart$3aconvert._AsciiBase64EncoderSink$d = private unnamed_addr constant { i64, i64 } { i64 524, i64 0 }
define ptr @df.mt.dart$3aconvert._AsciiBase64EncoderSink() {
b0:
  ret ptr @df.mt.dart$3aconvert._AsciiBase64EncoderSink$d
}
@df.mt.dart$3aconvert._Utf8Base64EncoderSink$d = private unnamed_addr constant { i64, i64 } { i64 571, i64 0 }
define ptr @df.mt.dart$3aconvert._Utf8Base64EncoderSink() {
b0:
  ret ptr @df.mt.dart$3aconvert._Utf8Base64EncoderSink$d
}
@df.mt.dart$3aconvert.Base64Decoder$d = private unnamed_addr constant { i64, i64 } { i64 500, i64 0 }
define ptr @df.mt.dart$3aconvert.Base64Decoder() {
b0:
  ret ptr @df.mt.dart$3aconvert.Base64Decoder$d
}
@df.mt.dart$3aconvert._Base64Decoder$d = private unnamed_addr constant { i64, i64 } { i64 525, i64 0 }
define ptr @df.mt.dart$3aconvert._Base64Decoder() {
b0:
  ret ptr @df.mt.dart$3aconvert._Base64Decoder$d
}
@df.mt.dart$3aconvert._Base64DecoderSink$d = private unnamed_addr constant { i64, i64 } { i64 526, i64 0 }
define ptr @df.mt.dart$3aconvert._Base64DecoderSink() {
b0:
  ret ptr @df.mt.dart$3aconvert._Base64DecoderSink$d
}
@df.mt.dart$3aconvert._ByteAdapterSink$d = private unnamed_addr constant { i64, i64 } { i64 530, i64 0 }
define ptr @df.mt.dart$3aconvert._ByteAdapterSink() {
b0:
  ret ptr @df.mt.dart$3aconvert._ByteAdapterSink$d
}
@df.mt.dart$3aconvert._ByteCallbackSink$d = private unnamed_addr constant { i64, i64 } { i64 531, i64 0 }
define ptr @df.mt.dart$3aconvert._ByteCallbackSink() {
b0:
  ret ptr @df.mt.dart$3aconvert._ByteCallbackSink$d
}
@df.mt.dart$3aconvert._SimpleCallbackSink$d = private unnamed_addr constant { i64, i64 } { i64 563, i64 0 }
define ptr @df.mt.dart$3aconvert._SimpleCallbackSink() {
b0:
  ret ptr @df.mt.dart$3aconvert._SimpleCallbackSink$d
}
@df.mt.dart$3aconvert._ConverterStreamEventSink$d = private unnamed_addr constant { i64, i64 } { i64 534, i64 0 }
define ptr @df.mt.dart$3aconvert._ConverterStreamEventSink() {
b0:
  ret ptr @df.mt.dart$3aconvert._ConverterStreamEventSink$d
}
@df.mt.dart$3aconvert._FusedCodec$d = private unnamed_addr constant { i64, i64 } { i64 536, i64 0 }
define ptr @df.mt.dart$3aconvert._FusedCodec() {
b0:
  ret ptr @df.mt.dart$3aconvert._FusedCodec$d
}
@df.mt.dart$3aconvert._InvertedCodec$d = private unnamed_addr constant { i64, i64 } { i64 539, i64 0 }
define ptr @df.mt.dart$3aconvert._InvertedCodec() {
b0:
  ret ptr @df.mt.dart$3aconvert._InvertedCodec$d
}
@df.mt.dart$3aconvert._FusedConverter$d = private unnamed_addr constant { i64, i64 } { i64 537, i64 0 }
define ptr @df.mt.dart$3aconvert._FusedConverter() {
b0:
  ret ptr @df.mt.dart$3aconvert._FusedConverter$d
}
@df.mt.dart$3aconvert.HtmlEscapeMode$d = private unnamed_addr constant { i64, i64 } { i64 509, i64 0 }
define ptr @df.mt.dart$3aconvert.HtmlEscapeMode() {
b0:
  ret ptr @df.mt.dart$3aconvert.HtmlEscapeMode$d
}
@df.mt.dart$3aconvert.HtmlEscape$d = private unnamed_addr constant { i64, i64 } { i64 508, i64 0 }
define ptr @df.mt.dart$3aconvert.HtmlEscape() {
b0:
  ret ptr @df.mt.dart$3aconvert.HtmlEscape$d
}
@df.mt.dart$3aconvert._HtmlEscapeSink$d = private unnamed_addr constant { i64, i64 } { i64 538, i64 0 }
define ptr @df.mt.dart$3aconvert._HtmlEscapeSink() {
b0:
  ret ptr @df.mt.dart$3aconvert._HtmlEscapeSink$d
}
@df.mt.dart$3aconvert.JsonUnsupportedObjectError$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 514, i64 11, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -4713017734788692867, ptr @df.dart$3acore.Error.stackTrace$g, i64 -3709406022152324920, ptr @df.dart$3aconvert.JsonUnsupportedObjectError.unsupportedObject$g, i64 -3445551396850951156, ptr @df.dart$3aconvert.JsonUnsupportedObjectError.toString$c, i64 -2772688926328976598, ptr @df.dart$3acore.Error._stackTrace$g, i64 -1365383212321303145, ptr @df.dart$3aconvert.JsonUnsupportedObjectError.cause$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aconvert.JsonUnsupportedObjectError() {
b0:
  ret ptr @df.mt.dart$3aconvert.JsonUnsupportedObjectError$d
}
@df.mt.dart$3aconvert.JsonCyclicError$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 511, i64 11, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -4713017734788692867, ptr @df.dart$3acore.Error.stackTrace$g, i64 -3709406022152324920, ptr @df.dart$3aconvert.JsonUnsupportedObjectError.unsupportedObject$g, i64 -3445551396850951156, ptr @df.dart$3aconvert.JsonCyclicError.toString$c, i64 -2772688926328976598, ptr @df.dart$3acore.Error._stackTrace$g, i64 -1365383212321303145, ptr @df.dart$3aconvert.JsonUnsupportedObjectError.cause$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aconvert.JsonCyclicError() {
b0:
  ret ptr @df.mt.dart$3aconvert.JsonCyclicError$d
}
@df.mt.dart$3aconvert.JsonCodec$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 510, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -7321284671083058388, ptr @df.dart$3aconvert.JsonCodec.encoder$g, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -2518386335229436526, ptr @df.dart$3aconvert.JsonCodec.encode$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aconvert.JsonCodec() {
b0:
  ret ptr @df.mt.dart$3aconvert.JsonCodec$d
}
@df.mt.dart$3aconvert.JsonEncoder$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 513, i64 8, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1047269154501687337, ptr @df.dart$3aconvert.JsonEncoder.convert$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aconvert.JsonEncoder() {
b0:
  ret ptr @df.mt.dart$3aconvert.JsonEncoder$d
}
@df.mt.dart$3aconvert.JsonUtf8Encoder$d = private unnamed_addr constant { i64, i64 } { i64 515, i64 0 }
define ptr @df.mt.dart$3aconvert.JsonUtf8Encoder() {
b0:
  ret ptr @df.mt.dart$3aconvert.JsonUtf8Encoder$d
}
@df.mt.dart$3aconvert._JsonEncoderSink$d = private unnamed_addr constant { i64, i64 } { i64 540, i64 0 }
define ptr @df.mt.dart$3aconvert._JsonEncoderSink() {
b0:
  ret ptr @df.mt.dart$3aconvert._JsonEncoderSink$d
}
@df.mt.dart$3aconvert._JsonUtf8EncoderSink$d = private unnamed_addr constant { i64, i64 } { i64 551, i64 0 }
define ptr @df.mt.dart$3aconvert._JsonUtf8EncoderSink() {
b0:
  ret ptr @df.mt.dart$3aconvert._JsonUtf8EncoderSink$d
}
@df.mt.dart$3aconvert.JsonDecoder$d = private unnamed_addr constant { i64, i64 } { i64 512, i64 0 }
define ptr @df.mt.dart$3aconvert.JsonDecoder() {
b0:
  ret ptr @df.mt.dart$3aconvert.JsonDecoder$d
}
@df.mt.dart$3aconvert._JsonStringStringifier$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 546, i64 20, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8320256614231863842, ptr @df.dart$3aconvert._JsonStringStringifier.writeStringSlice$tc, i64 -7031269532819067186, ptr @df.dart$3aconvert._JsonStringStringifier.writeCharCode$c, i64 -6065592078353237928, ptr @df.dart$3aconvert._JsonStringStringifier.writeCharCode$tc, i64 -4474219463148976689, ptr @df.dart$3aconvert._JsonStringifier.writeList$c, i64 -3754853971900222795, ptr @df.dart$3aconvert._JsonStringifier.writeList$tc, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 1692164881211233650, ptr @df.dart$3aconvert._JsonStringStringifier.writeString$c, i64 2137997847641750037, ptr @df.dart$3aconvert._JsonStringStringifier._partialResult$g, i64 2689180964389530887, ptr @df.dart$3aconvert._JsonStringifier.writeMap$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5991571162677679380, ptr @df.dart$3aconvert._JsonStringStringifier.writeNumber$tc, i64 6094415875262469640, ptr @df.dart$3aconvert._JsonStringStringifier.writeStringSlice$c, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7104878213942739717, ptr @df.dart$3aconvert._JsonStringifier.writeMap$tc, i64 7284372429840147684, ptr @df.dart$3aconvert._JsonStringStringifier.writeString$tc, i64 7592819467428503238, ptr @df.dart$3aconvert._JsonStringStringifier.writeNumber$c }
define ptr @df.mt.dart$3aconvert._JsonStringStringifier() {
b0:
  ret ptr @df.mt.dart$3aconvert._JsonStringStringifier$d
}
@df.mt.dart$3aconvert._JsonStringStringifierPretty$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 547, i64 22, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8320256614231863842, ptr @df.dart$3aconvert._JsonStringStringifier.writeStringSlice$tc, i64 -7031269532819067186, ptr @df.dart$3aconvert._JsonStringStringifier.writeCharCode$c, i64 -6065592078353237928, ptr @df.dart$3aconvert._JsonStringStringifier.writeCharCode$tc, i64 -4474219463148976689, ptr @df.dart$3aconvert._JsonPrettyPrintMixin.writeList$c, i64 -3754853971900222795, ptr @df.dart$3aconvert._JsonPrettyPrintMixin.writeList$tc, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -2130555862457855050, ptr @df.dart$3aconvert._JsonStringStringifierPretty.writeIndentation$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 1692164881211233650, ptr @df.dart$3aconvert._JsonStringStringifier.writeString$c, i64 2137997847641750037, ptr @df.dart$3aconvert._JsonStringStringifier._partialResult$g, i64 2689180964389530887, ptr @df.dart$3aconvert._JsonPrettyPrintMixin.writeMap$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 3753908038128016236, ptr @df.dart$3aconvert._JsonStringStringifierPretty.writeIndentation$tc, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5991571162677679380, ptr @df.dart$3aconvert._JsonStringStringifier.writeNumber$tc, i64 6094415875262469640, ptr @df.dart$3aconvert._JsonStringStringifier.writeStringSlice$c, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7104878213942739717, ptr @df.dart$3aconvert._JsonPrettyPrintMixin.writeMap$tc, i64 7284372429840147684, ptr @df.dart$3aconvert._JsonStringStringifier.writeString$tc, i64 7592819467428503238, ptr @df.dart$3aconvert._JsonStringStringifier.writeNumber$c }
define ptr @df.mt.dart$3aconvert._JsonStringStringifierPretty() {
b0:
  ret ptr @df.mt.dart$3aconvert._JsonStringStringifierPretty$d
}
@df.mt.dart$3aconvert._JsonUtf8Stringifier$d = private unnamed_addr constant { i64, i64 } { i64 553, i64 0 }
define ptr @df.mt.dart$3aconvert._JsonUtf8Stringifier() {
b0:
  ret ptr @df.mt.dart$3aconvert._JsonUtf8Stringifier$d
}
@df.mt.dart$3aconvert._JsonUtf8StringifierPretty$d = private unnamed_addr constant { i64, i64 } { i64 554, i64 0 }
define ptr @df.mt.dart$3aconvert._JsonUtf8StringifierPretty() {
b0:
  ret ptr @df.mt.dart$3aconvert._JsonUtf8StringifierPretty$d
}
@df.mt.dart$3aconvert.Latin1Codec$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 516, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -7321284671083058388, ptr @df.dart$3aconvert.Latin1Codec.encoder$g, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -2518386335229436526, ptr @df.dart$3aconvert.Latin1Codec.encode$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aconvert.Latin1Codec() {
b0:
  ret ptr @df.mt.dart$3aconvert.Latin1Codec$d
}
@df.mt.dart$3aconvert.Latin1Encoder$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 518, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1047269154501687337, ptr @df.dart$3aconvert._UnicodeSubsetEncoder.convert$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5181780973078530013, ptr @df.dart$3aconvert._UnicodeSubsetEncoder.convert$tc, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aconvert.Latin1Encoder() {
b0:
  ret ptr @df.mt.dart$3aconvert.Latin1Encoder$d
}
@df.mt.dart$3aconvert.Latin1Decoder$d = private unnamed_addr constant { i64, i64 } { i64 517, i64 0 }
define ptr @df.mt.dart$3aconvert.Latin1Decoder() {
b0:
  ret ptr @df.mt.dart$3aconvert.Latin1Decoder$d
}
@df.mt.dart$3aconvert._Latin1DecoderSink$d = private unnamed_addr constant { i64, i64 } { i64 556, i64 0 }
define ptr @df.mt.dart$3aconvert._Latin1DecoderSink() {
b0:
  ret ptr @df.mt.dart$3aconvert._Latin1DecoderSink$d
}
@df.mt.dart$3aconvert._Latin1AllowInvalidDecoderSink$d = private unnamed_addr constant { i64, i64 } { i64 555, i64 0 }
define ptr @df.mt.dart$3aconvert._Latin1AllowInvalidDecoderSink() {
b0:
  ret ptr @df.mt.dart$3aconvert._Latin1AllowInvalidDecoderSink$d
}
@df.mt.dart$3aconvert.LineSplitter$d = private unnamed_addr constant { i64, i64 } { i64 519, i64 0 }
define ptr @df.mt.dart$3aconvert.LineSplitter() {
b0:
  ret ptr @df.mt.dart$3aconvert.LineSplitter$d
}
@df.mt.dart$3aconvert._LineSplitterSink$d = private unnamed_addr constant { i64, i64 } { i64 560, i64 0 }
define ptr @df.mt.dart$3aconvert._LineSplitterSink() {
b0:
  ret ptr @df.mt.dart$3aconvert._LineSplitterSink$d
}
@df.mt.dart$3aconvert._LineSplitterEventSink$d = private unnamed_addr constant { i64, i64 } { i64 559, i64 0 }
define ptr @df.mt.dart$3aconvert._LineSplitterEventSink() {
b0:
  ret ptr @df.mt.dart$3aconvert._LineSplitterEventSink$d
}
@df.mt.dart$3aconvert._LineSplitIterable$d = private unnamed_addr constant { i64, i64 } { i64 557, i64 0 }
define ptr @df.mt.dart$3aconvert._LineSplitIterable() {
b0:
  ret ptr @df.mt.dart$3aconvert._LineSplitIterable$d
}
@df.mt.dart$3aconvert._LineSplitIterator$d = private unnamed_addr constant { i64, i64 } { i64 558, i64 0 }
define ptr @df.mt.dart$3aconvert._LineSplitIterator() {
b0:
  ret ptr @df.mt.dart$3aconvert._LineSplitIterator$d
}
@df.mt.dart$3aconvert._ClosableStringSink$d = private unnamed_addr constant { i64, i64 } { i64 533, i64 0 }
define ptr @df.mt.dart$3aconvert._ClosableStringSink() {
b0:
  ret ptr @df.mt.dart$3aconvert._ClosableStringSink$d
}
@df.mt.dart$3aconvert._StringConversionSinkAsStringSinkAdapter$d = private unnamed_addr constant { i64, i64 } { i64 566, i64 0 }
define ptr @df.mt.dart$3aconvert._StringConversionSinkAsStringSinkAdapter() {
b0:
  ret ptr @df.mt.dart$3aconvert._StringConversionSinkAsStringSinkAdapter$d
}
@df.mt.dart$3aconvert._StringSinkConversionSink$d = private unnamed_addr constant { i64, i64 } { i64 567, i64 0 }
define ptr @df.mt.dart$3aconvert._StringSinkConversionSink() {
b0:
  ret ptr @df.mt.dart$3aconvert._StringSinkConversionSink$d
}
@df.mt.dart$3aconvert._StringCallbackSink$d = private unnamed_addr constant { i64, i64 } { i64 565, i64 0 }
define ptr @df.mt.dart$3aconvert._StringCallbackSink() {
b0:
  ret ptr @df.mt.dart$3aconvert._StringCallbackSink$d
}
@df.mt.dart$3aconvert._StringAdapterSink$d = private unnamed_addr constant { i64, i64 } { i64 564, i64 0 }
define ptr @df.mt.dart$3aconvert._StringAdapterSink() {
b0:
  ret ptr @df.mt.dart$3aconvert._StringAdapterSink$d
}
@df.mt.dart$3aconvert._Utf8StringSinkAdapter$d = private unnamed_addr constant { i64, i64 } { i64 576, i64 0 }
define ptr @df.mt.dart$3aconvert._Utf8StringSinkAdapter() {
b0:
  ret ptr @df.mt.dart$3aconvert._Utf8StringSinkAdapter$d
}
@df.mt.dart$3aconvert._Utf8ConversionSink$d = private unnamed_addr constant { i64, i64 } { i64 572, i64 0 }
define ptr @df.mt.dart$3aconvert._Utf8ConversionSink() {
b0:
  ret ptr @df.mt.dart$3aconvert._Utf8ConversionSink$d
}
@df.mt.dart$3aconvert.Utf8Codec$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 521, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -7321284671083058388, ptr @df.dart$3aconvert.Utf8Codec.encoder$g, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -2518386335229436526, ptr @df.dart$3aconvert.Utf8Codec.encode$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aconvert.Utf8Codec() {
b0:
  ret ptr @df.mt.dart$3aconvert.Utf8Codec$d
}
@df.mt.dart$3aconvert.Utf8Encoder$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 523, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1047269154501687337, ptr @df.dart$3aconvert.Utf8Encoder.convert$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5181780973078530013, ptr @df.dart$3aconvert.Utf8Encoder.convert$tc, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aconvert.Utf8Encoder() {
b0:
  ret ptr @df.mt.dart$3aconvert.Utf8Encoder$d
}
@df.mt.dart$3aconvert._Utf8Encoder$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 574, i64 7, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aconvert._Utf8Encoder() {
b0:
  ret ptr @df.mt.dart$3aconvert._Utf8Encoder$d
}
@df.mt.dart$3aconvert._Utf8EncoderSink$d = private unnamed_addr constant { i64, i64 } { i64 575, i64 0 }
define ptr @df.mt.dart$3aconvert._Utf8EncoderSink() {
b0:
  ret ptr @df.mt.dart$3aconvert._Utf8EncoderSink$d
}
@df.mt.dart$3aconvert.Utf8Decoder$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 522, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1047269154501687337, ptr @df.dart$3aconvert.Utf8Decoder.convert$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5181780973078530013, ptr @df.dart$3aconvert.Utf8Decoder.convert$tc, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aconvert.Utf8Decoder() {
b0:
  ret ptr @df.mt.dart$3aconvert.Utf8Decoder$d
}
@df.mt.dart$3aconvert._Utf8Decoder$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 573, i64 7, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aconvert._Utf8Decoder() {
b0:
  ret ptr @df.mt.dart$3aconvert._Utf8Decoder$d
}
@df.mt.dart$3aconvert._JsonUtf8Decoder$d = private unnamed_addr constant { i64, i64 } { i64 549, i64 0 }
define ptr @df.mt.dart$3aconvert._JsonUtf8Decoder() {
b0:
  ret ptr @df.mt.dart$3aconvert._JsonUtf8Decoder$d
}
@df.mt.dart$3aconvert._JsonListener$d = private unnamed_addr constant { i64, i64 } { i64 541, i64 0 }
define ptr @df.mt.dart$3aconvert._JsonListener() {
b0:
  ret ptr @df.mt.dart$3aconvert._JsonListener$d
}
@df.mt.dart$3aconvert._NumberBuffer$d = private unnamed_addr constant { i64, i64 } { i64 561, i64 0 }
define ptr @df.mt.dart$3aconvert._NumberBuffer() {
b0:
  ret ptr @df.mt.dart$3aconvert._NumberBuffer$d
}
@df.mt.dart$3aconvert._JsonStringParser$d = private unnamed_addr constant { i64, i64 } { i64 545, i64 0 }
define ptr @df.mt.dart$3aconvert._JsonStringParser() {
b0:
  ret ptr @df.mt.dart$3aconvert._JsonStringParser$d
}
@df.mt.dart$3aconvert._JsonStringDecoderSink$d = private unnamed_addr constant { i64, i64 } { i64 544, i64 0 }
define ptr @df.mt.dart$3aconvert._JsonStringDecoderSink() {
b0:
  ret ptr @df.mt.dart$3aconvert._JsonStringDecoderSink$d
}
@df.mt.dart$3aconvert._JsonUtf8Parser$d = private unnamed_addr constant { i64, i64 } { i64 552, i64 0 }
define ptr @df.mt.dart$3aconvert._JsonUtf8Parser() {
b0:
  ret ptr @df.mt.dart$3aconvert._JsonUtf8Parser$d
}
@df.mt.dart$3aconvert._JsonUtf8DecoderSink$d = private unnamed_addr constant { i64, i64 } { i64 550, i64 0 }
define ptr @df.mt.dart$3aconvert._JsonUtf8DecoderSink() {
b0:
  ret ptr @df.mt.dart$3aconvert._JsonUtf8DecoderSink$d
}
@df.mt.dart$3aasync.AsyncError$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 338, i64 8, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -4713017734788692867, ptr @df.dart$3aasync.AsyncError.stackTrace$g, i64 -3445551396850951156, ptr @df.dart$3aasync.AsyncError.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aasync.AsyncError() {
b0:
  ret ptr @df.mt.dart$3aasync.AsyncError$d
}
@df.mt.dart$3aasync._BroadcastStream$d = private unnamed_addr constant { i64, i64 } { i64 374, i64 0 }
define ptr @df.mt.dart$3aasync._BroadcastStream() {
b0:
  ret ptr @df.mt.dart$3aasync._BroadcastStream$d
}
@df.mt.dart$3aasync._BroadcastSubscription$d = private unnamed_addr constant { i64, i64 } { i64 376, i64 0 }
define ptr @df.mt.dart$3aasync._BroadcastSubscription() {
b0:
  ret ptr @df.mt.dart$3aasync._BroadcastSubscription$d
}
@df.mt.dart$3aasync._SyncBroadcastStreamController$d = private unnamed_addr constant { i64, i64 } { i64 423, i64 0 }
define ptr @df.mt.dart$3aasync._SyncBroadcastStreamController() {
b0:
  ret ptr @df.mt.dart$3aasync._SyncBroadcastStreamController$d
}
@df.mt.dart$3aasync._AsyncBroadcastStreamController$d = private unnamed_addr constant { i64, i64 } { i64 365, i64 0 }
define ptr @df.mt.dart$3aasync._AsyncBroadcastStreamController() {
b0:
  ret ptr @df.mt.dart$3aasync._AsyncBroadcastStreamController$d
}
@df.mt.dart$3aasync._AsBroadcastStreamController$d = private unnamed_addr constant { i64, i64 } { i64 363, i64 0 }
define ptr @df.mt.dart$3aasync._AsBroadcastStreamController() {
b0:
  ret ptr @df.mt.dart$3aasync._AsBroadcastStreamController$d
}
@df.mt.dart$3aasync.DeferredLoadException$d = private unnamed_addr constant { i64, i64 } { i64 340, i64 0 }
define ptr @df.mt.dart$3aasync.DeferredLoadException() {
b0:
  ret ptr @df.mt.dart$3aasync.DeferredLoadException$d
}
@df.mt.dart$3aasync.TimeoutException$d = private unnamed_addr constant { i64, i64 } { i64 356, i64 0 }
define ptr @df.mt.dart$3aasync.TimeoutException() {
b0:
  ret ptr @df.mt.dart$3aasync.TimeoutException$d
}
@df.mt.dart$3aasync.ParallelWaitError$d = private unnamed_addr constant { i64, i64 } { i64 345, i64 0 }
define ptr @df.mt.dart$3aasync.ParallelWaitError() {
b0:
  ret ptr @df.mt.dart$3aasync.ParallelWaitError$d
}
@df.mt.dart$3aasync._FutureResult$d = private unnamed_addr constant { i64, i64 } { i64 400, i64 0 }
define ptr @df.mt.dart$3aasync._FutureResult() {
b0:
  ret ptr @df.mt.dart$3aasync._FutureResult$d
}
@df.mt.dart$3aasync._AsyncCompleter$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 367, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -6597723718937650565, ptr @df.dart$3aasync._Completer.future$g, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 8784601842970574303, ptr @df.dart$3aasync._AsyncCompleter.complete$c }
define ptr @df.mt.dart$3aasync._AsyncCompleter() {
b0:
  ret ptr @df.mt.dart$3aasync._AsyncCompleter$d
}
@df.mt.dart$3aasync._SyncCompleter$d = private unnamed_addr constant { i64, i64 } { i64 424, i64 0 }
define ptr @df.mt.dart$3aasync._SyncCompleter() {
b0:
  ret ptr @df.mt.dart$3aasync._SyncCompleter$d
}
@df.mt.dart$3aasync._FutureListener$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 399, i64 8, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 48430606180818049, ptr @df.dart$3aasync._FutureListener.errorCallback$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aasync._FutureListener() {
b0:
  ret ptr @df.mt.dart$3aasync._FutureListener$d
}
@df.mt.dart$3aasync._Future$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 398, i64 10, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -5138076544193824671, ptr @df.dart$3aasync._Future.then$tc, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -2078691453183203609, ptr @df.dart$3aasync._Future.then$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5993617609980764391, ptr @df.dart$3aasync._Future.whenComplete$c, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aasync._Future() {
b0:
  ret ptr @df.mt.dart$3aasync._Future$d
}
@df.mt.dart$3aasync._AsyncCallbackEntry$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 366, i64 7, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aasync._AsyncCallbackEntry() {
b0:
  ret ptr @df.mt.dart$3aasync._AsyncCallbackEntry$d
}
@df.mt.dart$3aasync._AsyncRun$d = private unnamed_addr constant { i64, i64 } { i64 368, i64 0 }
define ptr @df.mt.dart$3aasync._AsyncRun() {
b0:
  ret ptr @df.mt.dart$3aasync._AsyncRun$d
}
@df.mt.dart$3aasync.StreamView$d = private unnamed_addr constant { i64, i64 } { i64 354, i64 0 }
define ptr @df.mt.dart$3aasync.StreamView() {
b0:
  ret ptr @df.mt.dart$3aasync.StreamView$d
}
@df.mt.dart$3aasync._ControllerEventSinkWrapper$d = private unnamed_addr constant { i64, i64 } { i64 380, i64 0 }
define ptr @df.mt.dart$3aasync._ControllerEventSinkWrapper() {
b0:
  ret ptr @df.mt.dart$3aasync._ControllerEventSinkWrapper$d
}
@df.mt.dart$3aasync._AsyncStreamController$d = private unnamed_addr constant { i64, i64 } { i64 370, i64 0 }
define ptr @df.mt.dart$3aasync._AsyncStreamController() {
b0:
  ret ptr @df.mt.dart$3aasync._AsyncStreamController$d
}
@df.mt.dart$3aasync._SyncStreamController$d = private unnamed_addr constant { i64, i64 } { i64 427, i64 0 }
define ptr @df.mt.dart$3aasync._SyncStreamController() {
b0:
  ret ptr @df.mt.dart$3aasync._SyncStreamController$d
}
@df.mt.dart$3aasync._ControllerStream$d = private unnamed_addr constant { i64, i64 } { i64 381, i64 0 }
define ptr @df.mt.dart$3aasync._ControllerStream() {
b0:
  ret ptr @df.mt.dart$3aasync._ControllerStream$d
}
@df.mt.dart$3aasync._ControllerSubscription$d = private unnamed_addr constant { i64, i64 } { i64 382, i64 0 }
define ptr @df.mt.dart$3aasync._ControllerSubscription() {
b0:
  ret ptr @df.mt.dart$3aasync._ControllerSubscription$d
}
@df.mt.dart$3aasync._StreamSinkWrapper$d = private unnamed_addr constant { i64, i64 } { i64 421, i64 0 }
define ptr @df.mt.dart$3aasync._StreamSinkWrapper() {
b0:
  ret ptr @df.mt.dart$3aasync._StreamSinkWrapper$d
}
@df.mt.dart$3aasync._AddStreamState$d = private unnamed_addr constant { i64, i64 } { i64 361, i64 0 }
define ptr @df.mt.dart$3aasync._AddStreamState() {
b0:
  ret ptr @df.mt.dart$3aasync._AddStreamState$d
}
@df.mt.dart$3aasync._StreamControllerAddStreamState$d = private unnamed_addr constant { i64, i64 } { i64 414, i64 0 }
define ptr @df.mt.dart$3aasync._StreamControllerAddStreamState() {
b0:
  ret ptr @df.mt.dart$3aasync._StreamControllerAddStreamState$d
}
@df.mt.dart$3aasync._BufferingStreamSubscription$d = private unnamed_addr constant { i64, i64 } { i64 378, i64 0 }
define ptr @df.mt.dart$3aasync._BufferingStreamSubscription() {
b0:
  ret ptr @df.mt.dart$3aasync._BufferingStreamSubscription$d
}
@df.mt.dart$3aasync._DelayedData$d = private unnamed_addr constant { i64, i64 } { i64 384, i64 0 }
define ptr @df.mt.dart$3aasync._DelayedData() {
b0:
  ret ptr @df.mt.dart$3aasync._DelayedData$d
}
@df.mt.dart$3aasync._DelayedError$d = private unnamed_addr constant { i64, i64 } { i64 386, i64 0 }
define ptr @df.mt.dart$3aasync._DelayedError() {
b0:
  ret ptr @df.mt.dart$3aasync._DelayedError$d
}
@df.mt.dart$3aasync._DelayedDone$d = private unnamed_addr constant { i64, i64 } { i64 385, i64 0 }
define ptr @df.mt.dart$3aasync._DelayedDone() {
b0:
  ret ptr @df.mt.dart$3aasync._DelayedDone$d
}
@df.mt.dart$3aasync._PendingEvents$d = private unnamed_addr constant { i64, i64 } { i64 406, i64 0 }
define ptr @df.mt.dart$3aasync._PendingEvents() {
b0:
  ret ptr @df.mt.dart$3aasync._PendingEvents$d
}
@df.mt.dart$3aasync._DoneStreamSubscription$d = private unnamed_addr constant { i64, i64 } { i64 390, i64 0 }
define ptr @df.mt.dart$3aasync._DoneStreamSubscription() {
b0:
  ret ptr @df.mt.dart$3aasync._DoneStreamSubscription$d
}
@df.mt.dart$3aasync._AsBroadcastStream$d = private unnamed_addr constant { i64, i64 } { i64 362, i64 0 }
define ptr @df.mt.dart$3aasync._AsBroadcastStream() {
b0:
  ret ptr @df.mt.dart$3aasync._AsBroadcastStream$d
}
@df.mt.dart$3aasync._BroadcastSubscriptionWrapper$d = private unnamed_addr constant { i64, i64 } { i64 377, i64 0 }
define ptr @df.mt.dart$3aasync._BroadcastSubscriptionWrapper() {
b0:
  ret ptr @df.mt.dart$3aasync._BroadcastSubscriptionWrapper$d
}
@df.mt.dart$3aasync._StreamIterator$d = private unnamed_addr constant { i64, i64 } { i64 419, i64 0 }
define ptr @df.mt.dart$3aasync._StreamIterator() {
b0:
  ret ptr @df.mt.dart$3aasync._StreamIterator$d
}
@df.mt.dart$3aasync._EmptyStream$d = private unnamed_addr constant { i64, i64 } { i64 391, i64 0 }
define ptr @df.mt.dart$3aasync._EmptyStream() {
b0:
  ret ptr @df.mt.dart$3aasync._EmptyStream$d
}
@df.mt.dart$3aasync._MultiStream$d = private unnamed_addr constant { i64, i64 } { i64 404, i64 0 }
define ptr @df.mt.dart$3aasync._MultiStream() {
b0:
  ret ptr @df.mt.dart$3aasync._MultiStream$d
}
@df.mt.dart$3aasync._MultiStreamController$d = private unnamed_addr constant { i64, i64 } { i64 405, i64 0 }
define ptr @df.mt.dart$3aasync._MultiStreamController() {
b0:
  ret ptr @df.mt.dart$3aasync._MultiStreamController$d
}
@df.mt.dart$3aasync._ForwardingStreamSubscription$d = private unnamed_addr constant { i64, i64 } { i64 397, i64 0 }
define ptr @df.mt.dart$3aasync._ForwardingStreamSubscription() {
b0:
  ret ptr @df.mt.dart$3aasync._ForwardingStreamSubscription$d
}
@df.mt.dart$3aasync._WhereStream$d = private unnamed_addr constant { i64, i64 } { i64 432, i64 0 }
define ptr @df.mt.dart$3aasync._WhereStream() {
b0:
  ret ptr @df.mt.dart$3aasync._WhereStream$d
}
@df.mt.dart$3aasync._MapStream$d = private unnamed_addr constant { i64, i64 } { i64 403, i64 0 }
define ptr @df.mt.dart$3aasync._MapStream() {
b0:
  ret ptr @df.mt.dart$3aasync._MapStream$d
}
@df.mt.dart$3aasync._ExpandStream$d = private unnamed_addr constant { i64, i64 } { i64 395, i64 0 }
define ptr @df.mt.dart$3aasync._ExpandStream() {
b0:
  ret ptr @df.mt.dart$3aasync._ExpandStream$d
}
@df.mt.dart$3aasync._HandleErrorStream$d = private unnamed_addr constant { i64, i64 } { i64 401, i64 0 }
define ptr @df.mt.dart$3aasync._HandleErrorStream() {
b0:
  ret ptr @df.mt.dart$3aasync._HandleErrorStream$d
}
@df.mt.dart$3aasync._TakeStream$d = private unnamed_addr constant { i64, i64 } { i64 429, i64 0 }
define ptr @df.mt.dart$3aasync._TakeStream() {
b0:
  ret ptr @df.mt.dart$3aasync._TakeStream$d
}
@df.mt.dart$3aasync._StateStreamSubscription$d = private unnamed_addr constant { i64, i64 } { i64 411, i64 0 }
define ptr @df.mt.dart$3aasync._StateStreamSubscription() {
b0:
  ret ptr @df.mt.dart$3aasync._StateStreamSubscription$d
}
@df.mt.dart$3aasync._TakeWhileStream$d = private unnamed_addr constant { i64, i64 } { i64 430, i64 0 }
define ptr @df.mt.dart$3aasync._TakeWhileStream() {
b0:
  ret ptr @df.mt.dart$3aasync._TakeWhileStream$d
}
@df.mt.dart$3aasync._SkipStream$d = private unnamed_addr constant { i64, i64 } { i64 409, i64 0 }
define ptr @df.mt.dart$3aasync._SkipStream() {
b0:
  ret ptr @df.mt.dart$3aasync._SkipStream$d
}
@df.mt.dart$3aasync._SkipWhileStream$d = private unnamed_addr constant { i64, i64 } { i64 410, i64 0 }
define ptr @df.mt.dart$3aasync._SkipWhileStream() {
b0:
  ret ptr @df.mt.dart$3aasync._SkipWhileStream$d
}
@df.mt.dart$3aasync._DistinctStream$d = private unnamed_addr constant { i64, i64 } { i64 389, i64 0 }
define ptr @df.mt.dart$3aasync._DistinctStream() {
b0:
  ret ptr @df.mt.dart$3aasync._DistinctStream$d
}
@df.mt.dart$3aasync._EventSinkWrapper$d = private unnamed_addr constant { i64, i64 } { i64 394, i64 0 }
define ptr @df.mt.dart$3aasync._EventSinkWrapper() {
b0:
  ret ptr @df.mt.dart$3aasync._EventSinkWrapper$d
}
@df.mt.dart$3aasync._SinkTransformerStreamSubscription$d = private unnamed_addr constant { i64, i64 } { i64 408, i64 0 }
define ptr @df.mt.dart$3aasync._SinkTransformerStreamSubscription() {
b0:
  ret ptr @df.mt.dart$3aasync._SinkTransformerStreamSubscription$d
}
@df.mt.dart$3aasync._StreamSinkTransformer$d = private unnamed_addr constant { i64, i64 } { i64 420, i64 0 }
define ptr @df.mt.dart$3aasync._StreamSinkTransformer() {
b0:
  ret ptr @df.mt.dart$3aasync._StreamSinkTransformer$d
}
@df.mt.dart$3aasync._BoundSinkStream$d = private unnamed_addr constant { i64, i64 } { i64 372, i64 0 }
define ptr @df.mt.dart$3aasync._BoundSinkStream() {
b0:
  ret ptr @df.mt.dart$3aasync._BoundSinkStream$d
}
@df.mt.dart$3aasync._HandlerEventSink$d = private unnamed_addr constant { i64, i64 } { i64 402, i64 0 }
define ptr @df.mt.dart$3aasync._HandlerEventSink() {
b0:
  ret ptr @df.mt.dart$3aasync._HandlerEventSink$d
}
@df.mt.dart$3aasync._StreamHandlerTransformer$d = private unnamed_addr constant { i64, i64 } { i64 417, i64 0 }
define ptr @df.mt.dart$3aasync._StreamHandlerTransformer() {
b0:
  ret ptr @df.mt.dart$3aasync._StreamHandlerTransformer$d
}
@df.mt.dart$3aasync._StreamBindTransformer$d = private unnamed_addr constant { i64, i64 } { i64 412, i64 0 }
define ptr @df.mt.dart$3aasync._StreamBindTransformer() {
b0:
  ret ptr @df.mt.dart$3aasync._StreamBindTransformer$d
}
@df.mt.dart$3aasync._StreamSubscriptionTransformer$d = private unnamed_addr constant { i64, i64 } { i64 422, i64 0 }
define ptr @df.mt.dart$3aasync._StreamSubscriptionTransformer() {
b0:
  ret ptr @df.mt.dart$3aasync._StreamSubscriptionTransformer$d
}
@df.mt.dart$3aasync._BoundSubscriptionStream$d = private unnamed_addr constant { i64, i64 } { i64 373, i64 0 }
define ptr @df.mt.dart$3aasync._BoundSubscriptionStream() {
b0:
  ret ptr @df.mt.dart$3aasync._BoundSubscriptionStream$d
}
@df.mt.dart$3aasync._ZoneFunction$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 435, i64 7, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aasync._ZoneFunction() {
b0:
  ret ptr @df.mt.dart$3aasync._ZoneFunction$d
}
@df.mt.dart$3aasync._ZoneSpecification$d = private unnamed_addr constant { i64, i64 } { i64 436, i64 0 }
define ptr @df.mt.dart$3aasync._ZoneSpecification() {
b0:
  ret ptr @df.mt.dart$3aasync._ZoneSpecification$d
}
@df.mt.dart$3aasync._ZoneDelegate$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 434, i64 27, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8710877833121588872, ptr @df.dart$3aasync._ZoneDelegate.scheduleMicrotask$tc, i64 -8244634277810739333, ptr @df.dart$3aasync._ZoneDelegate.registerBinaryCallback$c, i64 -8055131169175262508, ptr @df.dart$3aasync._ZoneDelegate.runBinary$c, i64 -7269394859215955030, ptr @df.dart$3aasync._ZoneDelegate.runBinary$tc, i64 -5476924621088962099, ptr @df.dart$3aasync._ZoneDelegate.registerBinaryCallback$tc, i64 -5459233527952726237, ptr @df.dart$3aasync._ZoneDelegate.errorCallback$tc, i64 -5226054959052517560, ptr @df.dart$3aasync._ZoneDelegate.runUnary$c, i64 -5114293724581107891, ptr @df.dart$3aasync._ZoneDelegate.run$c, i64 -3832438578136438947, ptr @df.dart$3aasync._ZoneDelegate.createTimer$c, i64 -3521105203390658240, ptr @df.dart$3aasync._ZoneDelegate.registerCallback$tc, i64 -3506328106873284090, ptr @df.dart$3aasync._ZoneDelegate.runUnary$tc, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -3341039212870587661, ptr @df.dart$3aasync._ZoneDelegate.handleUncaughtError$tc, i64 -3249455508477993721, ptr @df.dart$3aasync._ZoneDelegate.run$tc, i64 -2806494481367636551, ptr @df.dart$3aasync._ZoneDelegate.handleUncaughtError$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 48430606180818049, ptr @df.dart$3aasync._ZoneDelegate.errorCallback$c, i64 544004507689246041, ptr @df.dart$3aasync._ZoneDelegate.registerUnaryCallback$tc, i64 3237293233194598139, ptr @df.dart$3aasync._ZoneDelegate.createTimer$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5320832679958428338, ptr @df.dart$3aasync._ZoneDelegate.registerCallback$c, i64 5573840302760808778, ptr @df.dart$3aasync._ZoneDelegate.scheduleMicrotask$c, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7808517781898044271, ptr @df.dart$3aasync._ZoneDelegate.registerUnaryCallback$c }
define ptr @df.mt.dart$3aasync._ZoneDelegate() {
b0:
  ret ptr @df.mt.dart$3aasync._ZoneDelegate$d
}
@df.mt.dart$3aasync._CustomZone$d = private unnamed_addr constant { i64, i64 } { i64 383, i64 0 }
define ptr @df.mt.dart$3aasync._CustomZone() {
b0:
  ret ptr @df.mt.dart$3aasync._CustomZone$d
}
@df.mt.dart$3aasync._RootZone$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 407, i64 39, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -9073847788167069060, ptr @df.dart$3aasync._RootZone.parent$g, i64 -8244634277810739333, ptr @df.dart$3aasync._RootZone.registerBinaryCallback$c, i64 -8055131169175262508, ptr @df.dart$3aasync._RootZone.runBinary$c, i64 -7614950032159781365, ptr @df.dart$3aasync._RootZone.bindUnaryCallbackGuarded$c, i64 -7389736200433238807, ptr @df.dart$3aasync._RootZone._createTimer$g, i64 -5659364709282068763, ptr @df.dart$3aasync._RootZone._registerBinaryCallback$g, i64 -5520834897069279500, ptr @df.dart$3aasync._RootZone.bindCallbackGuarded$c, i64 -5459233527952726237, ptr @df.dart$3aasync._RootZone.errorCallback$tc, i64 -5226054959052517560, ptr @df.dart$3aasync._RootZone.runUnary$c, i64 -5114293724581107891, ptr @df.dart$3aasync._RootZone.run$c, i64 -4941324565075902423, ptr @df.dart$3aasync._RootZone._run$g, i64 -3994858279131191926, ptr @df.dart$3aasync._RootZone._runBinary$g, i64 -3832438578136438947, ptr @df.dart$3aasync._RootZone.createTimer$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -3341039212870587661, ptr @df.dart$3aasync._RootZone.handleUncaughtError$tc, i64 -2806494481367636551, ptr @df.dart$3aasync._RootZone.handleUncaughtError$c, i64 -1592139980033640380, ptr @df.dart$3aasync._RootZone._runUnary$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 48430606180818049, ptr @df.dart$3aasync._RootZone.errorCallback$c, i64 158808971994848765, ptr @df.dart$3aasync._RootZone._handleUncaughtError$g, i64 382026248241879385, ptr @df.dart$3aasync._RootZone._delegate$g, i64 938695871837053633, ptr @df.dart$3aasync._RootZone._errorCallback$g, i64 1435367090964259548, ptr @df.dart$3aasync._RootZone.errorZone$g, i64 1606169432606192764, ptr @df.dart$3aasync._RootZone._scheduleMicrotask$g, i64 1650966719275361496, ptr @df.dart$3aasync._RootZone.bindCallback$c, i64 3237293233194598139, ptr @df.dart$3aasync._RootZone.createTimer$tc, i64 3598991429344932474, ptr @df.dart$3aasync._RootZone._registerCallback$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 3921420907284624277, ptr @df.dart$3aasync._RootZone.bindBinaryCallback$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4513061475814744281, ptr @df.dart$3aasync._RootZone._parentDelegate$g, i64 4969880521667493223, ptr @df.dart$3aasync._RootZone._registerUnaryCallback$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5320832679958428338, ptr @df.dart$3aasync._RootZone.registerCallback$c, i64 5573840302760808778, ptr @df.dart$3aasync._RootZone.scheduleMicrotask$c, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7808517781898044271, ptr @df.dart$3aasync._RootZone.registerUnaryCallback$c, i64 9189246021676726028, ptr @df.dart$3aasync._RootZone.$5b$5d$c }
define ptr @df.mt.dart$3aasync._RootZone() {
b0:
  ret ptr @df.mt.dart$3aasync._RootZone$d
}
@df.mt.dart$3aasync._DfAsyncError$d = private unnamed_addr constant { i64, i64 } { i64 388, i64 0 }
define ptr @df.mt.dart$3aasync._DfAsyncError() {
b0:
  ret ptr @df.mt.dart$3aasync._DfAsyncError$d
}
@df.mt.dart$3aasync._AsyncAwaitCompleter$d = private unnamed_addr constant { i64, i64 } { i64 364, i64 0 }
define ptr @df.mt.dart$3aasync._AsyncAwaitCompleter() {
b0:
  ret ptr @df.mt.dart$3aasync._AsyncAwaitCompleter$d
}
@df.mt.dart$3aasync._SyncStarIterable$d = private unnamed_addr constant { i64, i64 } { i64 425, i64 0 }
define ptr @df.mt.dart$3aasync._SyncStarIterable() {
b0:
  ret ptr @df.mt.dart$3aasync._SyncStarIterable$d
}
@df.mt.dart$3aasync._SyncStarIterator$d = private unnamed_addr constant { i64, i64 } { i64 426, i64 0 }
define ptr @df.mt.dart$3aasync._SyncStarIterator() {
b0:
  ret ptr @df.mt.dart$3aasync._SyncStarIterator$d
}
@df.mt.dart$3aasync._AsyncStarStreamController$d = private unnamed_addr constant { i64, i64 } { i64 369, i64 0 }
define ptr @df.mt.dart$3aasync._AsyncStarStreamController() {
b0:
  ret ptr @df.mt.dart$3aasync._AsyncStarStreamController$d
}
@df.mt.dart$3aasync._Timer$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 431, i64 7, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aasync._Timer() {
b0:
  ret ptr @df.mt.dart$3aasync._Timer$d
}
@df.mt.dart$3atyped_data.Endian$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 962, i64 7, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3atyped_data.Endian() {
b0:
  ret ptr @df.mt.dart$3atyped_data.Endian$d
}
@df.mt.dart$3atyped_data._ByteBuffer$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 982, i64 12, i64 -9163797671095228218, ptr @df.dart$3atyped_data._ByteBuffer.$3d$3d$c, i64 -8388772020220820974, ptr @df.dart$3atyped_data._ByteBuffer.asByteData$c, i64 -7802178253387990488, ptr @df.dart$3atyped_data._ByteBuffer.asUint8List$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 2835490342844453032, ptr @df.dart$3atyped_data._ByteBuffer.asByteData$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3atyped_data._ByteBuffer.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 6457676092542964098, ptr @df.dart$3atyped_data._ByteBuffer.lengthInBytes$g, i64 6646197143227882406, ptr @df.dart$3atyped_data._ByteBuffer.asUint8List$tc, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3atyped_data._ByteBuffer() {
b0:
  ret ptr @df.mt.dart$3atyped_data._ByteBuffer$d
}
@df.mt.dart$3atyped_data._Int8List$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 22, i64 51, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8971153493902442575, ptr @df.dart$3atyped_data._Int8List.$5b$5d$3d$tc, i64 -8113821193935802361, ptr @df.dart$3atyped_data._Int8List._createList$tc, i64 -7830014244959264555, ptr @df.dart$3atyped_data._Int8List.elementSizeInBytes$g, i64 -7142806495848668844, ptr @df.dart$3atyped_data._IntListMixin.last$g, i64 -7048868133546680485, ptr @df.dart$3atyped_data._IntListMixin.toList$tc, i64 -6880024560892829041, ptr @df.dart$3atyped_data._IntListMixin.skip$c, i64 -6565620648322651272, ptr @df.dart$3atyped_data._TypedListBase.length$g, i64 -6455655928913991845, ptr @df.dart$3atyped_data._IntListMixin.take$c, i64 -5476269667379286226, ptr @df.dart$3atyped_data._IntListMixin.iterator$g, i64 -4183823290162052582, ptr @df.dart$3atyped_data._TypedListBase.join$tc, i64 -3583372486457872994, ptr @df.dart$3atyped_data._Int8List._fastSetRange$c, i64 -3445551396850951156, ptr @df.dart$3atyped_data._TypedListBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3atyped_data._TypedListBase.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3atyped_data._IntListMixin.elementAt$c, i64 -2865225933037962029, ptr @df.dart$3atyped_data._IntListMixin.indexOf$tc, i64 -2322265645133230011, ptr @df.dart$3atyped_data._IntListMixin.skip$tc, i64 -2266111775014587155, ptr @df.dart$3atyped_data._TypedIntListMixin._slowSetRange$c, i64 -1759784064291000274, ptr @df.dart$3atyped_data._TypedList.buffer$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3atyped_data._TypedListBase.remove$c, i64 -921892303864442672, ptr @df.dart$3atyped_data._IntListMixin.removeLast$c, i64 -730073319095210781, ptr @df.dart$3atyped_data._IntListMixin.elementAt$tc, i64 -677989548411720471, ptr @df.dart$3atyped_data._IntListMixin.$2b$c, i64 -503246348505971594, ptr @df.dart$3atyped_data._IntListMixin.fillRange$c, i64 -8944174681508873, ptr @df.dart$3atyped_data._TypedList.offsetInBytes$g, i64 590583546444750725, ptr @df.dart$3atyped_data._IntListMixin.take$tc, i64 1309726782632086582, ptr @df.dart$3atyped_data._TypedListBase.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3atyped_data._IntListMixin.toList$c, i64 1890975232377856814, ptr @df.dart$3atyped_data._IntListMixin.map$c, i64 2870274114568068918, ptr @df.dart$3atyped_data._Int8List.$5b$5d$tc, i64 3251101298082571214, ptr @df.dart$3atyped_data._IntListMixin.forEach$c, i64 3337248483243775250, ptr @df.dart$3atyped_data._TypedListBase._containsUnsignedBytes$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 3785544036535605593, ptr @df.dart$3atyped_data._Int8List._createList$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4270166662586539371, ptr @df.dart$3atyped_data._IntListMixin.add$c, i64 4584568332005005361, ptr @df.dart$3atyped_data._IntListMixin.contains$c, i64 4761704951267565019, ptr @df.dart$3atyped_data._TypedList._typedData$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3atyped_data._TypedListBase.join$c, i64 5816122436118806360, ptr @df.dart$3atyped_data._IntListMixin.fillRange$tc, i64 6457676092542964098, ptr @df.dart$3atyped_data._TypedList.lengthInBytes$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7276400063129042528, ptr @df.dart$3atyped_data._Int8List._fastSetRange$tc, i64 7293158726991237507, ptr @df.dart$3atyped_data._IntListMixin.setRange$tc, i64 7526586947604351043, ptr @df.dart$3atyped_data._Int8List.$5b$5d$3d$c, i64 7800396592418680749, ptr @df.dart$3atyped_data._IntListMixin.setRange$c, i64 8310139465989025733, ptr @df.dart$3atyped_data._IntListMixin.indexOf$c, i64 8959578506744725547, ptr @df.dart$3atyped_data._TypedIntListMixin._slowSetRange$tc, i64 9189246021676726028, ptr @df.dart$3atyped_data._Int8List.$5b$5d$c }
define ptr @df.mt.dart$3atyped_data._Int8List() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Int8List$d
}
@df.mt.dart$3atyped_data._Uint8List$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 23, i64 51, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8971153493902442575, ptr @df.dart$3atyped_data._Uint8List.$5b$5d$3d$tc, i64 -8113821193935802361, ptr @df.dart$3atyped_data._Uint8List._createList$tc, i64 -7830014244959264555, ptr @df.dart$3atyped_data._Uint8List.elementSizeInBytes$g, i64 -7142806495848668844, ptr @df.dart$3atyped_data._IntListMixin.last$g, i64 -7048868133546680485, ptr @df.dart$3atyped_data._IntListMixin.toList$tc, i64 -6880024560892829041, ptr @df.dart$3atyped_data._IntListMixin.skip$c, i64 -6565620648322651272, ptr @df.dart$3atyped_data._TypedListBase.length$g, i64 -6455655928913991845, ptr @df.dart$3atyped_data._IntListMixin.take$c, i64 -5476269667379286226, ptr @df.dart$3atyped_data._IntListMixin.iterator$g, i64 -4183823290162052582, ptr @df.dart$3atyped_data._TypedListBase.join$tc, i64 -3583372486457872994, ptr @df.dart$3atyped_data._Uint8List._fastSetRange$c, i64 -3445551396850951156, ptr @df.dart$3atyped_data._TypedListBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3atyped_data._TypedListBase.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3atyped_data._IntListMixin.elementAt$c, i64 -2865225933037962029, ptr @df.dart$3atyped_data._IntListMixin.indexOf$tc, i64 -2322265645133230011, ptr @df.dart$3atyped_data._IntListMixin.skip$tc, i64 -2266111775014587155, ptr @df.dart$3atyped_data._TypedIntListMixin._slowSetRange$c, i64 -1759784064291000274, ptr @df.dart$3atyped_data._TypedList.buffer$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3atyped_data._TypedListBase.remove$c, i64 -921892303864442672, ptr @df.dart$3atyped_data._IntListMixin.removeLast$c, i64 -730073319095210781, ptr @df.dart$3atyped_data._IntListMixin.elementAt$tc, i64 -677989548411720471, ptr @df.dart$3atyped_data._IntListMixin.$2b$c, i64 -503246348505971594, ptr @df.dart$3atyped_data._IntListMixin.fillRange$c, i64 -8944174681508873, ptr @df.dart$3atyped_data._TypedList.offsetInBytes$g, i64 590583546444750725, ptr @df.dart$3atyped_data._IntListMixin.take$tc, i64 1309726782632086582, ptr @df.dart$3atyped_data._TypedListBase.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3atyped_data._IntListMixin.toList$c, i64 1890975232377856814, ptr @df.dart$3atyped_data._IntListMixin.map$c, i64 2870274114568068918, ptr @df.dart$3atyped_data._Uint8List.$5b$5d$tc, i64 3251101298082571214, ptr @df.dart$3atyped_data._IntListMixin.forEach$c, i64 3337248483243775250, ptr @df.dart$3atyped_data._Uint8List._containsUnsignedBytes$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 3785544036535605593, ptr @df.dart$3atyped_data._Uint8List._createList$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4270166662586539371, ptr @df.dart$3atyped_data._IntListMixin.add$c, i64 4584568332005005361, ptr @df.dart$3atyped_data._IntListMixin.contains$c, i64 4761704951267565019, ptr @df.dart$3atyped_data._TypedList._typedData$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3atyped_data._TypedListBase.join$c, i64 5816122436118806360, ptr @df.dart$3atyped_data._IntListMixin.fillRange$tc, i64 6457676092542964098, ptr @df.dart$3atyped_data._TypedList.lengthInBytes$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7276400063129042528, ptr @df.dart$3atyped_data._Uint8List._fastSetRange$tc, i64 7293158726991237507, ptr @df.dart$3atyped_data._IntListMixin.setRange$tc, i64 7526586947604351043, ptr @df.dart$3atyped_data._Uint8List.$5b$5d$3d$c, i64 7800396592418680749, ptr @df.dart$3atyped_data._IntListMixin.setRange$c, i64 8310139465989025733, ptr @df.dart$3atyped_data._IntListMixin.indexOf$c, i64 8959578506744725547, ptr @df.dart$3atyped_data._TypedIntListMixin._slowSetRange$tc, i64 9189246021676726028, ptr @df.dart$3atyped_data._Uint8List.$5b$5d$c }
define ptr @df.mt.dart$3atyped_data._Uint8List() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Uint8List$d
}
@df.mt.dart$3atyped_data._Uint8ClampedList$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 24, i64 51, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8971153493902442575, ptr @df.dart$3atyped_data._Uint8ClampedList.$5b$5d$3d$tc, i64 -8113821193935802361, ptr @df.dart$3atyped_data._Uint8ClampedList._createList$tc, i64 -7830014244959264555, ptr @df.dart$3atyped_data._Uint8ClampedList.elementSizeInBytes$g, i64 -7142806495848668844, ptr @df.dart$3atyped_data._IntListMixin.last$g, i64 -7048868133546680485, ptr @df.dart$3atyped_data._IntListMixin.toList$tc, i64 -6880024560892829041, ptr @df.dart$3atyped_data._IntListMixin.skip$c, i64 -6565620648322651272, ptr @df.dart$3atyped_data._TypedListBase.length$g, i64 -6455655928913991845, ptr @df.dart$3atyped_data._IntListMixin.take$c, i64 -5476269667379286226, ptr @df.dart$3atyped_data._IntListMixin.iterator$g, i64 -4183823290162052582, ptr @df.dart$3atyped_data._TypedListBase.join$tc, i64 -3583372486457872994, ptr @df.dart$3atyped_data._Uint8ClampedList._fastSetRange$c, i64 -3445551396850951156, ptr @df.dart$3atyped_data._TypedListBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3atyped_data._TypedListBase.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3atyped_data._IntListMixin.elementAt$c, i64 -2865225933037962029, ptr @df.dart$3atyped_data._IntListMixin.indexOf$tc, i64 -2322265645133230011, ptr @df.dart$3atyped_data._IntListMixin.skip$tc, i64 -2266111775014587155, ptr @df.dart$3atyped_data._TypedIntListMixin._slowSetRange$c, i64 -1759784064291000274, ptr @df.dart$3atyped_data._TypedList.buffer$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3atyped_data._TypedListBase.remove$c, i64 -921892303864442672, ptr @df.dart$3atyped_data._IntListMixin.removeLast$c, i64 -730073319095210781, ptr @df.dart$3atyped_data._IntListMixin.elementAt$tc, i64 -677989548411720471, ptr @df.dart$3atyped_data._IntListMixin.$2b$c, i64 -503246348505971594, ptr @df.dart$3atyped_data._IntListMixin.fillRange$c, i64 -8944174681508873, ptr @df.dart$3atyped_data._TypedList.offsetInBytes$g, i64 590583546444750725, ptr @df.dart$3atyped_data._IntListMixin.take$tc, i64 1309726782632086582, ptr @df.dart$3atyped_data._TypedListBase.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3atyped_data._IntListMixin.toList$c, i64 1890975232377856814, ptr @df.dart$3atyped_data._IntListMixin.map$c, i64 2870274114568068918, ptr @df.dart$3atyped_data._Uint8ClampedList.$5b$5d$tc, i64 3251101298082571214, ptr @df.dart$3atyped_data._IntListMixin.forEach$c, i64 3337248483243775250, ptr @df.dart$3atyped_data._Uint8ClampedList._containsUnsignedBytes$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 3785544036535605593, ptr @df.dart$3atyped_data._Uint8ClampedList._createList$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4270166662586539371, ptr @df.dart$3atyped_data._IntListMixin.add$c, i64 4584568332005005361, ptr @df.dart$3atyped_data._IntListMixin.contains$c, i64 4761704951267565019, ptr @df.dart$3atyped_data._TypedList._typedData$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3atyped_data._TypedListBase.join$c, i64 5816122436118806360, ptr @df.dart$3atyped_data._IntListMixin.fillRange$tc, i64 6457676092542964098, ptr @df.dart$3atyped_data._TypedList.lengthInBytes$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7276400063129042528, ptr @df.dart$3atyped_data._Uint8ClampedList._fastSetRange$tc, i64 7293158726991237507, ptr @df.dart$3atyped_data._IntListMixin.setRange$tc, i64 7526586947604351043, ptr @df.dart$3atyped_data._Uint8ClampedList.$5b$5d$3d$c, i64 7800396592418680749, ptr @df.dart$3atyped_data._IntListMixin.setRange$c, i64 8310139465989025733, ptr @df.dart$3atyped_data._IntListMixin.indexOf$c, i64 8959578506744725547, ptr @df.dart$3atyped_data._TypedIntListMixin._slowSetRange$tc, i64 9189246021676726028, ptr @df.dart$3atyped_data._Uint8ClampedList.$5b$5d$c }
define ptr @df.mt.dart$3atyped_data._Uint8ClampedList() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Uint8ClampedList$d
}
@df.mt.dart$3atyped_data._Int16List$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 25, i64 51, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8971153493902442575, ptr @df.dart$3atyped_data._Int16List.$5b$5d$3d$tc, i64 -8113821193935802361, ptr @df.dart$3atyped_data._Int16List._createList$tc, i64 -7830014244959264555, ptr @df.dart$3atyped_data._Int16List.elementSizeInBytes$g, i64 -7142806495848668844, ptr @df.dart$3atyped_data._IntListMixin.last$g, i64 -7048868133546680485, ptr @df.dart$3atyped_data._IntListMixin.toList$tc, i64 -6880024560892829041, ptr @df.dart$3atyped_data._IntListMixin.skip$c, i64 -6565620648322651272, ptr @df.dart$3atyped_data._TypedListBase.length$g, i64 -6455655928913991845, ptr @df.dart$3atyped_data._IntListMixin.take$c, i64 -5476269667379286226, ptr @df.dart$3atyped_data._IntListMixin.iterator$g, i64 -4183823290162052582, ptr @df.dart$3atyped_data._TypedListBase.join$tc, i64 -3583372486457872994, ptr @df.dart$3atyped_data._Int16List._fastSetRange$c, i64 -3445551396850951156, ptr @df.dart$3atyped_data._TypedListBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3atyped_data._TypedListBase.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3atyped_data._IntListMixin.elementAt$c, i64 -2865225933037962029, ptr @df.dart$3atyped_data._IntListMixin.indexOf$tc, i64 -2322265645133230011, ptr @df.dart$3atyped_data._IntListMixin.skip$tc, i64 -2266111775014587155, ptr @df.dart$3atyped_data._TypedIntListMixin._slowSetRange$c, i64 -1759784064291000274, ptr @df.dart$3atyped_data._TypedList.buffer$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3atyped_data._TypedListBase.remove$c, i64 -921892303864442672, ptr @df.dart$3atyped_data._IntListMixin.removeLast$c, i64 -730073319095210781, ptr @df.dart$3atyped_data._IntListMixin.elementAt$tc, i64 -677989548411720471, ptr @df.dart$3atyped_data._IntListMixin.$2b$c, i64 -503246348505971594, ptr @df.dart$3atyped_data._IntListMixin.fillRange$c, i64 -8944174681508873, ptr @df.dart$3atyped_data._TypedList.offsetInBytes$g, i64 590583546444750725, ptr @df.dart$3atyped_data._IntListMixin.take$tc, i64 1309726782632086582, ptr @df.dart$3atyped_data._TypedListBase.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3atyped_data._IntListMixin.toList$c, i64 1890975232377856814, ptr @df.dart$3atyped_data._IntListMixin.map$c, i64 2870274114568068918, ptr @df.dart$3atyped_data._Int16List.$5b$5d$tc, i64 3251101298082571214, ptr @df.dart$3atyped_data._IntListMixin.forEach$c, i64 3337248483243775250, ptr @df.dart$3atyped_data._TypedListBase._containsUnsignedBytes$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 3785544036535605593, ptr @df.dart$3atyped_data._Int16List._createList$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4270166662586539371, ptr @df.dart$3atyped_data._IntListMixin.add$c, i64 4584568332005005361, ptr @df.dart$3atyped_data._IntListMixin.contains$c, i64 4761704951267565019, ptr @df.dart$3atyped_data._TypedList._typedData$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3atyped_data._TypedListBase.join$c, i64 5816122436118806360, ptr @df.dart$3atyped_data._IntListMixin.fillRange$tc, i64 6457676092542964098, ptr @df.dart$3atyped_data._TypedList.lengthInBytes$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7276400063129042528, ptr @df.dart$3atyped_data._Int16List._fastSetRange$tc, i64 7293158726991237507, ptr @df.dart$3atyped_data._Int16List.setRange$tc, i64 7526586947604351043, ptr @df.dart$3atyped_data._Int16List.$5b$5d$3d$c, i64 7800396592418680749, ptr @df.dart$3atyped_data._Int16List.setRange$c, i64 8310139465989025733, ptr @df.dart$3atyped_data._IntListMixin.indexOf$c, i64 8959578506744725547, ptr @df.dart$3atyped_data._TypedIntListMixin._slowSetRange$tc, i64 9189246021676726028, ptr @df.dart$3atyped_data._Int16List.$5b$5d$c }
define ptr @df.mt.dart$3atyped_data._Int16List() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Int16List$d
}
@df.mt.dart$3atyped_data._Uint16List$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 26, i64 51, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8971153493902442575, ptr @df.dart$3atyped_data._Uint16List.$5b$5d$3d$tc, i64 -8113821193935802361, ptr @df.dart$3atyped_data._Uint16List._createList$tc, i64 -7830014244959264555, ptr @df.dart$3atyped_data._Uint16List.elementSizeInBytes$g, i64 -7142806495848668844, ptr @df.dart$3atyped_data._IntListMixin.last$g, i64 -7048868133546680485, ptr @df.dart$3atyped_data._IntListMixin.toList$tc, i64 -6880024560892829041, ptr @df.dart$3atyped_data._IntListMixin.skip$c, i64 -6565620648322651272, ptr @df.dart$3atyped_data._TypedListBase.length$g, i64 -6455655928913991845, ptr @df.dart$3atyped_data._IntListMixin.take$c, i64 -5476269667379286226, ptr @df.dart$3atyped_data._IntListMixin.iterator$g, i64 -4183823290162052582, ptr @df.dart$3atyped_data._TypedListBase.join$tc, i64 -3583372486457872994, ptr @df.dart$3atyped_data._Uint16List._fastSetRange$c, i64 -3445551396850951156, ptr @df.dart$3atyped_data._TypedListBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3atyped_data._TypedListBase.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3atyped_data._IntListMixin.elementAt$c, i64 -2865225933037962029, ptr @df.dart$3atyped_data._IntListMixin.indexOf$tc, i64 -2322265645133230011, ptr @df.dart$3atyped_data._IntListMixin.skip$tc, i64 -2266111775014587155, ptr @df.dart$3atyped_data._TypedIntListMixin._slowSetRange$c, i64 -1759784064291000274, ptr @df.dart$3atyped_data._TypedList.buffer$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3atyped_data._TypedListBase.remove$c, i64 -921892303864442672, ptr @df.dart$3atyped_data._IntListMixin.removeLast$c, i64 -730073319095210781, ptr @df.dart$3atyped_data._IntListMixin.elementAt$tc, i64 -677989548411720471, ptr @df.dart$3atyped_data._IntListMixin.$2b$c, i64 -503246348505971594, ptr @df.dart$3atyped_data._IntListMixin.fillRange$c, i64 -8944174681508873, ptr @df.dart$3atyped_data._TypedList.offsetInBytes$g, i64 590583546444750725, ptr @df.dart$3atyped_data._IntListMixin.take$tc, i64 1309726782632086582, ptr @df.dart$3atyped_data._TypedListBase.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3atyped_data._IntListMixin.toList$c, i64 1890975232377856814, ptr @df.dart$3atyped_data._IntListMixin.map$c, i64 2870274114568068918, ptr @df.dart$3atyped_data._Uint16List.$5b$5d$tc, i64 3251101298082571214, ptr @df.dart$3atyped_data._IntListMixin.forEach$c, i64 3337248483243775250, ptr @df.dart$3atyped_data._TypedListBase._containsUnsignedBytes$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 3785544036535605593, ptr @df.dart$3atyped_data._Uint16List._createList$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4270166662586539371, ptr @df.dart$3atyped_data._IntListMixin.add$c, i64 4584568332005005361, ptr @df.dart$3atyped_data._IntListMixin.contains$c, i64 4761704951267565019, ptr @df.dart$3atyped_data._TypedList._typedData$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3atyped_data._TypedListBase.join$c, i64 5816122436118806360, ptr @df.dart$3atyped_data._IntListMixin.fillRange$tc, i64 6457676092542964098, ptr @df.dart$3atyped_data._TypedList.lengthInBytes$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7276400063129042528, ptr @df.dart$3atyped_data._Uint16List._fastSetRange$tc, i64 7293158726991237507, ptr @df.dart$3atyped_data._Uint16List.setRange$tc, i64 7526586947604351043, ptr @df.dart$3atyped_data._Uint16List.$5b$5d$3d$c, i64 7800396592418680749, ptr @df.dart$3atyped_data._Uint16List.setRange$c, i64 8310139465989025733, ptr @df.dart$3atyped_data._IntListMixin.indexOf$c, i64 8959578506744725547, ptr @df.dart$3atyped_data._TypedIntListMixin._slowSetRange$tc, i64 9189246021676726028, ptr @df.dart$3atyped_data._Uint16List.$5b$5d$c }
define ptr @df.mt.dart$3atyped_data._Uint16List() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Uint16List$d
}
@df.mt.dart$3atyped_data._Int32List$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 27, i64 51, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8971153493902442575, ptr @df.dart$3atyped_data._Int32List.$5b$5d$3d$tc, i64 -8113821193935802361, ptr @df.dart$3atyped_data._Int32List._createList$tc, i64 -7830014244959264555, ptr @df.dart$3atyped_data._Int32List.elementSizeInBytes$g, i64 -7142806495848668844, ptr @df.dart$3atyped_data._IntListMixin.last$g, i64 -7048868133546680485, ptr @df.dart$3atyped_data._IntListMixin.toList$tc, i64 -6880024560892829041, ptr @df.dart$3atyped_data._IntListMixin.skip$c, i64 -6565620648322651272, ptr @df.dart$3atyped_data._TypedListBase.length$g, i64 -6455655928913991845, ptr @df.dart$3atyped_data._IntListMixin.take$c, i64 -5476269667379286226, ptr @df.dart$3atyped_data._IntListMixin.iterator$g, i64 -4183823290162052582, ptr @df.dart$3atyped_data._TypedListBase.join$tc, i64 -3583372486457872994, ptr @df.dart$3atyped_data._Int32List._fastSetRange$c, i64 -3445551396850951156, ptr @df.dart$3atyped_data._TypedListBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3atyped_data._TypedListBase.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3atyped_data._IntListMixin.elementAt$c, i64 -2865225933037962029, ptr @df.dart$3atyped_data._IntListMixin.indexOf$tc, i64 -2322265645133230011, ptr @df.dart$3atyped_data._IntListMixin.skip$tc, i64 -2266111775014587155, ptr @df.dart$3atyped_data._TypedIntListMixin._slowSetRange$c, i64 -1759784064291000274, ptr @df.dart$3atyped_data._TypedList.buffer$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3atyped_data._TypedListBase.remove$c, i64 -921892303864442672, ptr @df.dart$3atyped_data._IntListMixin.removeLast$c, i64 -730073319095210781, ptr @df.dart$3atyped_data._IntListMixin.elementAt$tc, i64 -677989548411720471, ptr @df.dart$3atyped_data._IntListMixin.$2b$c, i64 -503246348505971594, ptr @df.dart$3atyped_data._IntListMixin.fillRange$c, i64 -8944174681508873, ptr @df.dart$3atyped_data._TypedList.offsetInBytes$g, i64 590583546444750725, ptr @df.dart$3atyped_data._IntListMixin.take$tc, i64 1309726782632086582, ptr @df.dart$3atyped_data._TypedListBase.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3atyped_data._IntListMixin.toList$c, i64 1890975232377856814, ptr @df.dart$3atyped_data._IntListMixin.map$c, i64 2870274114568068918, ptr @df.dart$3atyped_data._Int32List.$5b$5d$tc, i64 3251101298082571214, ptr @df.dart$3atyped_data._IntListMixin.forEach$c, i64 3337248483243775250, ptr @df.dart$3atyped_data._TypedListBase._containsUnsignedBytes$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 3785544036535605593, ptr @df.dart$3atyped_data._Int32List._createList$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4270166662586539371, ptr @df.dart$3atyped_data._IntListMixin.add$c, i64 4584568332005005361, ptr @df.dart$3atyped_data._IntListMixin.contains$c, i64 4761704951267565019, ptr @df.dart$3atyped_data._TypedList._typedData$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3atyped_data._TypedListBase.join$c, i64 5816122436118806360, ptr @df.dart$3atyped_data._IntListMixin.fillRange$tc, i64 6457676092542964098, ptr @df.dart$3atyped_data._TypedList.lengthInBytes$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7276400063129042528, ptr @df.dart$3atyped_data._Int32List._fastSetRange$tc, i64 7293158726991237507, ptr @df.dart$3atyped_data._IntListMixin.setRange$tc, i64 7526586947604351043, ptr @df.dart$3atyped_data._Int32List.$5b$5d$3d$c, i64 7800396592418680749, ptr @df.dart$3atyped_data._IntListMixin.setRange$c, i64 8310139465989025733, ptr @df.dart$3atyped_data._IntListMixin.indexOf$c, i64 8959578506744725547, ptr @df.dart$3atyped_data._TypedIntListMixin._slowSetRange$tc, i64 9189246021676726028, ptr @df.dart$3atyped_data._Int32List.$5b$5d$c }
define ptr @df.mt.dart$3atyped_data._Int32List() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Int32List$d
}
@df.mt.dart$3atyped_data._Uint32List$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 28, i64 51, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8971153493902442575, ptr @df.dart$3atyped_data._Uint32List.$5b$5d$3d$tc, i64 -8113821193935802361, ptr @df.dart$3atyped_data._Uint32List._createList$tc, i64 -7830014244959264555, ptr @df.dart$3atyped_data._Uint32List.elementSizeInBytes$g, i64 -7142806495848668844, ptr @df.dart$3atyped_data._IntListMixin.last$g, i64 -7048868133546680485, ptr @df.dart$3atyped_data._IntListMixin.toList$tc, i64 -6880024560892829041, ptr @df.dart$3atyped_data._IntListMixin.skip$c, i64 -6565620648322651272, ptr @df.dart$3atyped_data._TypedListBase.length$g, i64 -6455655928913991845, ptr @df.dart$3atyped_data._IntListMixin.take$c, i64 -5476269667379286226, ptr @df.dart$3atyped_data._IntListMixin.iterator$g, i64 -4183823290162052582, ptr @df.dart$3atyped_data._TypedListBase.join$tc, i64 -3583372486457872994, ptr @df.dart$3atyped_data._Uint32List._fastSetRange$c, i64 -3445551396850951156, ptr @df.dart$3atyped_data._TypedListBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3atyped_data._TypedListBase.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3atyped_data._IntListMixin.elementAt$c, i64 -2865225933037962029, ptr @df.dart$3atyped_data._IntListMixin.indexOf$tc, i64 -2322265645133230011, ptr @df.dart$3atyped_data._IntListMixin.skip$tc, i64 -2266111775014587155, ptr @df.dart$3atyped_data._TypedIntListMixin._slowSetRange$c, i64 -1759784064291000274, ptr @df.dart$3atyped_data._TypedList.buffer$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3atyped_data._TypedListBase.remove$c, i64 -921892303864442672, ptr @df.dart$3atyped_data._IntListMixin.removeLast$c, i64 -730073319095210781, ptr @df.dart$3atyped_data._IntListMixin.elementAt$tc, i64 -677989548411720471, ptr @df.dart$3atyped_data._IntListMixin.$2b$c, i64 -503246348505971594, ptr @df.dart$3atyped_data._IntListMixin.fillRange$c, i64 -8944174681508873, ptr @df.dart$3atyped_data._TypedList.offsetInBytes$g, i64 590583546444750725, ptr @df.dart$3atyped_data._IntListMixin.take$tc, i64 1309726782632086582, ptr @df.dart$3atyped_data._TypedListBase.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3atyped_data._IntListMixin.toList$c, i64 1890975232377856814, ptr @df.dart$3atyped_data._IntListMixin.map$c, i64 2870274114568068918, ptr @df.dart$3atyped_data._Uint32List.$5b$5d$tc, i64 3251101298082571214, ptr @df.dart$3atyped_data._IntListMixin.forEach$c, i64 3337248483243775250, ptr @df.dart$3atyped_data._TypedListBase._containsUnsignedBytes$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 3785544036535605593, ptr @df.dart$3atyped_data._Uint32List._createList$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4270166662586539371, ptr @df.dart$3atyped_data._IntListMixin.add$c, i64 4584568332005005361, ptr @df.dart$3atyped_data._IntListMixin.contains$c, i64 4761704951267565019, ptr @df.dart$3atyped_data._TypedList._typedData$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3atyped_data._TypedListBase.join$c, i64 5816122436118806360, ptr @df.dart$3atyped_data._IntListMixin.fillRange$tc, i64 6457676092542964098, ptr @df.dart$3atyped_data._TypedList.lengthInBytes$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7276400063129042528, ptr @df.dart$3atyped_data._Uint32List._fastSetRange$tc, i64 7293158726991237507, ptr @df.dart$3atyped_data._IntListMixin.setRange$tc, i64 7526586947604351043, ptr @df.dart$3atyped_data._Uint32List.$5b$5d$3d$c, i64 7800396592418680749, ptr @df.dart$3atyped_data._IntListMixin.setRange$c, i64 8310139465989025733, ptr @df.dart$3atyped_data._IntListMixin.indexOf$c, i64 8959578506744725547, ptr @df.dart$3atyped_data._TypedIntListMixin._slowSetRange$tc, i64 9189246021676726028, ptr @df.dart$3atyped_data._Uint32List.$5b$5d$c }
define ptr @df.mt.dart$3atyped_data._Uint32List() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Uint32List$d
}
@df.mt.dart$3atyped_data._Int64List$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 29, i64 51, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8971153493902442575, ptr @df.dart$3atyped_data._Int64List.$5b$5d$3d$tc, i64 -8113821193935802361, ptr @df.dart$3atyped_data._Int64List._createList$tc, i64 -7830014244959264555, ptr @df.dart$3atyped_data._Int64List.elementSizeInBytes$g, i64 -7142806495848668844, ptr @df.dart$3atyped_data._IntListMixin.last$g, i64 -7048868133546680485, ptr @df.dart$3atyped_data._IntListMixin.toList$tc, i64 -6880024560892829041, ptr @df.dart$3atyped_data._IntListMixin.skip$c, i64 -6565620648322651272, ptr @df.dart$3atyped_data._TypedListBase.length$g, i64 -6455655928913991845, ptr @df.dart$3atyped_data._IntListMixin.take$c, i64 -5476269667379286226, ptr @df.dart$3atyped_data._IntListMixin.iterator$g, i64 -4183823290162052582, ptr @df.dart$3atyped_data._TypedListBase.join$tc, i64 -3583372486457872994, ptr @df.dart$3atyped_data._Int64List._fastSetRange$c, i64 -3445551396850951156, ptr @df.dart$3atyped_data._TypedListBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3atyped_data._TypedListBase.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3atyped_data._IntListMixin.elementAt$c, i64 -2865225933037962029, ptr @df.dart$3atyped_data._IntListMixin.indexOf$tc, i64 -2322265645133230011, ptr @df.dart$3atyped_data._IntListMixin.skip$tc, i64 -2266111775014587155, ptr @df.dart$3atyped_data._TypedIntListMixin._slowSetRange$c, i64 -1759784064291000274, ptr @df.dart$3atyped_data._TypedList.buffer$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3atyped_data._TypedListBase.remove$c, i64 -921892303864442672, ptr @df.dart$3atyped_data._IntListMixin.removeLast$c, i64 -730073319095210781, ptr @df.dart$3atyped_data._IntListMixin.elementAt$tc, i64 -677989548411720471, ptr @df.dart$3atyped_data._IntListMixin.$2b$c, i64 -503246348505971594, ptr @df.dart$3atyped_data._IntListMixin.fillRange$c, i64 -8944174681508873, ptr @df.dart$3atyped_data._TypedList.offsetInBytes$g, i64 590583546444750725, ptr @df.dart$3atyped_data._IntListMixin.take$tc, i64 1309726782632086582, ptr @df.dart$3atyped_data._TypedListBase.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3atyped_data._IntListMixin.toList$c, i64 1890975232377856814, ptr @df.dart$3atyped_data._IntListMixin.map$c, i64 2870274114568068918, ptr @df.dart$3atyped_data._Int64List.$5b$5d$tc, i64 3251101298082571214, ptr @df.dart$3atyped_data._IntListMixin.forEach$c, i64 3337248483243775250, ptr @df.dart$3atyped_data._TypedListBase._containsUnsignedBytes$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 3785544036535605593, ptr @df.dart$3atyped_data._Int64List._createList$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4270166662586539371, ptr @df.dart$3atyped_data._IntListMixin.add$c, i64 4584568332005005361, ptr @df.dart$3atyped_data._IntListMixin.contains$c, i64 4761704951267565019, ptr @df.dart$3atyped_data._TypedList._typedData$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3atyped_data._TypedListBase.join$c, i64 5816122436118806360, ptr @df.dart$3atyped_data._IntListMixin.fillRange$tc, i64 6457676092542964098, ptr @df.dart$3atyped_data._TypedList.lengthInBytes$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7276400063129042528, ptr @df.dart$3atyped_data._Int64List._fastSetRange$tc, i64 7293158726991237507, ptr @df.dart$3atyped_data._IntListMixin.setRange$tc, i64 7526586947604351043, ptr @df.dart$3atyped_data._Int64List.$5b$5d$3d$c, i64 7800396592418680749, ptr @df.dart$3atyped_data._IntListMixin.setRange$c, i64 8310139465989025733, ptr @df.dart$3atyped_data._IntListMixin.indexOf$c, i64 8959578506744725547, ptr @df.dart$3atyped_data._TypedIntListMixin._slowSetRange$tc, i64 9189246021676726028, ptr @df.dart$3atyped_data._Int64List.$5b$5d$c }
define ptr @df.mt.dart$3atyped_data._Int64List() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Int64List$d
}
@df.mt.dart$3atyped_data._Uint64List$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 30, i64 51, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8971153493902442575, ptr @df.dart$3atyped_data._Uint64List.$5b$5d$3d$tc, i64 -8113821193935802361, ptr @df.dart$3atyped_data._Uint64List._createList$tc, i64 -7830014244959264555, ptr @df.dart$3atyped_data._Uint64List.elementSizeInBytes$g, i64 -7142806495848668844, ptr @df.dart$3atyped_data._IntListMixin.last$g, i64 -7048868133546680485, ptr @df.dart$3atyped_data._IntListMixin.toList$tc, i64 -6880024560892829041, ptr @df.dart$3atyped_data._IntListMixin.skip$c, i64 -6565620648322651272, ptr @df.dart$3atyped_data._TypedListBase.length$g, i64 -6455655928913991845, ptr @df.dart$3atyped_data._IntListMixin.take$c, i64 -5476269667379286226, ptr @df.dart$3atyped_data._IntListMixin.iterator$g, i64 -4183823290162052582, ptr @df.dart$3atyped_data._TypedListBase.join$tc, i64 -3583372486457872994, ptr @df.dart$3atyped_data._Uint64List._fastSetRange$c, i64 -3445551396850951156, ptr @df.dart$3atyped_data._TypedListBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3atyped_data._TypedListBase.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3atyped_data._IntListMixin.elementAt$c, i64 -2865225933037962029, ptr @df.dart$3atyped_data._IntListMixin.indexOf$tc, i64 -2322265645133230011, ptr @df.dart$3atyped_data._IntListMixin.skip$tc, i64 -2266111775014587155, ptr @df.dart$3atyped_data._TypedIntListMixin._slowSetRange$c, i64 -1759784064291000274, ptr @df.dart$3atyped_data._TypedList.buffer$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3atyped_data._TypedListBase.remove$c, i64 -921892303864442672, ptr @df.dart$3atyped_data._IntListMixin.removeLast$c, i64 -730073319095210781, ptr @df.dart$3atyped_data._IntListMixin.elementAt$tc, i64 -677989548411720471, ptr @df.dart$3atyped_data._IntListMixin.$2b$c, i64 -503246348505971594, ptr @df.dart$3atyped_data._IntListMixin.fillRange$c, i64 -8944174681508873, ptr @df.dart$3atyped_data._TypedList.offsetInBytes$g, i64 590583546444750725, ptr @df.dart$3atyped_data._IntListMixin.take$tc, i64 1309726782632086582, ptr @df.dart$3atyped_data._TypedListBase.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3atyped_data._IntListMixin.toList$c, i64 1890975232377856814, ptr @df.dart$3atyped_data._IntListMixin.map$c, i64 2870274114568068918, ptr @df.dart$3atyped_data._Uint64List.$5b$5d$tc, i64 3251101298082571214, ptr @df.dart$3atyped_data._IntListMixin.forEach$c, i64 3337248483243775250, ptr @df.dart$3atyped_data._TypedListBase._containsUnsignedBytes$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 3785544036535605593, ptr @df.dart$3atyped_data._Uint64List._createList$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4270166662586539371, ptr @df.dart$3atyped_data._IntListMixin.add$c, i64 4584568332005005361, ptr @df.dart$3atyped_data._IntListMixin.contains$c, i64 4761704951267565019, ptr @df.dart$3atyped_data._TypedList._typedData$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3atyped_data._TypedListBase.join$c, i64 5816122436118806360, ptr @df.dart$3atyped_data._IntListMixin.fillRange$tc, i64 6457676092542964098, ptr @df.dart$3atyped_data._TypedList.lengthInBytes$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7276400063129042528, ptr @df.dart$3atyped_data._Uint64List._fastSetRange$tc, i64 7293158726991237507, ptr @df.dart$3atyped_data._IntListMixin.setRange$tc, i64 7526586947604351043, ptr @df.dart$3atyped_data._Uint64List.$5b$5d$3d$c, i64 7800396592418680749, ptr @df.dart$3atyped_data._IntListMixin.setRange$c, i64 8310139465989025733, ptr @df.dart$3atyped_data._IntListMixin.indexOf$c, i64 8959578506744725547, ptr @df.dart$3atyped_data._TypedIntListMixin._slowSetRange$tc, i64 9189246021676726028, ptr @df.dart$3atyped_data._Uint64List.$5b$5d$c }
define ptr @df.mt.dart$3atyped_data._Uint64List() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Uint64List$d
}
@df.mt.dart$3atyped_data._Float32List$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 31, i64 51, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8971153493902442575, ptr @df.dart$3atyped_data._Float32List.$5b$5d$3d$tc, i64 -8113821193935802361, ptr @df.dart$3atyped_data._Float32List._createList$tc, i64 -7830014244959264555, ptr @df.dart$3atyped_data._Float32List.elementSizeInBytes$g, i64 -7142806495848668844, ptr @df.dart$3atyped_data._DoubleListMixin.last$g, i64 -7048868133546680485, ptr @df.dart$3atyped_data._DoubleListMixin.toList$tc, i64 -6880024560892829041, ptr @df.dart$3atyped_data._DoubleListMixin.skip$c, i64 -6565620648322651272, ptr @df.dart$3atyped_data._TypedListBase.length$g, i64 -6455655928913991845, ptr @df.dart$3atyped_data._DoubleListMixin.take$c, i64 -5476269667379286226, ptr @df.dart$3atyped_data._DoubleListMixin.iterator$g, i64 -4183823290162052582, ptr @df.dart$3atyped_data._TypedListBase.join$tc, i64 -3583372486457872994, ptr @df.dart$3atyped_data._Float32List._fastSetRange$c, i64 -3445551396850951156, ptr @df.dart$3atyped_data._TypedListBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3atyped_data._TypedListBase.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3atyped_data._DoubleListMixin.elementAt$c, i64 -2865225933037962029, ptr @df.dart$3atyped_data._DoubleListMixin.indexOf$tc, i64 -2322265645133230011, ptr @df.dart$3atyped_data._DoubleListMixin.skip$tc, i64 -2266111775014587155, ptr @df.dart$3atyped_data._TypedDoubleListMixin._slowSetRange$c, i64 -1759784064291000274, ptr @df.dart$3atyped_data._TypedList.buffer$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3atyped_data._TypedListBase.remove$c, i64 -921892303864442672, ptr @df.dart$3atyped_data._DoubleListMixin.removeLast$c, i64 -730073319095210781, ptr @df.dart$3atyped_data._DoubleListMixin.elementAt$tc, i64 -677989548411720471, ptr @df.dart$3atyped_data._DoubleListMixin.$2b$c, i64 -503246348505971594, ptr @df.dart$3atyped_data._DoubleListMixin.fillRange$c, i64 -8944174681508873, ptr @df.dart$3atyped_data._TypedList.offsetInBytes$g, i64 590583546444750725, ptr @df.dart$3atyped_data._DoubleListMixin.take$tc, i64 1309726782632086582, ptr @df.dart$3atyped_data._TypedListBase.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3atyped_data._DoubleListMixin.toList$c, i64 1890975232377856814, ptr @df.dart$3atyped_data._DoubleListMixin.map$c, i64 2870274114568068918, ptr @df.dart$3atyped_data._Float32List.$5b$5d$tc, i64 3251101298082571214, ptr @df.dart$3atyped_data._DoubleListMixin.forEach$c, i64 3337248483243775250, ptr @df.dart$3atyped_data._TypedListBase._containsUnsignedBytes$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 3785544036535605593, ptr @df.dart$3atyped_data._Float32List._createList$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4270166662586539371, ptr @df.dart$3atyped_data._DoubleListMixin.add$c, i64 4584568332005005361, ptr @df.dart$3atyped_data._DoubleListMixin.contains$c, i64 4761704951267565019, ptr @df.dart$3atyped_data._TypedList._typedData$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3atyped_data._TypedListBase.join$c, i64 5816122436118806360, ptr @df.dart$3atyped_data._DoubleListMixin.fillRange$tc, i64 6457676092542964098, ptr @df.dart$3atyped_data._TypedList.lengthInBytes$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7276400063129042528, ptr @df.dart$3atyped_data._Float32List._fastSetRange$tc, i64 7293158726991237507, ptr @df.dart$3atyped_data._DoubleListMixin.setRange$tc, i64 7526586947604351043, ptr @df.dart$3atyped_data._Float32List.$5b$5d$3d$c, i64 7800396592418680749, ptr @df.dart$3atyped_data._DoubleListMixin.setRange$c, i64 8310139465989025733, ptr @df.dart$3atyped_data._DoubleListMixin.indexOf$c, i64 8959578506744725547, ptr @df.dart$3atyped_data._TypedDoubleListMixin._slowSetRange$tc, i64 9189246021676726028, ptr @df.dart$3atyped_data._Float32List.$5b$5d$c }
define ptr @df.mt.dart$3atyped_data._Float32List() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Float32List$d
}
@df.mt.dart$3atyped_data._Float64List$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 32, i64 51, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8971153493902442575, ptr @df.dart$3atyped_data._Float64List.$5b$5d$3d$tc, i64 -8113821193935802361, ptr @df.dart$3atyped_data._Float64List._createList$tc, i64 -7830014244959264555, ptr @df.dart$3atyped_data._Float64List.elementSizeInBytes$g, i64 -7142806495848668844, ptr @df.dart$3atyped_data._DoubleListMixin.last$g, i64 -7048868133546680485, ptr @df.dart$3atyped_data._DoubleListMixin.toList$tc, i64 -6880024560892829041, ptr @df.dart$3atyped_data._DoubleListMixin.skip$c, i64 -6565620648322651272, ptr @df.dart$3atyped_data._TypedListBase.length$g, i64 -6455655928913991845, ptr @df.dart$3atyped_data._DoubleListMixin.take$c, i64 -5476269667379286226, ptr @df.dart$3atyped_data._DoubleListMixin.iterator$g, i64 -4183823290162052582, ptr @df.dart$3atyped_data._TypedListBase.join$tc, i64 -3583372486457872994, ptr @df.dart$3atyped_data._Float64List._fastSetRange$c, i64 -3445551396850951156, ptr @df.dart$3atyped_data._TypedListBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3atyped_data._TypedListBase.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3atyped_data._DoubleListMixin.elementAt$c, i64 -2865225933037962029, ptr @df.dart$3atyped_data._DoubleListMixin.indexOf$tc, i64 -2322265645133230011, ptr @df.dart$3atyped_data._DoubleListMixin.skip$tc, i64 -2266111775014587155, ptr @df.dart$3atyped_data._TypedDoubleListMixin._slowSetRange$c, i64 -1759784064291000274, ptr @df.dart$3atyped_data._TypedList.buffer$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3atyped_data._TypedListBase.remove$c, i64 -921892303864442672, ptr @df.dart$3atyped_data._DoubleListMixin.removeLast$c, i64 -730073319095210781, ptr @df.dart$3atyped_data._DoubleListMixin.elementAt$tc, i64 -677989548411720471, ptr @df.dart$3atyped_data._DoubleListMixin.$2b$c, i64 -503246348505971594, ptr @df.dart$3atyped_data._DoubleListMixin.fillRange$c, i64 -8944174681508873, ptr @df.dart$3atyped_data._TypedList.offsetInBytes$g, i64 590583546444750725, ptr @df.dart$3atyped_data._DoubleListMixin.take$tc, i64 1309726782632086582, ptr @df.dart$3atyped_data._TypedListBase.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3atyped_data._DoubleListMixin.toList$c, i64 1890975232377856814, ptr @df.dart$3atyped_data._DoubleListMixin.map$c, i64 2870274114568068918, ptr @df.dart$3atyped_data._Float64List.$5b$5d$tc, i64 3251101298082571214, ptr @df.dart$3atyped_data._DoubleListMixin.forEach$c, i64 3337248483243775250, ptr @df.dart$3atyped_data._TypedListBase._containsUnsignedBytes$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 3785544036535605593, ptr @df.dart$3atyped_data._Float64List._createList$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4270166662586539371, ptr @df.dart$3atyped_data._DoubleListMixin.add$c, i64 4584568332005005361, ptr @df.dart$3atyped_data._DoubleListMixin.contains$c, i64 4761704951267565019, ptr @df.dart$3atyped_data._TypedList._typedData$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3atyped_data._TypedListBase.join$c, i64 5816122436118806360, ptr @df.dart$3atyped_data._DoubleListMixin.fillRange$tc, i64 6457676092542964098, ptr @df.dart$3atyped_data._TypedList.lengthInBytes$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7276400063129042528, ptr @df.dart$3atyped_data._Float64List._fastSetRange$tc, i64 7293158726991237507, ptr @df.dart$3atyped_data._DoubleListMixin.setRange$tc, i64 7526586947604351043, ptr @df.dart$3atyped_data._Float64List.$5b$5d$3d$c, i64 7800396592418680749, ptr @df.dart$3atyped_data._DoubleListMixin.setRange$c, i64 8310139465989025733, ptr @df.dart$3atyped_data._DoubleListMixin.indexOf$c, i64 8959578506744725547, ptr @df.dart$3atyped_data._TypedDoubleListMixin._slowSetRange$tc, i64 9189246021676726028, ptr @df.dart$3atyped_data._Float64List.$5b$5d$c }
define ptr @df.mt.dart$3atyped_data._Float64List() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Float64List$d
}
@df.mt.dart$3atyped_data._Float32x4List$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 33, i64 51, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8971153493902442575, ptr @df.dart$3atyped_data._Float32x4List.$5b$5d$3d$tc, i64 -8113821193935802361, ptr @df.dart$3atyped_data._Float32x4List._createList$tc, i64 -7830014244959264555, ptr @df.dart$3atyped_data._Float32x4List.elementSizeInBytes$g, i64 -7142806495848668844, ptr @df.dart$3atyped_data._Float32x4ListMixin.last$g, i64 -7048868133546680485, ptr @df.dart$3atyped_data._Float32x4ListMixin.toList$tc, i64 -6880024560892829041, ptr @df.dart$3atyped_data._Float32x4ListMixin.skip$c, i64 -6565620648322651272, ptr @df.dart$3atyped_data._TypedListBase.length$g, i64 -6455655928913991845, ptr @df.dart$3atyped_data._Float32x4ListMixin.take$c, i64 -5476269667379286226, ptr @df.dart$3atyped_data._Float32x4ListMixin.iterator$g, i64 -4183823290162052582, ptr @df.dart$3atyped_data._TypedListBase.join$tc, i64 -3583372486457872994, ptr @df.dart$3atyped_data._Float32x4List._fastSetRange$c, i64 -3445551396850951156, ptr @df.dart$3atyped_data._TypedListBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3atyped_data._TypedListBase.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3atyped_data._Float32x4ListMixin.elementAt$c, i64 -2865225933037962029, ptr @df.dart$3atyped_data._Float32x4ListMixin.indexOf$tc, i64 -2322265645133230011, ptr @df.dart$3atyped_data._Float32x4ListMixin.skip$tc, i64 -2266111775014587155, ptr @df.dart$3atyped_data._Float32x4ListMixin._slowSetRange$c, i64 -1759784064291000274, ptr @df.dart$3atyped_data._TypedList.buffer$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3atyped_data._TypedListBase.remove$c, i64 -921892303864442672, ptr @df.dart$3atyped_data._Float32x4ListMixin.removeLast$c, i64 -730073319095210781, ptr @df.dart$3atyped_data._Float32x4ListMixin.elementAt$tc, i64 -677989548411720471, ptr @df.dart$3atyped_data._Float32x4ListMixin.$2b$c, i64 -503246348505971594, ptr @df.dart$3atyped_data._Float32x4ListMixin.fillRange$c, i64 -8944174681508873, ptr @df.dart$3atyped_data._TypedList.offsetInBytes$g, i64 590583546444750725, ptr @df.dart$3atyped_data._Float32x4ListMixin.take$tc, i64 1309726782632086582, ptr @df.dart$3atyped_data._TypedListBase.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3atyped_data._Float32x4ListMixin.toList$c, i64 1890975232377856814, ptr @df.dart$3atyped_data._Float32x4ListMixin.map$c, i64 2870274114568068918, ptr @df.dart$3atyped_data._Float32x4List.$5b$5d$tc, i64 3251101298082571214, ptr @df.dart$3atyped_data._Float32x4ListMixin.forEach$c, i64 3337248483243775250, ptr @df.dart$3atyped_data._TypedListBase._containsUnsignedBytes$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 3785544036535605593, ptr @df.dart$3atyped_data._Float32x4List._createList$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4270166662586539371, ptr @df.dart$3atyped_data._Float32x4ListMixin.add$c, i64 4584568332005005361, ptr @df.dart$3atyped_data._Float32x4ListMixin.contains$c, i64 4761704951267565019, ptr @df.dart$3atyped_data._TypedList._typedData$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3atyped_data._TypedListBase.join$c, i64 5816122436118806360, ptr @df.dart$3atyped_data._Float32x4ListMixin.fillRange$tc, i64 6457676092542964098, ptr @df.dart$3atyped_data._TypedList.lengthInBytes$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7276400063129042528, ptr @df.dart$3atyped_data._Float32x4List._fastSetRange$tc, i64 7293158726991237507, ptr @df.dart$3atyped_data._Float32x4ListMixin.setRange$tc, i64 7526586947604351043, ptr @df.dart$3atyped_data._Float32x4List.$5b$5d$3d$c, i64 7800396592418680749, ptr @df.dart$3atyped_data._Float32x4ListMixin.setRange$c, i64 8310139465989025733, ptr @df.dart$3atyped_data._Float32x4ListMixin.indexOf$c, i64 8959578506744725547, ptr @df.dart$3atyped_data._Float32x4ListMixin._slowSetRange$tc, i64 9189246021676726028, ptr @df.dart$3atyped_data._Float32x4List.$5b$5d$c }
define ptr @df.mt.dart$3atyped_data._Float32x4List() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Float32x4List$d
}
@df.mt.dart$3atyped_data._Int32x4List$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 34, i64 51, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8971153493902442575, ptr @df.dart$3atyped_data._Int32x4List.$5b$5d$3d$tc, i64 -8113821193935802361, ptr @df.dart$3atyped_data._Int32x4List._createList$tc, i64 -7830014244959264555, ptr @df.dart$3atyped_data._Int32x4List.elementSizeInBytes$g, i64 -7142806495848668844, ptr @df.dart$3atyped_data._Int32x4ListMixin.last$g, i64 -7048868133546680485, ptr @df.dart$3atyped_data._Int32x4ListMixin.toList$tc, i64 -6880024560892829041, ptr @df.dart$3atyped_data._Int32x4ListMixin.skip$c, i64 -6565620648322651272, ptr @df.dart$3atyped_data._TypedListBase.length$g, i64 -6455655928913991845, ptr @df.dart$3atyped_data._Int32x4ListMixin.take$c, i64 -5476269667379286226, ptr @df.dart$3atyped_data._Int32x4ListMixin.iterator$g, i64 -4183823290162052582, ptr @df.dart$3atyped_data._TypedListBase.join$tc, i64 -3583372486457872994, ptr @df.dart$3atyped_data._Int32x4List._fastSetRange$c, i64 -3445551396850951156, ptr @df.dart$3atyped_data._TypedListBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3atyped_data._TypedListBase.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3atyped_data._Int32x4ListMixin.elementAt$c, i64 -2865225933037962029, ptr @df.dart$3atyped_data._Int32x4ListMixin.indexOf$tc, i64 -2322265645133230011, ptr @df.dart$3atyped_data._Int32x4ListMixin.skip$tc, i64 -2266111775014587155, ptr @df.dart$3atyped_data._Int32x4ListMixin._slowSetRange$c, i64 -1759784064291000274, ptr @df.dart$3atyped_data._TypedList.buffer$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3atyped_data._TypedListBase.remove$c, i64 -921892303864442672, ptr @df.dart$3atyped_data._Int32x4ListMixin.removeLast$c, i64 -730073319095210781, ptr @df.dart$3atyped_data._Int32x4ListMixin.elementAt$tc, i64 -677989548411720471, ptr @df.dart$3atyped_data._Int32x4ListMixin.$2b$c, i64 -503246348505971594, ptr @df.dart$3atyped_data._Int32x4ListMixin.fillRange$c, i64 -8944174681508873, ptr @df.dart$3atyped_data._TypedList.offsetInBytes$g, i64 590583546444750725, ptr @df.dart$3atyped_data._Int32x4ListMixin.take$tc, i64 1309726782632086582, ptr @df.dart$3atyped_data._TypedListBase.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3atyped_data._Int32x4ListMixin.toList$c, i64 1890975232377856814, ptr @df.dart$3atyped_data._Int32x4ListMixin.map$c, i64 2870274114568068918, ptr @df.dart$3atyped_data._Int32x4List.$5b$5d$tc, i64 3251101298082571214, ptr @df.dart$3atyped_data._Int32x4ListMixin.forEach$c, i64 3337248483243775250, ptr @df.dart$3atyped_data._TypedListBase._containsUnsignedBytes$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 3785544036535605593, ptr @df.dart$3atyped_data._Int32x4List._createList$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4270166662586539371, ptr @df.dart$3atyped_data._Int32x4ListMixin.add$c, i64 4584568332005005361, ptr @df.dart$3atyped_data._Int32x4ListMixin.contains$c, i64 4761704951267565019, ptr @df.dart$3atyped_data._TypedList._typedData$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3atyped_data._TypedListBase.join$c, i64 5816122436118806360, ptr @df.dart$3atyped_data._Int32x4ListMixin.fillRange$tc, i64 6457676092542964098, ptr @df.dart$3atyped_data._TypedList.lengthInBytes$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7276400063129042528, ptr @df.dart$3atyped_data._Int32x4List._fastSetRange$tc, i64 7293158726991237507, ptr @df.dart$3atyped_data._Int32x4ListMixin.setRange$tc, i64 7526586947604351043, ptr @df.dart$3atyped_data._Int32x4List.$5b$5d$3d$c, i64 7800396592418680749, ptr @df.dart$3atyped_data._Int32x4ListMixin.setRange$c, i64 8310139465989025733, ptr @df.dart$3atyped_data._Int32x4ListMixin.indexOf$c, i64 8959578506744725547, ptr @df.dart$3atyped_data._Int32x4ListMixin._slowSetRange$tc, i64 9189246021676726028, ptr @df.dart$3atyped_data._Int32x4List.$5b$5d$c }
define ptr @df.mt.dart$3atyped_data._Int32x4List() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Int32x4List$d
}
@df.mt.dart$3atyped_data._Float64x2List$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 35, i64 51, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8971153493902442575, ptr @df.dart$3atyped_data._Float64x2List.$5b$5d$3d$tc, i64 -8113821193935802361, ptr @df.dart$3atyped_data._Float64x2List._createList$tc, i64 -7830014244959264555, ptr @df.dart$3atyped_data._Float64x2List.elementSizeInBytes$g, i64 -7142806495848668844, ptr @df.dart$3atyped_data._Float64x2ListMixin.last$g, i64 -7048868133546680485, ptr @df.dart$3atyped_data._Float64x2ListMixin.toList$tc, i64 -6880024560892829041, ptr @df.dart$3atyped_data._Float64x2ListMixin.skip$c, i64 -6565620648322651272, ptr @df.dart$3atyped_data._TypedListBase.length$g, i64 -6455655928913991845, ptr @df.dart$3atyped_data._Float64x2ListMixin.take$c, i64 -5476269667379286226, ptr @df.dart$3atyped_data._Float64x2ListMixin.iterator$g, i64 -4183823290162052582, ptr @df.dart$3atyped_data._TypedListBase.join$tc, i64 -3583372486457872994, ptr @df.dart$3atyped_data._Float64x2List._fastSetRange$c, i64 -3445551396850951156, ptr @df.dart$3atyped_data._TypedListBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3atyped_data._TypedListBase.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3atyped_data._Float64x2ListMixin.elementAt$c, i64 -2865225933037962029, ptr @df.dart$3atyped_data._Float64x2ListMixin.indexOf$tc, i64 -2322265645133230011, ptr @df.dart$3atyped_data._Float64x2ListMixin.skip$tc, i64 -2266111775014587155, ptr @df.dart$3atyped_data._Float64x2ListMixin._slowSetRange$c, i64 -1759784064291000274, ptr @df.dart$3atyped_data._TypedList.buffer$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3atyped_data._TypedListBase.remove$c, i64 -921892303864442672, ptr @df.dart$3atyped_data._Float64x2ListMixin.removeLast$c, i64 -730073319095210781, ptr @df.dart$3atyped_data._Float64x2ListMixin.elementAt$tc, i64 -677989548411720471, ptr @df.dart$3atyped_data._Float64x2ListMixin.$2b$c, i64 -503246348505971594, ptr @df.dart$3atyped_data._Float64x2ListMixin.fillRange$c, i64 -8944174681508873, ptr @df.dart$3atyped_data._TypedList.offsetInBytes$g, i64 590583546444750725, ptr @df.dart$3atyped_data._Float64x2ListMixin.take$tc, i64 1309726782632086582, ptr @df.dart$3atyped_data._TypedListBase.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3atyped_data._Float64x2ListMixin.toList$c, i64 1890975232377856814, ptr @df.dart$3atyped_data._Float64x2ListMixin.map$c, i64 2870274114568068918, ptr @df.dart$3atyped_data._Float64x2List.$5b$5d$tc, i64 3251101298082571214, ptr @df.dart$3atyped_data._Float64x2ListMixin.forEach$c, i64 3337248483243775250, ptr @df.dart$3atyped_data._TypedListBase._containsUnsignedBytes$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 3785544036535605593, ptr @df.dart$3atyped_data._Float64x2List._createList$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4270166662586539371, ptr @df.dart$3atyped_data._Float64x2ListMixin.add$c, i64 4584568332005005361, ptr @df.dart$3atyped_data._Float64x2ListMixin.contains$c, i64 4761704951267565019, ptr @df.dart$3atyped_data._TypedList._typedData$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3atyped_data._TypedListBase.join$c, i64 5816122436118806360, ptr @df.dart$3atyped_data._Float64x2ListMixin.fillRange$tc, i64 6457676092542964098, ptr @df.dart$3atyped_data._TypedList.lengthInBytes$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7276400063129042528, ptr @df.dart$3atyped_data._Float64x2List._fastSetRange$tc, i64 7293158726991237507, ptr @df.dart$3atyped_data._Float64x2ListMixin.setRange$tc, i64 7526586947604351043, ptr @df.dart$3atyped_data._Float64x2List.$5b$5d$3d$c, i64 7800396592418680749, ptr @df.dart$3atyped_data._Float64x2ListMixin.setRange$c, i64 8310139465989025733, ptr @df.dart$3atyped_data._Float64x2ListMixin.indexOf$c, i64 8959578506744725547, ptr @df.dart$3atyped_data._Float64x2ListMixin._slowSetRange$tc, i64 9189246021676726028, ptr @df.dart$3atyped_data._Float64x2List.$5b$5d$c }
define ptr @df.mt.dart$3atyped_data._Float64x2List() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Float64x2List$d
}
@df.mt.dart$3atyped_data._ExternalInt8Array$d = private unnamed_addr constant { i64, i64 } { i64 992, i64 0 }
define ptr @df.mt.dart$3atyped_data._ExternalInt8Array() {
b0:
  ret ptr @df.mt.dart$3atyped_data._ExternalInt8Array$d
}
@df.mt.dart$3atyped_data._ExternalUint8Array$d = private unnamed_addr constant { i64, i64 } { i64 996, i64 0 }
define ptr @df.mt.dart$3atyped_data._ExternalUint8Array() {
b0:
  ret ptr @df.mt.dart$3atyped_data._ExternalUint8Array$d
}
@df.mt.dart$3atyped_data._ExternalUint8ClampedArray$d = private unnamed_addr constant { i64, i64 } { i64 997, i64 0 }
define ptr @df.mt.dart$3atyped_data._ExternalUint8ClampedArray() {
b0:
  ret ptr @df.mt.dart$3atyped_data._ExternalUint8ClampedArray$d
}
@df.mt.dart$3atyped_data._ExternalInt16Array$d = private unnamed_addr constant { i64, i64 } { i64 988, i64 0 }
define ptr @df.mt.dart$3atyped_data._ExternalInt16Array() {
b0:
  ret ptr @df.mt.dart$3atyped_data._ExternalInt16Array$d
}
@df.mt.dart$3atyped_data._ExternalUint16Array$d = private unnamed_addr constant { i64, i64 } { i64 993, i64 0 }
define ptr @df.mt.dart$3atyped_data._ExternalUint16Array() {
b0:
  ret ptr @df.mt.dart$3atyped_data._ExternalUint16Array$d
}
@df.mt.dart$3atyped_data._ExternalInt32Array$d = private unnamed_addr constant { i64, i64 } { i64 989, i64 0 }
define ptr @df.mt.dart$3atyped_data._ExternalInt32Array() {
b0:
  ret ptr @df.mt.dart$3atyped_data._ExternalInt32Array$d
}
@df.mt.dart$3atyped_data._ExternalUint32Array$d = private unnamed_addr constant { i64, i64 } { i64 994, i64 0 }
define ptr @df.mt.dart$3atyped_data._ExternalUint32Array() {
b0:
  ret ptr @df.mt.dart$3atyped_data._ExternalUint32Array$d
}
@df.mt.dart$3atyped_data._ExternalInt64Array$d = private unnamed_addr constant { i64, i64 } { i64 991, i64 0 }
define ptr @df.mt.dart$3atyped_data._ExternalInt64Array() {
b0:
  ret ptr @df.mt.dart$3atyped_data._ExternalInt64Array$d
}
@df.mt.dart$3atyped_data._ExternalUint64Array$d = private unnamed_addr constant { i64, i64 } { i64 995, i64 0 }
define ptr @df.mt.dart$3atyped_data._ExternalUint64Array() {
b0:
  ret ptr @df.mt.dart$3atyped_data._ExternalUint64Array$d
}
@df.mt.dart$3atyped_data._ExternalFloat32Array$d = private unnamed_addr constant { i64, i64 } { i64 984, i64 0 }
define ptr @df.mt.dart$3atyped_data._ExternalFloat32Array() {
b0:
  ret ptr @df.mt.dart$3atyped_data._ExternalFloat32Array$d
}
@df.mt.dart$3atyped_data._ExternalFloat64Array$d = private unnamed_addr constant { i64, i64 } { i64 986, i64 0 }
define ptr @df.mt.dart$3atyped_data._ExternalFloat64Array() {
b0:
  ret ptr @df.mt.dart$3atyped_data._ExternalFloat64Array$d
}
@df.mt.dart$3atyped_data._ExternalFloat32x4Array$d = private unnamed_addr constant { i64, i64 } { i64 985, i64 0 }
define ptr @df.mt.dart$3atyped_data._ExternalFloat32x4Array() {
b0:
  ret ptr @df.mt.dart$3atyped_data._ExternalFloat32x4Array$d
}
@df.mt.dart$3atyped_data._ExternalInt32x4Array$d = private unnamed_addr constant { i64, i64 } { i64 990, i64 0 }
define ptr @df.mt.dart$3atyped_data._ExternalInt32x4Array() {
b0:
  ret ptr @df.mt.dart$3atyped_data._ExternalInt32x4Array$d
}
@df.mt.dart$3atyped_data._ExternalFloat64x2Array$d = private unnamed_addr constant { i64, i64 } { i64 987, i64 0 }
define ptr @df.mt.dart$3atyped_data._ExternalFloat64x2Array() {
b0:
  ret ptr @df.mt.dart$3atyped_data._ExternalFloat64x2Array$d
}
@df.mt.dart$3atyped_data._Float32x4$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 19, i64 15, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -4020828333918261805, ptr @df.dart$3atyped_data._Float32x4.$2f$tc, i64 -4020826134895005383, ptr @df.dart$3atyped_data._Float32x4.$2d$tc, i64 -4020825035383377172, ptr @df.dart$3atyped_data._Float32x4.$2a$tc, i64 -4020823935871748961, ptr @df.dart$3atyped_data._Float32x4.$2b$tc, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -677990647923348682, ptr @df.dart$3atyped_data._Float32x4.$2a$c, i64 -677989548411720471, ptr @df.dart$3atyped_data._Float32x4.$2b$c, i64 -677987349388464049, ptr @df.dart$3atyped_data._Float32x4.$2d$c, i64 -677985150365207627, ptr @df.dart$3atyped_data._Float32x4.$2f$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3atyped_data._Float32x4() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Float32x4$d
}
@df.mt.dart$3atyped_data._Int32x4$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 20, i64 11, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -4020826134895005383, ptr @df.dart$3atyped_data._Int32x4.$2d$tc, i64 -4020823935871748961, ptr @df.dart$3atyped_data._Int32x4.$2b$tc, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -677989548411720471, ptr @df.dart$3atyped_data._Int32x4.$2b$c, i64 -677987349388464049, ptr @df.dart$3atyped_data._Int32x4.$2d$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3atyped_data._Int32x4() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Int32x4$d
}
@df.mt.dart$3atyped_data._Float64x2$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 21, i64 15, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -4020828333918261805, ptr @df.dart$3atyped_data._Float64x2.$2f$tc, i64 -4020826134895005383, ptr @df.dart$3atyped_data._Float64x2.$2d$tc, i64 -4020825035383377172, ptr @df.dart$3atyped_data._Float64x2.$2a$tc, i64 -4020823935871748961, ptr @df.dart$3atyped_data._Float64x2.$2b$tc, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -677990647923348682, ptr @df.dart$3atyped_data._Float64x2.$2a$c, i64 -677989548411720471, ptr @df.dart$3atyped_data._Float64x2.$2b$c, i64 -677987349388464049, ptr @df.dart$3atyped_data._Float64x2.$2d$c, i64 -677985150365207627, ptr @df.dart$3atyped_data._Float64x2.$2f$c, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3atyped_data._Float64x2() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Float64x2$d
}
@df.mt.dart$3atyped_data._TypedListIterator$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 1021, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -5038376148439920376, ptr @df.dart$3atyped_data._TypedListIterator.moveNext$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 1052728634250411761, ptr @df.dart$3atyped_data._TypedListIterator.current$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3atyped_data._TypedListIterator() {
b0:
  ret ptr @df.mt.dart$3atyped_data._TypedListIterator$d
}
@df.mt.dart$3atyped_data._Int8ArrayView$d = private unnamed_addr constant { i64, i64 } { i64 36, i64 0 }
define ptr @df.mt.dart$3atyped_data._Int8ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Int8ArrayView$d
}
@df.mt.dart$3atyped_data._Uint8ArrayView$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 37, i64 51, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8971153493902442575, ptr @df.dart$3atyped_data._Uint8ArrayView.$5b$5d$3d$tc, i64 -8113821193935802361, ptr @df.dart$3atyped_data._Uint8ArrayView._createList$tc, i64 -7830014244959264555, ptr @df.dart$3atyped_data._Uint8ArrayView.elementSizeInBytes$g, i64 -7142806495848668844, ptr @df.dart$3atyped_data._IntListMixin.last$g, i64 -7048868133546680485, ptr @df.dart$3atyped_data._IntListMixin.toList$tc, i64 -6880024560892829041, ptr @df.dart$3atyped_data._IntListMixin.skip$c, i64 -6565620648322651272, ptr @df.dart$3atyped_data._TypedListBase.length$g, i64 -6455655928913991845, ptr @df.dart$3atyped_data._IntListMixin.take$c, i64 -5476269667379286226, ptr @df.dart$3atyped_data._IntListMixin.iterator$g, i64 -4183823290162052582, ptr @df.dart$3atyped_data._TypedListBase.join$tc, i64 -3583372486457872994, ptr @df.dart$3atyped_data._Uint8ArrayView._fastSetRange$c, i64 -3445551396850951156, ptr @df.dart$3atyped_data._TypedListBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3atyped_data._TypedListBase.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3atyped_data._IntListMixin.elementAt$c, i64 -2865225933037962029, ptr @df.dart$3atyped_data._IntListMixin.indexOf$tc, i64 -2322265645133230011, ptr @df.dart$3atyped_data._IntListMixin.skip$tc, i64 -2266111775014587155, ptr @df.dart$3atyped_data._TypedIntListMixin._slowSetRange$c, i64 -1759784064291000274, ptr @df.dart$3atyped_data._TypedListView.buffer$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3atyped_data._TypedListBase.remove$c, i64 -921892303864442672, ptr @df.dart$3atyped_data._IntListMixin.removeLast$c, i64 -730073319095210781, ptr @df.dart$3atyped_data._IntListMixin.elementAt$tc, i64 -677989548411720471, ptr @df.dart$3atyped_data._IntListMixin.$2b$c, i64 -503246348505971594, ptr @df.dart$3atyped_data._IntListMixin.fillRange$c, i64 -8944174681508873, ptr @df.dart$3atyped_data._TypedListView.offsetInBytes$g, i64 590583546444750725, ptr @df.dart$3atyped_data._IntListMixin.take$tc, i64 1309726782632086582, ptr @df.dart$3atyped_data._TypedListBase.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3atyped_data._IntListMixin.toList$c, i64 1890975232377856814, ptr @df.dart$3atyped_data._IntListMixin.map$c, i64 2870274114568068918, ptr @df.dart$3atyped_data._Uint8ArrayView.$5b$5d$tc, i64 3251101298082571214, ptr @df.dart$3atyped_data._IntListMixin.forEach$c, i64 3337248483243775250, ptr @df.dart$3atyped_data._Uint8ArrayView._containsUnsignedBytes$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 3785544036535605593, ptr @df.dart$3atyped_data._Uint8ArrayView._createList$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4270166662586539371, ptr @df.dart$3atyped_data._IntListMixin.add$c, i64 4584568332005005361, ptr @df.dart$3atyped_data._IntListMixin.contains$c, i64 4761704951267565019, ptr @df.dart$3atyped_data._TypedListView._typedData$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3atyped_data._TypedListBase.join$c, i64 5816122436118806360, ptr @df.dart$3atyped_data._IntListMixin.fillRange$tc, i64 6457676092542964098, ptr @df.dart$3atyped_data._TypedListView.lengthInBytes$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7276400063129042528, ptr @df.dart$3atyped_data._Uint8ArrayView._fastSetRange$tc, i64 7293158726991237507, ptr @df.dart$3atyped_data._IntListMixin.setRange$tc, i64 7526586947604351043, ptr @df.dart$3atyped_data._Uint8ArrayView.$5b$5d$3d$c, i64 7800396592418680749, ptr @df.dart$3atyped_data._IntListMixin.setRange$c, i64 8310139465989025733, ptr @df.dart$3atyped_data._IntListMixin.indexOf$c, i64 8959578506744725547, ptr @df.dart$3atyped_data._TypedIntListMixin._slowSetRange$tc, i64 9189246021676726028, ptr @df.dart$3atyped_data._Uint8ArrayView.$5b$5d$c }
define ptr @df.mt.dart$3atyped_data._Uint8ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Uint8ArrayView$d
}
@df.mt.dart$3atyped_data._Uint8ClampedArrayView$d = private unnamed_addr constant { i64, i64 } { i64 38, i64 0 }
define ptr @df.mt.dart$3atyped_data._Uint8ClampedArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Uint8ClampedArrayView$d
}
@df.mt.dart$3atyped_data._Int16ArrayView$d = private unnamed_addr constant { i64, i64 } { i64 39, i64 0 }
define ptr @df.mt.dart$3atyped_data._Int16ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Int16ArrayView$d
}
@df.mt.dart$3atyped_data._Uint16ArrayView$d = private unnamed_addr constant { i64, i64 } { i64 40, i64 0 }
define ptr @df.mt.dart$3atyped_data._Uint16ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Uint16ArrayView$d
}
@df.mt.dart$3atyped_data._Int32ArrayView$d = private unnamed_addr constant { i64, i64 } { i64 41, i64 0 }
define ptr @df.mt.dart$3atyped_data._Int32ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Int32ArrayView$d
}
@df.mt.dart$3atyped_data._Uint32ArrayView$d = private unnamed_addr constant { i64, i64 } { i64 42, i64 0 }
define ptr @df.mt.dart$3atyped_data._Uint32ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Uint32ArrayView$d
}
@df.mt.dart$3atyped_data._Int64ArrayView$d = private unnamed_addr constant { i64, i64 } { i64 43, i64 0 }
define ptr @df.mt.dart$3atyped_data._Int64ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Int64ArrayView$d
}
@df.mt.dart$3atyped_data._Uint64ArrayView$d = private unnamed_addr constant { i64, i64 } { i64 44, i64 0 }
define ptr @df.mt.dart$3atyped_data._Uint64ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Uint64ArrayView$d
}
@df.mt.dart$3atyped_data._Float32ArrayView$d = private unnamed_addr constant { i64, i64 } { i64 45, i64 0 }
define ptr @df.mt.dart$3atyped_data._Float32ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Float32ArrayView$d
}
@df.mt.dart$3atyped_data._Float64ArrayView$d = private unnamed_addr constant { i64, i64 } { i64 46, i64 0 }
define ptr @df.mt.dart$3atyped_data._Float64ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Float64ArrayView$d
}
@df.mt.dart$3atyped_data._Float32x4ArrayView$d = private unnamed_addr constant { i64, i64 } { i64 47, i64 0 }
define ptr @df.mt.dart$3atyped_data._Float32x4ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Float32x4ArrayView$d
}
@df.mt.dart$3atyped_data._Int32x4ArrayView$d = private unnamed_addr constant { i64, i64 } { i64 48, i64 0 }
define ptr @df.mt.dart$3atyped_data._Int32x4ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Int32x4ArrayView$d
}
@df.mt.dart$3atyped_data._Float64x2ArrayView$d = private unnamed_addr constant { i64, i64 } { i64 49, i64 0 }
define ptr @df.mt.dart$3atyped_data._Float64x2ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._Float64x2ArrayView$d
}
@df.mt.dart$3atyped_data._ByteDataView$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 64, i64 15, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8341379617484369062, ptr @df.dart$3atyped_data._ByteDataView.setInt32$tc, i64 -7830014244959264555, ptr @df.dart$3atyped_data._ByteDataView.elementSizeInBytes$g, i64 -6565620648322651272, ptr @df.dart$3atyped_data._ByteDataView.length$g, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1759784064291000274, ptr @df.dart$3atyped_data._ByteDataView.buffer$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -8944174681508873, ptr @df.dart$3atyped_data._ByteDataView.offsetInBytes$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4181654740913895748, ptr @df.dart$3atyped_data._ByteDataView.setInt32$c, i64 4761704951267565019, ptr @df.dart$3atyped_data._ByteDataView._typedData$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 6457676092542964098, ptr @df.dart$3atyped_data._ByteDataView.lengthInBytes$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3atyped_data._ByteDataView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._ByteDataView$d
}
@df.mt.dart$3atyped_data._UnmodifiableInt8ArrayView$d = private unnamed_addr constant { i64, i64 } { i64 50, i64 0 }
define ptr @df.mt.dart$3atyped_data._UnmodifiableInt8ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._UnmodifiableInt8ArrayView$d
}
@df.mt.dart$3atyped_data._UnmodifiableUint8ArrayView$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 51, i64 51, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8971153493902442575, ptr @df.dart$3atyped_data._UnmodifiableUint8ArrayView.$5b$5d$3d$tc, i64 -8113821193935802361, ptr @df.dart$3atyped_data._Uint8ArrayView._createList$tc, i64 -7830014244959264555, ptr @df.dart$3atyped_data._Uint8ArrayView.elementSizeInBytes$g, i64 -7142806495848668844, ptr @df.dart$3atyped_data._IntListMixin.last$g, i64 -7048868133546680485, ptr @df.dart$3atyped_data._IntListMixin.toList$tc, i64 -6880024560892829041, ptr @df.dart$3atyped_data._IntListMixin.skip$c, i64 -6565620648322651272, ptr @df.dart$3atyped_data._TypedListBase.length$g, i64 -6455655928913991845, ptr @df.dart$3atyped_data._IntListMixin.take$c, i64 -5476269667379286226, ptr @df.dart$3atyped_data._IntListMixin.iterator$g, i64 -4183823290162052582, ptr @df.dart$3atyped_data._TypedListBase.join$tc, i64 -3583372486457872994, ptr @df.dart$3atyped_data._Uint8ArrayView._fastSetRange$c, i64 -3445551396850951156, ptr @df.dart$3atyped_data._TypedListBase.toString$c, i64 -3444103220339216083, ptr @df.dart$3atyped_data._TypedListBase.isEmpty$g, i64 -3250703859553326075, ptr @df.dart$3atyped_data._IntListMixin.elementAt$c, i64 -2865225933037962029, ptr @df.dart$3atyped_data._IntListMixin.indexOf$tc, i64 -2322265645133230011, ptr @df.dart$3atyped_data._IntListMixin.skip$tc, i64 -2266111775014587155, ptr @df.dart$3atyped_data._TypedIntListMixin._slowSetRange$c, i64 -1759784064291000274, ptr @df.dart$3atyped_data._UnmodifiableUint8ArrayView.buffer$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -1032508464182748640, ptr @df.dart$3atyped_data._TypedListBase.remove$c, i64 -921892303864442672, ptr @df.dart$3atyped_data._IntListMixin.removeLast$c, i64 -730073319095210781, ptr @df.dart$3atyped_data._IntListMixin.elementAt$tc, i64 -677989548411720471, ptr @df.dart$3atyped_data._IntListMixin.$2b$c, i64 -503246348505971594, ptr @df.dart$3atyped_data._IntListMixin.fillRange$c, i64 -8944174681508873, ptr @df.dart$3atyped_data._TypedListView.offsetInBytes$g, i64 590583546444750725, ptr @df.dart$3atyped_data._IntListMixin.take$tc, i64 1309726782632086582, ptr @df.dart$3atyped_data._TypedListBase.isNotEmpty$g, i64 1886393889905153277, ptr @df.dart$3atyped_data._IntListMixin.toList$c, i64 1890975232377856814, ptr @df.dart$3atyped_data._IntListMixin.map$c, i64 2870274114568068918, ptr @df.dart$3atyped_data._Uint8ArrayView.$5b$5d$tc, i64 3251101298082571214, ptr @df.dart$3atyped_data._IntListMixin.forEach$c, i64 3337248483243775250, ptr @df.dart$3atyped_data._Uint8ArrayView._containsUnsignedBytes$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 3785544036535605593, ptr @df.dart$3atyped_data._Uint8ArrayView._createList$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4270166662586539371, ptr @df.dart$3atyped_data._IntListMixin.add$c, i64 4584568332005005361, ptr @df.dart$3atyped_data._IntListMixin.contains$c, i64 4761704951267565019, ptr @df.dart$3atyped_data._TypedListView._typedData$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 5506484333731414888, ptr @df.dart$3atyped_data._TypedListBase.join$c, i64 5816122436118806360, ptr @df.dart$3atyped_data._IntListMixin.fillRange$tc, i64 6457676092542964098, ptr @df.dart$3atyped_data._TypedListView.lengthInBytes$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7276400063129042528, ptr @df.dart$3atyped_data._Uint8ArrayView._fastSetRange$tc, i64 7293158726991237507, ptr @df.dart$3atyped_data._IntListMixin.setRange$tc, i64 7526586947604351043, ptr @df.dart$3atyped_data._UnmodifiableUint8ArrayView.$5b$5d$3d$c, i64 7800396592418680749, ptr @df.dart$3atyped_data._IntListMixin.setRange$c, i64 8310139465989025733, ptr @df.dart$3atyped_data._IntListMixin.indexOf$c, i64 8959578506744725547, ptr @df.dart$3atyped_data._TypedIntListMixin._slowSetRange$tc, i64 9189246021676726028, ptr @df.dart$3atyped_data._Uint8ArrayView.$5b$5d$c }
define ptr @df.mt.dart$3atyped_data._UnmodifiableUint8ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._UnmodifiableUint8ArrayView$d
}
@df.mt.dart$3atyped_data._UnmodifiableUint8ClampedArrayView$d = private unnamed_addr constant { i64, i64 } { i64 52, i64 0 }
define ptr @df.mt.dart$3atyped_data._UnmodifiableUint8ClampedArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._UnmodifiableUint8ClampedArrayView$d
}
@df.mt.dart$3atyped_data._UnmodifiableInt16ArrayView$d = private unnamed_addr constant { i64, i64 } { i64 53, i64 0 }
define ptr @df.mt.dart$3atyped_data._UnmodifiableInt16ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._UnmodifiableInt16ArrayView$d
}
@df.mt.dart$3atyped_data._UnmodifiableUint16ArrayView$d = private unnamed_addr constant { i64, i64 } { i64 54, i64 0 }
define ptr @df.mt.dart$3atyped_data._UnmodifiableUint16ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._UnmodifiableUint16ArrayView$d
}
@df.mt.dart$3atyped_data._UnmodifiableInt32ArrayView$d = private unnamed_addr constant { i64, i64 } { i64 55, i64 0 }
define ptr @df.mt.dart$3atyped_data._UnmodifiableInt32ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._UnmodifiableInt32ArrayView$d
}
@df.mt.dart$3atyped_data._UnmodifiableUint32ArrayView$d = private unnamed_addr constant { i64, i64 } { i64 56, i64 0 }
define ptr @df.mt.dart$3atyped_data._UnmodifiableUint32ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._UnmodifiableUint32ArrayView$d
}
@df.mt.dart$3atyped_data._UnmodifiableInt64ArrayView$d = private unnamed_addr constant { i64, i64 } { i64 57, i64 0 }
define ptr @df.mt.dart$3atyped_data._UnmodifiableInt64ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._UnmodifiableInt64ArrayView$d
}
@df.mt.dart$3atyped_data._UnmodifiableUint64ArrayView$d = private unnamed_addr constant { i64, i64 } { i64 58, i64 0 }
define ptr @df.mt.dart$3atyped_data._UnmodifiableUint64ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._UnmodifiableUint64ArrayView$d
}
@df.mt.dart$3atyped_data._UnmodifiableFloat32ArrayView$d = private unnamed_addr constant { i64, i64 } { i64 59, i64 0 }
define ptr @df.mt.dart$3atyped_data._UnmodifiableFloat32ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._UnmodifiableFloat32ArrayView$d
}
@df.mt.dart$3atyped_data._UnmodifiableFloat64ArrayView$d = private unnamed_addr constant { i64, i64 } { i64 60, i64 0 }
define ptr @df.mt.dart$3atyped_data._UnmodifiableFloat64ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._UnmodifiableFloat64ArrayView$d
}
@df.mt.dart$3atyped_data._UnmodifiableFloat32x4ArrayView$d = private unnamed_addr constant { i64, i64 } { i64 61, i64 0 }
define ptr @df.mt.dart$3atyped_data._UnmodifiableFloat32x4ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._UnmodifiableFloat32x4ArrayView$d
}
@df.mt.dart$3atyped_data._UnmodifiableInt32x4ArrayView$d = private unnamed_addr constant { i64, i64 } { i64 62, i64 0 }
define ptr @df.mt.dart$3atyped_data._UnmodifiableInt32x4ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._UnmodifiableInt32x4ArrayView$d
}
@df.mt.dart$3atyped_data._UnmodifiableFloat64x2ArrayView$d = private unnamed_addr constant { i64, i64 } { i64 63, i64 0 }
define ptr @df.mt.dart$3atyped_data._UnmodifiableFloat64x2ArrayView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._UnmodifiableFloat64x2ArrayView$d
}
@df.mt.dart$3atyped_data._UnmodifiableByteDataView$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 65, i64 15, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8341379617484369062, ptr @df.dart$3atyped_data._UnmodifiableByteDataView.setInt32$tc, i64 -7830014244959264555, ptr @df.dart$3atyped_data._ByteDataView.elementSizeInBytes$g, i64 -6565620648322651272, ptr @df.dart$3atyped_data._ByteDataView.length$g, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1759784064291000274, ptr @df.dart$3atyped_data._UnmodifiableByteDataView.buffer$g, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -8944174681508873, ptr @df.dart$3atyped_data._ByteDataView.offsetInBytes$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 4181654740913895748, ptr @df.dart$3atyped_data._UnmodifiableByteDataView.setInt32$c, i64 4761704951267565019, ptr @df.dart$3atyped_data._ByteDataView._typedData$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 6457676092542964098, ptr @df.dart$3atyped_data._ByteDataView.lengthInBytes$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3atyped_data._UnmodifiableByteDataView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._UnmodifiableByteDataView$d
}
@df.mt.dart$3atyped_data._UnmodifiableByteBufferView$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 1023, i64 12, i64 -9163797671095228218, ptr @df.dart$3atyped_data._ByteBuffer.$3d$3d$c, i64 -8388772020220820974, ptr @df.dart$3atyped_data._UnmodifiableByteBufferView.asByteData$c, i64 -7802178253387990488, ptr @df.dart$3atyped_data._UnmodifiableByteBufferView.asUint8List$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 2835490342844453032, ptr @df.dart$3atyped_data._UnmodifiableByteBufferView.asByteData$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3atyped_data._ByteBuffer.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 6457676092542964098, ptr @df.dart$3atyped_data._ByteBuffer.lengthInBytes$g, i64 6646197143227882406, ptr @df.dart$3atyped_data._UnmodifiableByteBufferView.asUint8List$tc, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3atyped_data._UnmodifiableByteBufferView() {
b0:
  ret ptr @df.mt.dart$3atyped_data._UnmodifiableByteBufferView$d
}
@df.mt.dart$3aisolate.IsolateSpawnException$d = private unnamed_addr constant { i64, i64 } { i64 916, i64 0 }
define ptr @df.mt.dart$3aisolate.IsolateSpawnException() {
b0:
  ret ptr @df.mt.dart$3aisolate.IsolateSpawnException$d
}
@df.mt.dart$3aisolate.Isolate$d = private unnamed_addr constant { i64, i64 } { i64 915, i64 0 }
define ptr @df.mt.dart$3aisolate.Isolate() {
b0:
  ret ptr @df.mt.dart$3aisolate.Isolate$d
}
@df.mt.dart$3aisolate.RemoteError$d = private unnamed_addr constant { i64, i64 } { i64 919, i64 0 }
define ptr @df.mt.dart$3aisolate.RemoteError() {
b0:
  ret ptr @df.mt.dart$3aisolate.RemoteError$d
}
@df.mt.dart$3aisolate._RemoteRunner$d = private unnamed_addr constant { i64, i64 } { i64 924, i64 0 }
define ptr @df.mt.dart$3aisolate._RemoteRunner() {
b0:
  ret ptr @df.mt.dart$3aisolate._RemoteRunner$d
}
@df.mt.dart$3aisolate._Capability$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 18, i64 7, i64 -9163797671095228218, ptr @df.dart$3aisolate._Capability.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3aisolate._Capability.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aisolate._Capability() {
b0:
  ret ptr @df.mt.dart$3aisolate._Capability$d
}
@df.mt.dart$3aisolate._ReceivePortImpl$d = private unnamed_addr constant { i64, i64 } { i64 923, i64 0 }
define ptr @df.mt.dart$3aisolate._ReceivePortImpl() {
b0:
  ret ptr @df.mt.dart$3aisolate._ReceivePortImpl$d
}
@df.mt.dart$3aisolate._RawReceivePort$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 922, i64 10, i64 -9163797671095228218, ptr @df.dart$3aisolate._RawReceivePort.$3d$3d$c, i64 -8067501549842329812, ptr @df.dart$3aisolate._RawReceivePort.close$c, i64 -4982825901463859484, ptr @df.dart$3aisolate._RawReceivePort.handler$3d$s, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 621680182166144389, ptr @df.dart$3aisolate._RawReceivePort.sendPort$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3aisolate._RawReceivePort.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aisolate._RawReceivePort() {
b0:
  ret ptr @df.mt.dart$3aisolate._RawReceivePort$d
}
@df.mt.dart$3aisolate._SendPort$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 17, i64 8, i64 -9163797671095228218, ptr @df.dart$3aisolate._SendPort.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3aisolate._SendPort.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3aisolate._SendPort.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 7941348200592334934, ptr @df.dart$3aisolate._SendPort.send$c }
define ptr @df.mt.dart$3aisolate._SendPort() {
b0:
  ret ptr @df.mt.dart$3aisolate._SendPort$d
}
@df.mt.dart$3aisolate._TransferableTypedDataImpl$d = private unnamed_addr constant { i64, i64 } { i64 925, i64 0 }
define ptr @df.mt.dart$3aisolate._TransferableTypedDataImpl() {
b0:
  ret ptr @df.mt.dart$3aisolate._TransferableTypedDataImpl$d
}
@df.mt.dart$3adeveloper.ServiceExtensionResponse$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 680, i64 8, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8374845926483294193, ptr @df.dart$3adeveloper.ServiceExtensionResponse.errorCode$g, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3adeveloper.ServiceExtensionResponse() {
b0:
  ret ptr @df.mt.dart$3adeveloper.ServiceExtensionResponse$d
}
@df.mt.dart$3adeveloper.ServiceProtocolInfo$d = private unnamed_addr constant { i64, i64 } { i64 681, i64 0 }
define ptr @df.mt.dart$3adeveloper.ServiceProtocolInfo() {
b0:
  ret ptr @df.mt.dart$3adeveloper.ServiceProtocolInfo$d
}
@df.mt.dart$3adeveloper.Service$d = private unnamed_addr constant { i64, i64 } { i64 679, i64 0 }
define ptr @df.mt.dart$3adeveloper.Service() {
b0:
  ret ptr @df.mt.dart$3adeveloper.Service$d
}
@df.mt.dart$3adeveloper.Flow$d = private unnamed_addr constant { i64, i64 } { i64 677, i64 0 }
define ptr @df.mt.dart$3adeveloper.Flow() {
b0:
  ret ptr @df.mt.dart$3adeveloper.Flow$d
}
@df.mt.dart$3adeveloper.TimelineTask$d = private unnamed_addr constant { i64, i64 } { i64 683, i64 0 }
define ptr @df.mt.dart$3adeveloper.TimelineTask() {
b0:
  ret ptr @df.mt.dart$3adeveloper.TimelineTask$d
}
@df.mt.dart$3adeveloper._AsyncBlock$d = private unnamed_addr constant { i64, i64 } { i64 685, i64 0 }
define ptr @df.mt.dart$3adeveloper._AsyncBlock() {
b0:
  ret ptr @df.mt.dart$3adeveloper._AsyncBlock$d
}
@df.mt.dart$3adeveloper._SyncBlock$d = private unnamed_addr constant { i64, i64 } { i64 686, i64 0 }
define ptr @df.mt.dart$3adeveloper._SyncBlock() {
b0:
  ret ptr @df.mt.dart$3adeveloper._SyncBlock$d
}
@df.mt.dart$3adeveloper._UserTag$d = private unnamed_addr constant { i64, i64 } { i64 687, i64 0 }
define ptr @df.mt.dart$3adeveloper._UserTag() {
b0:
  ret ptr @df.mt.dart$3adeveloper._UserTag$d
}
@df.mt.dart$3anativewrappers.NativeFieldWrapperClass1$d = private unnamed_addr constant { i64, i64 } { i64 956, i64 0 }
define ptr @df.mt.dart$3anativewrappers.NativeFieldWrapperClass1() {
b0:
  ret ptr @df.mt.dart$3anativewrappers.NativeFieldWrapperClass1$d
}
@df.mt.dart$3anativewrappers.NativeFieldWrapperClass2$d = private unnamed_addr constant { i64, i64 } { i64 957, i64 0 }
define ptr @df.mt.dart$3anativewrappers.NativeFieldWrapperClass2() {
b0:
  ret ptr @df.mt.dart$3anativewrappers.NativeFieldWrapperClass2$d
}
@df.mt.dart$3anativewrappers.NativeFieldWrapperClass3$d = private unnamed_addr constant { i64, i64 } { i64 958, i64 0 }
define ptr @df.mt.dart$3anativewrappers.NativeFieldWrapperClass3() {
b0:
  ret ptr @df.mt.dart$3anativewrappers.NativeFieldWrapperClass3$d
}
@df.mt.dart$3anativewrappers.NativeFieldWrapperClass4$d = private unnamed_addr constant { i64, i64 } { i64 959, i64 0 }
define ptr @df.mt.dart$3anativewrappers.NativeFieldWrapperClass4() {
b0:
  ret ptr @df.mt.dart$3anativewrappers.NativeFieldWrapperClass4$d
}
@df.mt.dart$3affi.Pointer$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 719, i64 7, i64 -9163797671095228218, ptr @df.dart$3affi.Pointer.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3affi.Pointer.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3affi.Pointer() {
b0:
  ret ptr @df.mt.dart$3affi.Pointer$d
}
@df.mt.dart$3affi.Array$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 692, i64 7, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3affi.Array() {
b0:
  ret ptr @df.mt.dart$3affi.Array$d
}
@df.mt.dart$3affi._ArraySize$d = private unnamed_addr constant { i64, i64 } { i64 740, i64 0 }
define ptr @df.mt.dart$3affi._ArraySize() {
b0:
  ret ptr @df.mt.dart$3affi._ArraySize$d
}
@df.mt.dart$3affi.Dart_CObject$d = private unnamed_addr constant { i64, i64 } { i64 696, i64 0 }
define ptr @df.mt.dart$3affi.Dart_CObject() {
b0:
  ret ptr @df.mt.dart$3affi.Dart_CObject$d
}
@df.mt.dart$3affi.Native$d = private unnamed_addr constant { i64, i64 } { i64 711, i64 0 }
define ptr @df.mt.dart$3affi.Native() {
b0:
  ret ptr @df.mt.dart$3affi.Native$d
}
@df.mt.dart$3affi.DefaultAsset$d = private unnamed_addr constant { i64, i64 } { i64 697, i64 0 }
define ptr @df.mt.dart$3affi.DefaultAsset() {
b0:
  ret ptr @df.mt.dart$3affi.DefaultAsset$d
}
@df.mt.dart$3affi.Abi$d = private unnamed_addr constant { i64, i64 } { i64 688, i64 0 }
define ptr @df.mt.dart$3affi.Abi() {
b0:
  ret ptr @df.mt.dart$3affi.Abi$d
}
@df.mt.dart$3affi._Architecture$d = private unnamed_addr constant { i64, i64 } { i64 739, i64 0 }
define ptr @df.mt.dart$3affi._Architecture() {
b0:
  ret ptr @df.mt.dart$3affi._Architecture$d
}
@df.mt.dart$3affi._OS$d = private unnamed_addr constant { i64, i64 } { i64 753, i64 0 }
define ptr @df.mt.dart$3affi._OS() {
b0:
  ret ptr @df.mt.dart$3affi._OS$d
}
@df.mt.dart$3affi.AbiSpecificInteger$d = private unnamed_addr constant { i64, i64 } { i64 689, i64 0 }
define ptr @df.mt.dart$3affi.AbiSpecificInteger() {
b0:
  ret ptr @df.mt.dart$3affi.AbiSpecificInteger$d
}
@df.mt.dart$3affi.AbiSpecificIntegerMapping$d = private unnamed_addr constant { i64, i64 } { i64 690, i64 0 }
define ptr @df.mt.dart$3affi.AbiSpecificIntegerMapping() {
b0:
  ret ptr @df.mt.dart$3affi.AbiSpecificIntegerMapping$d
}
@df.mt.dart$3affi.Int8$d = private unnamed_addr constant { i64, i64 } { i64 707, i64 0 }
define ptr @df.mt.dart$3affi.Int8() {
b0:
  ret ptr @df.mt.dart$3affi.Int8$d
}
@df.mt.dart$3affi.Int16$d = private unnamed_addr constant { i64, i64 } { i64 704, i64 0 }
define ptr @df.mt.dart$3affi.Int16() {
b0:
  ret ptr @df.mt.dart$3affi.Int16$d
}
@df.mt.dart$3affi.Int32$d = private unnamed_addr constant { i64, i64 } { i64 705, i64 0 }
define ptr @df.mt.dart$3affi.Int32() {
b0:
  ret ptr @df.mt.dart$3affi.Int32$d
}
@df.mt.dart$3affi.Int64$d = private unnamed_addr constant { i64, i64 } { i64 706, i64 0 }
define ptr @df.mt.dart$3affi.Int64() {
b0:
  ret ptr @df.mt.dart$3affi.Int64$d
}
@df.mt.dart$3affi.Uint8$d = private unnamed_addr constant { i64, i64 } { i64 728, i64 0 }
define ptr @df.mt.dart$3affi.Uint8() {
b0:
  ret ptr @df.mt.dart$3affi.Uint8$d
}
@df.mt.dart$3affi.Uint16$d = private unnamed_addr constant { i64, i64 } { i64 725, i64 0 }
define ptr @df.mt.dart$3affi.Uint16() {
b0:
  ret ptr @df.mt.dart$3affi.Uint16$d
}
@df.mt.dart$3affi.Uint32$d = private unnamed_addr constant { i64, i64 } { i64 726, i64 0 }
define ptr @df.mt.dart$3affi.Uint32() {
b0:
  ret ptr @df.mt.dart$3affi.Uint32$d
}
@df.mt.dart$3affi.Uint64$d = private unnamed_addr constant { i64, i64 } { i64 727, i64 0 }
define ptr @df.mt.dart$3affi.Uint64() {
b0:
  ret ptr @df.mt.dart$3affi.Uint64$d
}
@df.mt.dart$3affi.Float$d = private unnamed_addr constant { i64, i64 } { i64 701, i64 0 }
define ptr @df.mt.dart$3affi.Float() {
b0:
  ret ptr @df.mt.dart$3affi.Float$d
}
@df.mt.dart$3affi.Double$d = private unnamed_addr constant { i64, i64 } { i64 698, i64 0 }
define ptr @df.mt.dart$3affi.Double() {
b0:
  ret ptr @df.mt.dart$3affi.Double$d
}
@df.mt.dart$3affi.Bool$d = private unnamed_addr constant { i64, i64 } { i64 693, i64 0 }
define ptr @df.mt.dart$3affi.Bool() {
b0:
  ret ptr @df.mt.dart$3affi.Bool$d
}
@df.mt.dart$3affi.DartRepresentationOf$d = private unnamed_addr constant { i64, i64 } { i64 695, i64 0 }
define ptr @df.mt.dart$3affi.DartRepresentationOf() {
b0:
  ret ptr @df.mt.dart$3affi.DartRepresentationOf$d
}
@df.mt.dart$3affi.Char$d = private unnamed_addr constant { i64, i64 } { i64 694, i64 0 }
define ptr @df.mt.dart$3affi.Char() {
b0:
  ret ptr @df.mt.dart$3affi.Char$d
}
@df.mt.dart$3affi.SignedChar$d = private unnamed_addr constant { i64, i64 } { i64 721, i64 0 }
define ptr @df.mt.dart$3affi.SignedChar() {
b0:
  ret ptr @df.mt.dart$3affi.SignedChar$d
}
@df.mt.dart$3affi.UnsignedChar$d = private unnamed_addr constant { i64, i64 } { i64 731, i64 0 }
define ptr @df.mt.dart$3affi.UnsignedChar() {
b0:
  ret ptr @df.mt.dart$3affi.UnsignedChar$d
}
@df.mt.dart$3affi.Short$d = private unnamed_addr constant { i64, i64 } { i64 720, i64 0 }
define ptr @df.mt.dart$3affi.Short() {
b0:
  ret ptr @df.mt.dart$3affi.Short$d
}
@df.mt.dart$3affi.UnsignedShort$d = private unnamed_addr constant { i64, i64 } { i64 735, i64 0 }
define ptr @df.mt.dart$3affi.UnsignedShort() {
b0:
  ret ptr @df.mt.dart$3affi.UnsignedShort$d
}
@df.mt.dart$3affi.Int$d = private unnamed_addr constant { i64, i64 } { i64 703, i64 0 }
define ptr @df.mt.dart$3affi.Int() {
b0:
  ret ptr @df.mt.dart$3affi.Int$d
}
@df.mt.dart$3affi.UnsignedInt$d = private unnamed_addr constant { i64, i64 } { i64 732, i64 0 }
define ptr @df.mt.dart$3affi.UnsignedInt() {
b0:
  ret ptr @df.mt.dart$3affi.UnsignedInt$d
}
@df.mt.dart$3affi.Long$d = private unnamed_addr constant { i64, i64 } { i64 709, i64 0 }
define ptr @df.mt.dart$3affi.Long() {
b0:
  ret ptr @df.mt.dart$3affi.Long$d
}
@df.mt.dart$3affi.UnsignedLong$d = private unnamed_addr constant { i64, i64 } { i64 733, i64 0 }
define ptr @df.mt.dart$3affi.UnsignedLong() {
b0:
  ret ptr @df.mt.dart$3affi.UnsignedLong$d
}
@df.mt.dart$3affi.LongLong$d = private unnamed_addr constant { i64, i64 } { i64 710, i64 0 }
define ptr @df.mt.dart$3affi.LongLong() {
b0:
  ret ptr @df.mt.dart$3affi.LongLong$d
}
@df.mt.dart$3affi.UnsignedLongLong$d = private unnamed_addr constant { i64, i64 } { i64 734, i64 0 }
define ptr @df.mt.dart$3affi.UnsignedLongLong() {
b0:
  ret ptr @df.mt.dart$3affi.UnsignedLongLong$d
}
@df.mt.dart$3affi.IntPtr$d = private unnamed_addr constant { i64, i64 } { i64 708, i64 0 }
define ptr @df.mt.dart$3affi.IntPtr() {
b0:
  ret ptr @df.mt.dart$3affi.IntPtr$d
}
@df.mt.dart$3affi.UintPtr$d = private unnamed_addr constant { i64, i64 } { i64 729, i64 0 }
define ptr @df.mt.dart$3affi.UintPtr() {
b0:
  ret ptr @df.mt.dart$3affi.UintPtr$d
}
@df.mt.dart$3affi.Size$d = private unnamed_addr constant { i64, i64 } { i64 722, i64 0 }
define ptr @df.mt.dart$3affi.Size() {
b0:
  ret ptr @df.mt.dart$3affi.Size$d
}
@df.mt.dart$3affi.WChar$d = private unnamed_addr constant { i64, i64 } { i64 738, i64 0 }
define ptr @df.mt.dart$3affi.WChar() {
b0:
  ret ptr @df.mt.dart$3affi.WChar$d
}
@df.mt.dart$3affi.DynamicLibrary$d = private unnamed_addr constant { i64, i64 } { i64 699, i64 0 }
define ptr @df.mt.dart$3affi.DynamicLibrary() {
b0:
  ret ptr @df.mt.dart$3affi.DynamicLibrary$d
}
@df.mt.dart$3affi._Compound$d = private unnamed_addr constant { i64, i64 } { i64 741, i64 0 }
define ptr @df.mt.dart$3affi._Compound() {
b0:
  ret ptr @df.mt.dart$3affi._Compound$d
}
@df.mt.dart$3affi.Packed$d = private unnamed_addr constant { i64, i64 } { i64 718, i64 0 }
define ptr @df.mt.dart$3affi.Packed() {
b0:
  ret ptr @df.mt.dart$3affi.Packed$d
}
@df.mt.dart$3affi._FfiCall$d = private unnamed_addr constant { i64, i64 } { i64 743, i64 0 }
define ptr @df.mt.dart$3affi._FfiCall() {
b0:
  ret ptr @df.mt.dart$3affi._FfiCall$d
}
@df.mt.dart$3affi._NativeCallableIsolateLocal$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 747, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8067501549842329812, ptr @df.dart$3affi._NativeCallableBase.close$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 8446190591372432197, ptr @df.dart$3affi._NativeCallableIsolateLocal._close$c }
define ptr @df.mt.dart$3affi._NativeCallableIsolateLocal() {
b0:
  ret ptr @df.mt.dart$3affi._NativeCallableIsolateLocal$d
}
@df.mt.dart$3affi._NativeCallableListener$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 748, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8067501549842329812, ptr @df.dart$3affi._NativeCallableBase.close$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 8446190591372432197, ptr @df.dart$3affi._NativeCallableListener._close$c }
define ptr @df.mt.dart$3affi._NativeCallableListener() {
b0:
  ret ptr @df.mt.dart$3affi._NativeCallableListener$d
}
@df.mt.dart$3affi._NativeCallableSync$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 749, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8067501549842329812, ptr @df.dart$3affi._NativeCallableBase.close$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g, i64 8446190591372432197, ptr @df.dart$3affi._NativeCallableSync._close$c }
define ptr @df.mt.dart$3affi._NativeCallableSync() {
b0:
  ret ptr @df.mt.dart$3affi._NativeCallableSync$d
}
@df.mt.dart$3affi._FfiAbiSpecificMapping$d = private unnamed_addr constant { i64, i64 } { i64 742, i64 0 }
define ptr @df.mt.dart$3affi._FfiAbiSpecificMapping() {
b0:
  ret ptr @df.mt.dart$3affi._FfiAbiSpecificMapping$d
}
@df.mt.dart$3affi._NativeFinalizer$d = private unnamed_addr constant { i64, i64 } { i64 751, i64 0 }
define ptr @df.mt.dart$3affi._NativeFinalizer() {
b0:
  ret ptr @df.mt.dart$3affi._NativeFinalizer$d
}
@df.mt.dart$3affi._FfiStructLayout$d = private unnamed_addr constant { i64, i64 } { i64 745, i64 0 }
define ptr @df.mt.dart$3affi._FfiStructLayout() {
b0:
  ret ptr @df.mt.dart$3affi._FfiStructLayout$d
}
@df.mt.dart$3affi._FfiInlineArray$d = private unnamed_addr constant { i64, i64 } { i64 744, i64 0 }
define ptr @df.mt.dart$3affi._FfiInlineArray() {
b0:
  ret ptr @df.mt.dart$3affi._FfiInlineArray$d
}
@df.mt.dart$3a_http.HttpConnectionsInfo$d = private unnamed_addr constant { i64, i64 } { i64 169, i64 0 }
define ptr @df.mt.dart$3a_http.HttpConnectionsInfo() {
b0:
  ret ptr @df.mt.dart$3a_http.HttpConnectionsInfo$d
}
@df.mt.dart$3a_http.SameSite$d = private unnamed_addr constant { i64, i64 } { i64 181, i64 0 }
define ptr @df.mt.dart$3a_http.SameSite() {
b0:
  ret ptr @df.mt.dart$3a_http.SameSite$d
}
@df.mt.dart$3a_http.HttpClientResponseCompressionState$d = private unnamed_addr constant { i64, i64 } { i64 167, i64 0 }
define ptr @df.mt.dart$3a_http.HttpClientResponseCompressionState() {
b0:
  ret ptr @df.mt.dart$3a_http.HttpClientResponseCompressionState$d
}
@df.mt.dart$3a_http.HttpException$d = private unnamed_addr constant { i64, i64 } { i64 171, i64 0 }
define ptr @df.mt.dart$3a_http.HttpException() {
b0:
  ret ptr @df.mt.dart$3a_http.HttpException$d
}
@df.mt.dart$3a_http.RedirectException$d = private unnamed_addr constant { i64, i64 } { i64 179, i64 0 }
define ptr @df.mt.dart$3a_http.RedirectException() {
b0:
  ret ptr @df.mt.dart$3a_http.RedirectException$d
}
@df.mt.dart$3a_http._CryptoUtils$d = private unnamed_addr constant { i64, i64 } { i64 197, i64 0 }
define ptr @df.mt.dart$3a_http._CryptoUtils() {
b0:
  ret ptr @df.mt.dart$3a_http._CryptoUtils$d
}
@df.mt.dart$3a_http._MD5$d = private unnamed_addr constant { i64, i64 } { i64 231, i64 0 }
define ptr @df.mt.dart$3a_http._MD5() {
b0:
  ret ptr @df.mt.dart$3a_http._MD5$d
}
@df.mt.dart$3a_http._SHA1$d = private unnamed_addr constant { i64, i64 } { i64 237, i64 0 }
define ptr @df.mt.dart$3a_http._SHA1() {
b0:
  ret ptr @df.mt.dart$3a_http._SHA1$d
}
@df.mt.dart$3a_http.HttpDate$d = private unnamed_addr constant { i64, i64 } { i64 170, i64 0 }
define ptr @df.mt.dart$3a_http.HttpDate() {
b0:
  ret ptr @df.mt.dart$3a_http.HttpDate$d
}
@df.mt.dart$3a_http._HttpHeaders$d = private unnamed_addr constant { i64, i64 } { i64 214, i64 0 }
define ptr @df.mt.dart$3a_http._HttpHeaders() {
b0:
  ret ptr @df.mt.dart$3a_http._HttpHeaders$d
}
@df.mt.dart$3a_http._HeaderValue$d = private unnamed_addr constant { i64, i64 } { i64 201, i64 0 }
define ptr @df.mt.dart$3a_http._HeaderValue() {
b0:
  ret ptr @df.mt.dart$3a_http._HeaderValue$d
}
@df.mt.dart$3a_http._ContentType$d = private unnamed_addr constant { i64, i64 } { i64 193, i64 0 }
define ptr @df.mt.dart$3a_http._ContentType() {
b0:
  ret ptr @df.mt.dart$3a_http._ContentType$d
}
@df.mt.dart$3a_http._Cookie$d = private unnamed_addr constant { i64, i64 } { i64 194, i64 0 }
define ptr @df.mt.dart$3a_http._Cookie() {
b0:
  ret ptr @df.mt.dart$3a_http._Cookie$d
}
@df.mt.dart$3a_http._HttpProfileEvent$d = private unnamed_addr constant { i64, i64 } { i64 223, i64 0 }
define ptr @df.mt.dart$3a_http._HttpProfileEvent() {
b0:
  ret ptr @df.mt.dart$3a_http._HttpProfileEvent$d
}
@df.mt.dart$3a_http._HttpProfileData$d = private unnamed_addr constant { i64, i64 } { i64 222, i64 0 }
define ptr @df.mt.dart$3a_http._HttpProfileData() {
b0:
  ret ptr @df.mt.dart$3a_http._HttpProfileData$d
}
@df.mt.dart$3a_http._CopyingBytesBuilder$d = private unnamed_addr constant { i64, i64 } { i64 195, i64 0 }
define ptr @df.mt.dart$3a_http._CopyingBytesBuilder() {
b0:
  ret ptr @df.mt.dart$3a_http._CopyingBytesBuilder$d
}
@df.mt.dart$3a_http._HttpIncoming$d = private unnamed_addr constant { i64, i64 } { i64 217, i64 0 }
define ptr @df.mt.dart$3a_http._HttpIncoming() {
b0:
  ret ptr @df.mt.dart$3a_http._HttpIncoming$d
}
@df.mt.dart$3a_http._HttpRequest$d = private unnamed_addr constant { i64, i64 } { i64 224, i64 0 }
define ptr @df.mt.dart$3a_http._HttpRequest() {
b0:
  ret ptr @df.mt.dart$3a_http._HttpRequest$d
}
@df.mt.dart$3a_http._HttpClientResponse$d = private unnamed_addr constant { i64, i64 } { i64 208, i64 0 }
define ptr @df.mt.dart$3a_http._HttpClientResponse() {
b0:
  ret ptr @df.mt.dart$3a_http._HttpClientResponse$d
}
@df.mt.dart$3a_http._ToUint8List$d = private unnamed_addr constant { i64, i64 } { i64 242, i64 0 }
define ptr @df.mt.dart$3a_http._ToUint8List() {
b0:
  ret ptr @df.mt.dart$3a_http._ToUint8List$d
}
@df.mt.dart$3a_http._Uint8ListConversionSink$d = private unnamed_addr constant { i64, i64 } { i64 243, i64 0 }
define ptr @df.mt.dart$3a_http._Uint8ListConversionSink() {
b0:
  ret ptr @df.mt.dart$3a_http._Uint8ListConversionSink$d
}
@df.mt.dart$3a_http._StreamSinkImpl$d = private unnamed_addr constant { i64, i64 } { i64 241, i64 0 }
define ptr @df.mt.dart$3a_http._StreamSinkImpl() {
b0:
  ret ptr @df.mt.dart$3a_http._StreamSinkImpl$d
}
@df.mt.dart$3a_http._IOSinkImpl$d = private unnamed_addr constant { i64, i64 } { i64 230, i64 0 }
define ptr @df.mt.dart$3a_http._IOSinkImpl() {
b0:
  ret ptr @df.mt.dart$3a_http._IOSinkImpl$d
}
@df.mt.dart$3a_http._HttpResponse$d = private unnamed_addr constant { i64, i64 } { i64 225, i64 0 }
define ptr @df.mt.dart$3a_http._HttpResponse() {
b0:
  ret ptr @df.mt.dart$3a_http._HttpResponse$d
}
@df.mt.dart$3a_http._HttpClientRequest$d = private unnamed_addr constant { i64, i64 } { i64 207, i64 0 }
define ptr @df.mt.dart$3a_http._HttpClientRequest() {
b0:
  ret ptr @df.mt.dart$3a_http._HttpClientRequest$d
}
@df.mt.dart$3a_http._HttpGZipSink$d = private unnamed_addr constant { i64, i64 } { i64 213, i64 0 }
define ptr @df.mt.dart$3a_http._HttpGZipSink() {
b0:
  ret ptr @df.mt.dart$3a_http._HttpGZipSink$d
}
@df.mt.dart$3a_http._HttpOutgoing$d = private unnamed_addr constant { i64, i64 } { i64 219, i64 0 }
define ptr @df.mt.dart$3a_http._HttpOutgoing() {
b0:
  ret ptr @df.mt.dart$3a_http._HttpOutgoing$d
}
@df.mt.dart$3a_http._HttpClientConnection$d = private unnamed_addr constant { i64, i64 } { i64 204, i64 0 }
define ptr @df.mt.dart$3a_http._HttpClientConnection() {
b0:
  ret ptr @df.mt.dart$3a_http._HttpClientConnection$d
}
@df.mt.dart$3a_http._ConnectionInfo$d = private unnamed_addr constant { i64, i64 } { i64 190, i64 0 }
define ptr @df.mt.dart$3a_http._ConnectionInfo() {
b0:
  ret ptr @df.mt.dart$3a_http._ConnectionInfo$d
}
@df.mt.dart$3a_http._ConnectionTarget$d = private unnamed_addr constant { i64, i64 } { i64 191, i64 0 }
define ptr @df.mt.dart$3a_http._ConnectionTarget() {
b0:
  ret ptr @df.mt.dart$3a_http._ConnectionTarget$d
}
@df.mt.dart$3a_http._HttpClient$d = private unnamed_addr constant { i64, i64 } { i64 202, i64 0 }
define ptr @df.mt.dart$3a_http._HttpClient() {
b0:
  ret ptr @df.mt.dart$3a_http._HttpClient$d
}
@df.mt.dart$3a_http._HttpConnection$d = private unnamed_addr constant { i64, i64 } { i64 209, i64 0 }
define ptr @df.mt.dart$3a_http._HttpConnection() {
b0:
  ret ptr @df.mt.dart$3a_http._HttpConnection$d
}
@df.mt.dart$3a_http._HttpServer$d = private unnamed_addr constant { i64, i64 } { i64 226, i64 0 }
define ptr @df.mt.dart$3a_http._HttpServer() {
b0:
  ret ptr @df.mt.dart$3a_http._HttpServer$d
}
@df.mt.dart$3a_http._ProxyConfiguration$d = private unnamed_addr constant { i64, i64 } { i64 234, i64 0 }
define ptr @df.mt.dart$3a_http._ProxyConfiguration() {
b0:
  ret ptr @df.mt.dart$3a_http._ProxyConfiguration$d
}
@df.mt.dart$3a_http._Proxy$d = private unnamed_addr constant { i64, i64 } { i64 233, i64 0 }
define ptr @df.mt.dart$3a_http._Proxy() {
b0:
  ret ptr @df.mt.dart$3a_http._Proxy$d
}
@df.mt.dart$3a_http._HttpConnectionInfo$d = private unnamed_addr constant { i64, i64 } { i64 210, i64 0 }
define ptr @df.mt.dart$3a_http._HttpConnectionInfo() {
b0:
  ret ptr @df.mt.dart$3a_http._HttpConnectionInfo$d
}
@df.mt.dart$3a_http._DetachedSocket$d = private unnamed_addr constant { i64, i64 } { i64 198, i64 0 }
define ptr @df.mt.dart$3a_http._DetachedSocket() {
b0:
  ret ptr @df.mt.dart$3a_http._DetachedSocket$d
}
@df.mt.dart$3a_http._AuthenticationScheme$d = private unnamed_addr constant { i64, i64 } { i64 187, i64 0 }
define ptr @df.mt.dart$3a_http._AuthenticationScheme() {
b0:
  ret ptr @df.mt.dart$3a_http._AuthenticationScheme$d
}
@df.mt.dart$3a_http._SiteCredentials$d = private unnamed_addr constant { i64, i64 } { i64 239, i64 0 }
define ptr @df.mt.dart$3a_http._SiteCredentials() {
b0:
  ret ptr @df.mt.dart$3a_http._SiteCredentials$d
}
@df.mt.dart$3a_http._ProxyCredentials$d = private unnamed_addr constant { i64, i64 } { i64 235, i64 0 }
define ptr @df.mt.dart$3a_http._ProxyCredentials() {
b0:
  ret ptr @df.mt.dart$3a_http._ProxyCredentials$d
}
@df.mt.dart$3a_http._HttpClientBasicCredentials$d = private unnamed_addr constant { i64, i64 } { i64 203, i64 0 }
define ptr @df.mt.dart$3a_http._HttpClientBasicCredentials() {
b0:
  ret ptr @df.mt.dart$3a_http._HttpClientBasicCredentials$d
}
@df.mt.dart$3a_http._HttpClientDigestCredentials$d = private unnamed_addr constant { i64, i64 } { i64 206, i64 0 }
define ptr @df.mt.dart$3a_http._HttpClientDigestCredentials() {
b0:
  ret ptr @df.mt.dart$3a_http._HttpClientDigestCredentials$d
}
@df.mt.dart$3a_http._RedirectInfo$d = private unnamed_addr constant { i64, i64 } { i64 236, i64 0 }
define ptr @df.mt.dart$3a_http._RedirectInfo() {
b0:
  ret ptr @df.mt.dart$3a_http._RedirectInfo$d
}
@df.mt.dart$3a_http._Const$d = private unnamed_addr constant { i64, i64 } { i64 192, i64 0 }
define ptr @df.mt.dart$3a_http._Const() {
b0:
  ret ptr @df.mt.dart$3a_http._Const$d
}
@df.mt.dart$3a_http._CharCode$d = private unnamed_addr constant { i64, i64 } { i64 188, i64 0 }
define ptr @df.mt.dart$3a_http._CharCode() {
b0:
  ret ptr @df.mt.dart$3a_http._CharCode$d
}
@df.mt.dart$3a_http._State$d = private unnamed_addr constant { i64, i64 } { i64 240, i64 0 }
define ptr @df.mt.dart$3a_http._State() {
b0:
  ret ptr @df.mt.dart$3a_http._State$d
}
@df.mt.dart$3a_http._HttpVersion$d = private unnamed_addr constant { i64, i64 } { i64 229, i64 0 }
define ptr @df.mt.dart$3a_http._HttpVersion() {
b0:
  ret ptr @df.mt.dart$3a_http._HttpVersion$d
}
@df.mt.dart$3a_http._MessageType$d = private unnamed_addr constant { i64, i64 } { i64 232, i64 0 }
define ptr @df.mt.dart$3a_http._MessageType() {
b0:
  ret ptr @df.mt.dart$3a_http._MessageType$d
}
@df.mt.dart$3a_http._HttpDetachedStreamSubscription$d = private unnamed_addr constant { i64, i64 } { i64 212, i64 0 }
define ptr @df.mt.dart$3a_http._HttpDetachedStreamSubscription() {
b0:
  ret ptr @df.mt.dart$3a_http._HttpDetachedStreamSubscription$d
}
@df.mt.dart$3a_http._HttpDetachedIncoming$d = private unnamed_addr constant { i64, i64 } { i64 211, i64 0 }
define ptr @df.mt.dart$3a_http._HttpDetachedIncoming() {
b0:
  ret ptr @df.mt.dart$3a_http._HttpDetachedIncoming$d
}
@df.mt.dart$3a_http._HttpParser$d = private unnamed_addr constant { i64, i64 } { i64 221, i64 0 }
define ptr @df.mt.dart$3a_http._HttpParser() {
b0:
  ret ptr @df.mt.dart$3a_http._HttpParser$d
}
@df.mt.dart$3a_http._HttpSession$d = private unnamed_addr constant { i64, i64 } { i64 227, i64 0 }
define ptr @df.mt.dart$3a_http._HttpSession() {
b0:
  ret ptr @df.mt.dart$3a_http._HttpSession$d
}
@df.mt.dart$3a_http._HttpSessionManager$d = private unnamed_addr constant { i64, i64 } { i64 228, i64 0 }
define ptr @df.mt.dart$3a_http._HttpSessionManager() {
b0:
  ret ptr @df.mt.dart$3a_http._HttpSessionManager$d
}
@df.mt.dart$3a_http._HttpOverridesScope$d = private unnamed_addr constant { i64, i64 } { i64 220, i64 0 }
define ptr @df.mt.dart$3a_http._HttpOverridesScope() {
b0:
  ret ptr @df.mt.dart$3a_http._HttpOverridesScope$d
}
@df.mt.dart$3a_http.CompressionOptions$d = private unnamed_addr constant { i64, i64 } { i64 157, i64 0 }
define ptr @df.mt.dart$3a_http.CompressionOptions() {
b0:
  ret ptr @df.mt.dart$3a_http.CompressionOptions$d
}
@df.mt.dart$3a_http.WebSocketException$d = private unnamed_addr constant { i64, i64 } { i64 184, i64 0 }
define ptr @df.mt.dart$3a_http.WebSocketException() {
b0:
  ret ptr @df.mt.dart$3a_http.WebSocketException$d
}
@df.mt.dart$3a_http._WebSocketMessageType$d = private unnamed_addr constant { i64, i64 } { i64 246, i64 0 }
define ptr @df.mt.dart$3a_http._WebSocketMessageType() {
b0:
  ret ptr @df.mt.dart$3a_http._WebSocketMessageType$d
}
@df.mt.dart$3a_http._WebSocketOpcode$d = private unnamed_addr constant { i64, i64 } { i64 247, i64 0 }
define ptr @df.mt.dart$3a_http._WebSocketOpcode() {
b0:
  ret ptr @df.mt.dart$3a_http._WebSocketOpcode$d
}
@df.mt.dart$3a_http._EncodedString$d = private unnamed_addr constant { i64, i64 } { i64 199, i64 0 }
define ptr @df.mt.dart$3a_http._EncodedString() {
b0:
  ret ptr @df.mt.dart$3a_http._EncodedString$d
}
@df.mt.dart$3a_http._CompressionMaxWindowBits$d = private unnamed_addr constant { i64, i64 } { i64 189, i64 0 }
define ptr @df.mt.dart$3a_http._CompressionMaxWindowBits() {
b0:
  ret ptr @df.mt.dart$3a_http._CompressionMaxWindowBits$d
}
@df.mt.dart$3a_http._WebSocketProtocolTransformer$d = private unnamed_addr constant { i64, i64 } { i64 252, i64 0 }
define ptr @df.mt.dart$3a_http._WebSocketProtocolTransformer() {
b0:
  ret ptr @df.mt.dart$3a_http._WebSocketProtocolTransformer$d
}
@df.mt.dart$3a_http._WebSocketPing$d = private unnamed_addr constant { i64, i64 } { i64 250, i64 0 }
define ptr @df.mt.dart$3a_http._WebSocketPing() {
b0:
  ret ptr @df.mt.dart$3a_http._WebSocketPing$d
}
@df.mt.dart$3a_http._WebSocketPong$d = private unnamed_addr constant { i64, i64 } { i64 251, i64 0 }
define ptr @df.mt.dart$3a_http._WebSocketPong() {
b0:
  ret ptr @df.mt.dart$3a_http._WebSocketPong$d
}
@df.mt.dart$3a_http._WebSocketTransformerImpl$d = private unnamed_addr constant { i64, i64 } { i64 253, i64 0 }
define ptr @df.mt.dart$3a_http._WebSocketTransformerImpl() {
b0:
  ret ptr @df.mt.dart$3a_http._WebSocketTransformerImpl$d
}
@df.mt.dart$3a_http._WebSocketPerMessageDeflate$d = private unnamed_addr constant { i64, i64 } { i64 249, i64 0 }
define ptr @df.mt.dart$3a_http._WebSocketPerMessageDeflate() {
b0:
  ret ptr @df.mt.dart$3a_http._WebSocketPerMessageDeflate$d
}
@df.mt.dart$3a_http._WebSocketOutgoingTransformer$d = private unnamed_addr constant { i64, i64 } { i64 248, i64 0 }
define ptr @df.mt.dart$3a_http._WebSocketOutgoingTransformer() {
b0:
  ret ptr @df.mt.dart$3a_http._WebSocketOutgoingTransformer$d
}
@df.mt.dart$3a_http._WebSocketConsumer$d = private unnamed_addr constant { i64, i64 } { i64 244, i64 0 }
define ptr @df.mt.dart$3a_http._WebSocketConsumer() {
b0:
  ret ptr @df.mt.dart$3a_http._WebSocketConsumer$d
}
@df.mt.dart$3a_http._WebSocketImpl$d = private unnamed_addr constant { i64, i64 } { i64 245, i64 0 }
define ptr @df.mt.dart$3a_http._WebSocketImpl() {
b0:
  ret ptr @df.mt.dart$3a_http._WebSocketImpl$d
}
@df.mt.dart$3aio.OSError$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 779, i64 9, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8460972710066630285, ptr @df.dart$3aio.OSError.message$g, i64 -8374845926483294193, ptr @df.dart$3aio.OSError.errorCode$g, i64 -3445551396850951156, ptr @df.dart$3aio.OSError.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aio.OSError() {
b0:
  ret ptr @df.mt.dart$3aio.OSError$d
}
@df.mt.dart$3aio._BufferAndStart$d = private unnamed_addr constant { i64, i64 } { i64 831, i64 0 }
define ptr @df.mt.dart$3aio._BufferAndStart() {
b0:
  ret ptr @df.mt.dart$3aio._BufferAndStart$d
}
@df.mt.dart$3aio._IOCrypto$d = private unnamed_addr constant { i64, i64 } { i64 847, i64 0 }
define ptr @df.mt.dart$3aio._IOCrypto() {
b0:
  ret ptr @df.mt.dart$3aio._IOCrypto$d
}
@df.mt.dart$3aio.ZLibCodec$d = private unnamed_addr constant { i64, i64 } { i64 824, i64 0 }
define ptr @df.mt.dart$3aio.ZLibCodec() {
b0:
  ret ptr @df.mt.dart$3aio.ZLibCodec$d
}
@df.mt.dart$3aio.GZipCodec$d = private unnamed_addr constant { i64, i64 } { i64 770, i64 0 }
define ptr @df.mt.dart$3aio.GZipCodec() {
b0:
  ret ptr @df.mt.dart$3aio.GZipCodec$d
}
@df.mt.dart$3aio.ZLibEncoder$d = private unnamed_addr constant { i64, i64 } { i64 826, i64 0 }
define ptr @df.mt.dart$3aio.ZLibEncoder() {
b0:
  ret ptr @df.mt.dart$3aio.ZLibEncoder$d
}
@df.mt.dart$3aio.ZLibDecoder$d = private unnamed_addr constant { i64, i64 } { i64 825, i64 0 }
define ptr @df.mt.dart$3aio.ZLibDecoder() {
b0:
  ret ptr @df.mt.dart$3aio.ZLibDecoder$d
}
@df.mt.dart$3aio._BufferSink$d = private unnamed_addr constant { i64, i64 } { i64 832, i64 0 }
define ptr @df.mt.dart$3aio._BufferSink() {
b0:
  ret ptr @df.mt.dart$3aio._BufferSink$d
}
@df.mt.dart$3aio._ZLibEncoderSink$d = private unnamed_addr constant { i64, i64 } { i64 912, i64 0 }
define ptr @df.mt.dart$3aio._ZLibEncoderSink() {
b0:
  ret ptr @df.mt.dart$3aio._ZLibEncoderSink$d
}
@df.mt.dart$3aio._ZLibDecoderSink$d = private unnamed_addr constant { i64, i64 } { i64 910, i64 0 }
define ptr @df.mt.dart$3aio._ZLibDecoderSink() {
b0:
  ret ptr @df.mt.dart$3aio._ZLibDecoderSink$d
}
@df.mt.dart$3aio._FilterSink$d = private unnamed_addr constant { i64, i64 } { i64 845, i64 0 }
define ptr @df.mt.dart$3aio._FilterSink() {
b0:
  ret ptr @df.mt.dart$3aio._FilterSink$d
}
@df.mt.dart$3aio._Directory$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 834, i64 11, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -9073847788167069060, ptr @df.dart$3aio.FileSystemEntity.parent$g, i64 -5831654267004812466, ptr @df.dart$3aio._Directory.uri$g, i64 -3445551396850951156, ptr @df.dart$3aio._Directory.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -946583804159754013, ptr @df.dart$3aio._Directory._path$g, i64 2201403351817896611, ptr @df.dart$3aio._Directory.path$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aio._Directory() {
b0:
  ret ptr @df.mt.dart$3aio._Directory$d
}
@df.mt.dart$3aio._AsyncDirectoryLister$d = private unnamed_addr constant { i64, i64 } { i64 828, i64 0 }
define ptr @df.mt.dart$3aio._AsyncDirectoryLister() {
b0:
  ret ptr @df.mt.dart$3aio._AsyncDirectoryLister$d
}
@df.mt.dart$3aio._EventHandler$d = private unnamed_addr constant { i64, i64 } { i64 836, i64 0 }
define ptr @df.mt.dart$3aio._EventHandler() {
b0:
  ret ptr @df.mt.dart$3aio._EventHandler$d
}
@df.mt.dart$3aio.FileMode$d = private unnamed_addr constant { i64, i64 } { i64 760, i64 0 }
define ptr @df.mt.dart$3aio.FileMode() {
b0:
  ret ptr @df.mt.dart$3aio.FileMode$d
}
@df.mt.dart$3aio.FileLock$d = private unnamed_addr constant { i64, i64 } { i64 759, i64 0 }
define ptr @df.mt.dart$3aio.FileLock() {
b0:
  ret ptr @df.mt.dart$3aio.FileLock$d
}
@df.mt.dart$3aio.FileSystemException$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 767, i64 10, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8460972710066630285, ptr @df.dart$3aio.FileSystemException.message$g, i64 -3960934359536485088, ptr @df.dart$3aio.FileSystemException.osError$g, i64 -3445551396850951156, ptr @df.dart$3aio.FileSystemException.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 2201403351817896611, ptr @df.dart$3aio.FileSystemException.path$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aio.FileSystemException() {
b0:
  ret ptr @df.mt.dart$3aio.FileSystemException$d
}
@df.mt.dart$3aio.PathAccessException$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 780, i64 10, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8460972710066630285, ptr @df.dart$3aio.FileSystemException.message$g, i64 -3960934359536485088, ptr @df.dart$3aio.FileSystemException.osError$g, i64 -3445551396850951156, ptr @df.dart$3aio.PathAccessException.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 2201403351817896611, ptr @df.dart$3aio.FileSystemException.path$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aio.PathAccessException() {
b0:
  ret ptr @df.mt.dart$3aio.PathAccessException$d
}
@df.mt.dart$3aio.PathExistsException$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 781, i64 10, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8460972710066630285, ptr @df.dart$3aio.FileSystemException.message$g, i64 -3960934359536485088, ptr @df.dart$3aio.FileSystemException.osError$g, i64 -3445551396850951156, ptr @df.dart$3aio.PathExistsException.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 2201403351817896611, ptr @df.dart$3aio.FileSystemException.path$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aio.PathExistsException() {
b0:
  ret ptr @df.mt.dart$3aio.PathExistsException$d
}
@df.mt.dart$3aio.PathNotFoundException$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 782, i64 10, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8460972710066630285, ptr @df.dart$3aio.FileSystemException.message$g, i64 -3960934359536485088, ptr @df.dart$3aio.FileSystemException.osError$g, i64 -3445551396850951156, ptr @df.dart$3aio.PathNotFoundException.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 2201403351817896611, ptr @df.dart$3aio.FileSystemException.path$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aio.PathNotFoundException() {
b0:
  ret ptr @df.mt.dart$3aio.PathNotFoundException$d
}
@df.mt.dart$3aio._FileStream$d = private unnamed_addr constant { i64, i64 } { i64 841, i64 0 }
define ptr @df.mt.dart$3aio._FileStream() {
b0:
  ret ptr @df.mt.dart$3aio._FileStream$d
}
@df.mt.dart$3aio._FileStreamConsumer$d = private unnamed_addr constant { i64, i64 } { i64 842, i64 0 }
define ptr @df.mt.dart$3aio._FileStreamConsumer() {
b0:
  ret ptr @df.mt.dart$3aio._FileStreamConsumer$d
}
@df.mt.dart$3aio._File$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 839, i64 12, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -9073847788167069060, ptr @df.dart$3aio.FileSystemEntity.parent$g, i64 -6565620648322651272, ptr @df.dart$3aio._File.length$g, i64 -5831654267004812466, ptr @df.dart$3aio.FileSystemEntity.uri$g, i64 -3445551396850951156, ptr @df.dart$3aio._File.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -946583804159754013, ptr @df.dart$3aio._File._path$g, i64 2201403351817896611, ptr @df.dart$3aio._File.path$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aio._File() {
b0:
  ret ptr @df.mt.dart$3aio._File$d
}
@df.mt.dart$3aio._RandomAccessFile$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 870, i64 11, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8067501549842329812, ptr @df.dart$3aio._RandomAccessFile.close$c, i64 -6565620648322651272, ptr @df.dart$3aio._RandomAccessFile.length$g, i64 -4318155389668546510, ptr @df.dart$3aio._RandomAccessFile.truncate$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 2201403351817896611, ptr @df.dart$3aio._RandomAccessFile.path$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aio._RandomAccessFile() {
b0:
  ret ptr @df.mt.dart$3aio._RandomAccessFile$d
}
@df.mt.dart$3aio._ReadPipe$d = private unnamed_addr constant { i64, i64 } { i64 880, i64 0 }
define ptr @df.mt.dart$3aio._ReadPipe() {
b0:
  ret ptr @df.mt.dart$3aio._ReadPipe$d
}
@df.mt.dart$3aio._WritePipe$d = private unnamed_addr constant { i64, i64 } { i64 908, i64 0 }
define ptr @df.mt.dart$3aio._WritePipe() {
b0:
  ret ptr @df.mt.dart$3aio._WritePipe$d
}
@df.mt.dart$3aio._Pipe$d = private unnamed_addr constant { i64, i64 } { i64 863, i64 0 }
define ptr @df.mt.dart$3aio._Pipe() {
b0:
  ret ptr @df.mt.dart$3aio._Pipe$d
}
@df.mt.dart$3aio.FileSystemEntityType$d = private unnamed_addr constant { i64, i64 } { i64 765, i64 0 }
define ptr @df.mt.dart$3aio.FileSystemEntityType() {
b0:
  ret ptr @df.mt.dart$3aio.FileSystemEntityType$d
}
@df.mt.dart$3aio.FileStat$d = private unnamed_addr constant { i64, i64 } { i64 761, i64 0 }
define ptr @df.mt.dart$3aio.FileStat() {
b0:
  ret ptr @df.mt.dart$3aio.FileStat$d
}
@df.mt.dart$3aio.FileSystemEvent$d = private unnamed_addr constant { i64, i64 } { i64 766, i64 0 }
define ptr @df.mt.dart$3aio.FileSystemEvent() {
b0:
  ret ptr @df.mt.dart$3aio.FileSystemEvent$d
}
@df.mt.dart$3aio.FileSystemCreateEvent$d = private unnamed_addr constant { i64, i64 } { i64 762, i64 0 }
define ptr @df.mt.dart$3aio.FileSystemCreateEvent() {
b0:
  ret ptr @df.mt.dart$3aio.FileSystemCreateEvent$d
}
@df.mt.dart$3aio.FileSystemModifyEvent$d = private unnamed_addr constant { i64, i64 } { i64 768, i64 0 }
define ptr @df.mt.dart$3aio.FileSystemModifyEvent() {
b0:
  ret ptr @df.mt.dart$3aio.FileSystemModifyEvent$d
}
@df.mt.dart$3aio.FileSystemDeleteEvent$d = private unnamed_addr constant { i64, i64 } { i64 763, i64 0 }
define ptr @df.mt.dart$3aio.FileSystemDeleteEvent() {
b0:
  ret ptr @df.mt.dart$3aio.FileSystemDeleteEvent$d
}
@df.mt.dart$3aio.FileSystemMoveEvent$d = private unnamed_addr constant { i64, i64 } { i64 769, i64 0 }
define ptr @df.mt.dart$3aio.FileSystemMoveEvent() {
b0:
  ret ptr @df.mt.dart$3aio.FileSystemMoveEvent$d
}
@df.mt.dart$3aio._FileResourceInfo$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 840, i64 8, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 494151758419248719, ptr @df.dart$3aio._FileResourceInfo.name$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aio._FileResourceInfo() {
b0:
  ret ptr @df.mt.dart$3aio._FileResourceInfo$d
}
@df.mt.dart$3aio._SpawnedProcessResourceInfo$d = private unnamed_addr constant { i64, i64 } { i64 896, i64 0 }
define ptr @df.mt.dart$3aio._SpawnedProcessResourceInfo() {
b0:
  ret ptr @df.mt.dart$3aio._SpawnedProcessResourceInfo$d
}
@df.mt.dart$3aio._StreamSinkImpl$d = private unnamed_addr constant { i64, i64 } { i64 901, i64 0 }
define ptr @df.mt.dart$3aio._StreamSinkImpl() {
b0:
  ret ptr @df.mt.dart$3aio._StreamSinkImpl$d
}
@df.mt.dart$3aio._IOSinkImpl$d = private unnamed_addr constant { i64, i64 } { i64 851, i64 0 }
define ptr @df.mt.dart$3aio._IOSinkImpl() {
b0:
  ret ptr @df.mt.dart$3aio._IOSinkImpl$d
}
@df.mt.dart$3aio._IOService$d = private unnamed_addr constant { i64, i64 } { i64 850, i64 0 }
define ptr @df.mt.dart$3aio._IOService() {
b0:
  ret ptr @df.mt.dart$3aio._IOService$d
}
@df.mt.dart$3aio._Link$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 854, i64 11, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -9073847788167069060, ptr @df.dart$3aio.FileSystemEntity.parent$g, i64 -5831654267004812466, ptr @df.dart$3aio.FileSystemEntity.uri$g, i64 -3445551396850951156, ptr @df.dart$3aio._Link.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 -946583804159754013, ptr @df.dart$3aio._Link._path$g, i64 2201403351817896611, ptr @df.dart$3aio._Link.path$g, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aio._Link() {
b0:
  ret ptr @df.mt.dart$3aio._Link$d
}
@df.mt.dart$3aio._SocketProfileType$d = private unnamed_addr constant { i64, i64 } { i64 893, i64 0 }
define ptr @df.mt.dart$3aio._SocketProfileType() {
b0:
  ret ptr @df.mt.dart$3aio._SocketProfileType$d
}
@df.mt.dart$3aio._SocketStatistic$d = private unnamed_addr constant { i64, i64 } { i64 894, i64 0 }
define ptr @df.mt.dart$3aio._SocketStatistic() {
b0:
  ret ptr @df.mt.dart$3aio._SocketStatistic$d
}
@df.mt.dart$3aio._IOOverridesScope$d = private unnamed_addr constant { i64, i64 } { i64 848, i64 0 }
define ptr @df.mt.dart$3aio._IOOverridesScope() {
b0:
  ret ptr @df.mt.dart$3aio._IOOverridesScope$d
}
@df.mt.dart$3aio._Platform$d = private unnamed_addr constant { i64, i64 } { i64 864, i64 0 }
define ptr @df.mt.dart$3aio._Platform() {
b0:
  ret ptr @df.mt.dart$3aio._Platform$d
}
@df.mt.dart$3aio._CaseInsensitiveStringMap$d = private unnamed_addr constant { i64, i64 } { i64 833, i64 0 }
define ptr @df.mt.dart$3aio._CaseInsensitiveStringMap() {
b0:
  ret ptr @df.mt.dart$3aio._CaseInsensitiveStringMap$d
}
@df.mt.dart$3aio._ProcessUtils$d = private unnamed_addr constant { i64, i64 } { i64 869, i64 0 }
define ptr @df.mt.dart$3aio._ProcessUtils() {
b0:
  ret ptr @df.mt.dart$3aio._ProcessUtils$d
}
@df.mt.dart$3aio.ProcessStartMode$d = private unnamed_addr constant { i64, i64 } { i64 790, i64 0 }
define ptr @df.mt.dart$3aio.ProcessStartMode() {
b0:
  ret ptr @df.mt.dart$3aio.ProcessStartMode$d
}
@df.mt.dart$3aio.ProcessResult$d = private unnamed_addr constant { i64, i64 } { i64 788, i64 0 }
define ptr @df.mt.dart$3aio.ProcessResult() {
b0:
  ret ptr @df.mt.dart$3aio.ProcessResult$d
}
@df.mt.dart$3aio.ProcessSignal$d = private unnamed_addr constant { i64, i64 } { i64 789, i64 0 }
define ptr @df.mt.dart$3aio.ProcessSignal() {
b0:
  ret ptr @df.mt.dart$3aio.ProcessSignal$d
}
@df.mt.dart$3aio.SignalException$d = private unnamed_addr constant { i64, i64 } { i64 807, i64 0 }
define ptr @df.mt.dart$3aio.SignalException() {
b0:
  ret ptr @df.mt.dart$3aio.SignalException$d
}
@df.mt.dart$3aio.ProcessException$d = private unnamed_addr constant { i64, i64 } { i64 786, i64 0 }
define ptr @df.mt.dart$3aio.ProcessException() {
b0:
  ret ptr @df.mt.dart$3aio.ProcessException$d
}
@df.mt.dart$3aio.SecureServerSocket$d = private unnamed_addr constant { i64, i64 } { i64 803, i64 0 }
define ptr @df.mt.dart$3aio.SecureServerSocket() {
b0:
  ret ptr @df.mt.dart$3aio.SecureServerSocket$d
}
@df.mt.dart$3aio.RawSecureServerSocket$d = private unnamed_addr constant { i64, i64 } { i64 793, i64 0 }
define ptr @df.mt.dart$3aio.RawSecureServerSocket() {
b0:
  ret ptr @df.mt.dart$3aio.RawSecureServerSocket$d
}
@df.mt.dart$3aio._FilterStatus$d = private unnamed_addr constant { i64, i64 } { i64 846, i64 0 }
define ptr @df.mt.dart$3aio._FilterStatus() {
b0:
  ret ptr @df.mt.dart$3aio._FilterStatus$d
}
@df.mt.dart$3aio._RawSecureSocket$d = private unnamed_addr constant { i64, i64 } { i64 874, i64 0 }
define ptr @df.mt.dart$3aio._RawSecureSocket() {
b0:
  ret ptr @df.mt.dart$3aio._RawSecureSocket$d
}
@df.mt.dart$3aio._ExternalBuffer$d = private unnamed_addr constant { i64, i64 } { i64 837, i64 0 }
define ptr @df.mt.dart$3aio._ExternalBuffer() {
b0:
  ret ptr @df.mt.dart$3aio._ExternalBuffer$d
}
@df.mt.dart$3aio.TlsException$d = private unnamed_addr constant { i64, i64 } { i64 820, i64 0 }
define ptr @df.mt.dart$3aio.TlsException() {
b0:
  ret ptr @df.mt.dart$3aio.TlsException$d
}
@df.mt.dart$3aio.HandshakeException$d = private unnamed_addr constant { i64, i64 } { i64 771, i64 0 }
define ptr @df.mt.dart$3aio.HandshakeException() {
b0:
  ret ptr @df.mt.dart$3aio.HandshakeException$d
}
@df.mt.dart$3aio.CertificateException$d = private unnamed_addr constant { i64, i64 } { i64 754, i64 0 }
define ptr @df.mt.dart$3aio.CertificateException() {
b0:
  ret ptr @df.mt.dart$3aio.CertificateException$d
}
@df.mt.dart$3aio.TlsProtocolVersion$d = private unnamed_addr constant { i64, i64 } { i64 821, i64 0 }
define ptr @df.mt.dart$3aio.TlsProtocolVersion() {
b0:
  ret ptr @df.mt.dart$3aio.TlsProtocolVersion$d
}
@df.mt.dart$3aio.InternetAddressType$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 776, i64 7, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3aio.InternetAddressType.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aio.InternetAddressType() {
b0:
  ret ptr @df.mt.dart$3aio.InternetAddressType$d
}
@df.mt.dart$3aio.SocketDirection$d = private unnamed_addr constant { i64, i64 } { i64 810, i64 0 }
define ptr @df.mt.dart$3aio.SocketDirection() {
b0:
  ret ptr @df.mt.dart$3aio.SocketDirection$d
}
@df.mt.dart$3aio.SocketOption$d = private unnamed_addr constant { i64, i64 } { i64 813, i64 0 }
define ptr @df.mt.dart$3aio.SocketOption() {
b0:
  ret ptr @df.mt.dart$3aio.SocketOption$d
}
@df.mt.dart$3aio._RawSocketOptions$d = private unnamed_addr constant { i64, i64 } { i64 878, i64 0 }
define ptr @df.mt.dart$3aio._RawSocketOptions() {
b0:
  ret ptr @df.mt.dart$3aio._RawSocketOptions$d
}
@df.mt.dart$3aio.RawSocketOption$d = private unnamed_addr constant { i64, i64 } { i64 798, i64 0 }
define ptr @df.mt.dart$3aio.RawSocketOption() {
b0:
  ret ptr @df.mt.dart$3aio.RawSocketOption$d
}
@df.mt.dart$3aio.RawSocketEvent$d = private unnamed_addr constant { i64, i64 } { i64 797, i64 0 }
define ptr @df.mt.dart$3aio.RawSocketEvent() {
b0:
  ret ptr @df.mt.dart$3aio.RawSocketEvent$d
}
@df.mt.dart$3aio.ConnectionTask$d = private unnamed_addr constant { i64, i64 } { i64 755, i64 0 }
define ptr @df.mt.dart$3aio.ConnectionTask() {
b0:
  ret ptr @df.mt.dart$3aio.ConnectionTask$d
}
@df.mt.dart$3aio.Datagram$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 756, i64 8, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -4034584598075232417, ptr @df.dart$3aio.Datagram.port$g, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aio.Datagram() {
b0:
  ret ptr @df.mt.dart$3aio.Datagram$d
}
@df.mt.dart$3aio.SocketMessage$d = private unnamed_addr constant { i64, i64 } { i64 812, i64 0 }
define ptr @df.mt.dart$3aio.SocketMessage() {
b0:
  ret ptr @df.mt.dart$3aio.SocketMessage$d
}
@df.mt.dart$3aio.SocketException$d = private unnamed_addr constant { i64, i64 } { i64 811, i64 0 }
define ptr @df.mt.dart$3aio.SocketException() {
b0:
  ret ptr @df.mt.dart$3aio.SocketException$d
}
@df.mt.dart$3aio._StdStream$d = private unnamed_addr constant { i64, i64 } { i64 900, i64 0 }
define ptr @df.mt.dart$3aio._StdStream() {
b0:
  ret ptr @df.mt.dart$3aio._StdStream$d
}
@df.mt.dart$3aio.Stdin$d = private unnamed_addr constant { i64, i64 } { i64 814, i64 0 }
define ptr @df.mt.dart$3aio.Stdin() {
b0:
  ret ptr @df.mt.dart$3aio.Stdin$d
}
@df.mt.dart$3aio.Stdout$d = private unnamed_addr constant { i64, i64 } { i64 817, i64 0 }
define ptr @df.mt.dart$3aio.Stdout() {
b0:
  ret ptr @df.mt.dart$3aio.Stdout$d
}
@df.mt.dart$3aio.StdoutException$d = private unnamed_addr constant { i64, i64 } { i64 818, i64 0 }
define ptr @df.mt.dart$3aio.StdoutException() {
b0:
  ret ptr @df.mt.dart$3aio.StdoutException$d
}
@df.mt.dart$3aio.StdinException$d = private unnamed_addr constant { i64, i64 } { i64 815, i64 0 }
define ptr @df.mt.dart$3aio.StdinException() {
b0:
  ret ptr @df.mt.dart$3aio.StdinException$d
}
@df.mt.dart$3aio._StdConsumer$d = private unnamed_addr constant { i64, i64 } { i64 897, i64 0 }
define ptr @df.mt.dart$3aio._StdConsumer() {
b0:
  ret ptr @df.mt.dart$3aio._StdConsumer$d
}
@df.mt.dart$3aio._StdSink$d = private unnamed_addr constant { i64, i64 } { i64 899, i64 0 }
define ptr @df.mt.dart$3aio._StdSink() {
b0:
  ret ptr @df.mt.dart$3aio._StdSink$d
}
@df.mt.dart$3aio.StdioType$d = private unnamed_addr constant { i64, i64 } { i64 816, i64 0 }
define ptr @df.mt.dart$3aio.StdioType() {
b0:
  ret ptr @df.mt.dart$3aio.StdioType$d
}
@df.mt.dart$3aio._StdIOUtils$d = private unnamed_addr constant { i64, i64 } { i64 898, i64 0 }
define ptr @df.mt.dart$3aio._StdIOUtils() {
b0:
  ret ptr @df.mt.dart$3aio._StdIOUtils$d
}
@df.mt.dart$3aio.SystemEncoding$d = private unnamed_addr constant { i64, i64 } { i64 819, i64 0 }
define ptr @df.mt.dart$3aio.SystemEncoding() {
b0:
  ret ptr @df.mt.dart$3aio.SystemEncoding$d
}
@df.mt.dart$3aio._WindowsCodePageEncoder$d = private unnamed_addr constant { i64, i64 } { i64 906, i64 0 }
define ptr @df.mt.dart$3aio._WindowsCodePageEncoder() {
b0:
  ret ptr @df.mt.dart$3aio._WindowsCodePageEncoder$d
}
@df.mt.dart$3aio._WindowsCodePageEncoderSink$d = private unnamed_addr constant { i64, i64 } { i64 907, i64 0 }
define ptr @df.mt.dart$3aio._WindowsCodePageEncoderSink() {
b0:
  ret ptr @df.mt.dart$3aio._WindowsCodePageEncoderSink$d
}
@df.mt.dart$3aio._WindowsCodePageDecoder$d = private unnamed_addr constant { i64, i64 } { i64 904, i64 0 }
define ptr @df.mt.dart$3aio._WindowsCodePageDecoder() {
b0:
  ret ptr @df.mt.dart$3aio._WindowsCodePageDecoder$d
}
@df.mt.dart$3aio._WindowsCodePageDecoderSink$d = private unnamed_addr constant { i64, i64 } { i64 905, i64 0 }
define ptr @df.mt.dart$3aio._WindowsCodePageDecoderSink() {
b0:
  ret ptr @df.mt.dart$3aio._WindowsCodePageDecoderSink$d
}
@df.mt.dart$3aio._AsyncDirectoryListerOpsImpl$d = private unnamed_addr constant { i64, i64 } { i64 830, i64 0 }
define ptr @df.mt.dart$3aio._AsyncDirectoryListerOpsImpl() {
b0:
  ret ptr @df.mt.dart$3aio._AsyncDirectoryListerOpsImpl$d
}
@df.mt.dart$3aio._RandomAccessFileOpsImpl$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 872, i64 10, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -8067501549842329812, ptr @df.dart$3aio._RandomAccessFileOpsImpl.close$c, i64 -6565620648322651272, ptr @df.dart$3aio._RandomAccessFileOpsImpl.length$g, i64 -4318155389668546510, ptr @df.dart$3aio._RandomAccessFileOpsImpl.truncate$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aio._RandomAccessFileOpsImpl() {
b0:
  ret ptr @df.mt.dart$3aio._RandomAccessFileOpsImpl$d
}
@df.mt.dart$3aio._WatcherPath$d = private unnamed_addr constant { i64, i64 } { i64 902, i64 0 }
define ptr @df.mt.dart$3aio._WatcherPath() {
b0:
  ret ptr @df.mt.dart$3aio._WatcherPath$d
}
@df.mt.dart$3aio._InotifyFileSystemWatcher$d = private unnamed_addr constant { i64, i64 } { i64 852, i64 0 }
define ptr @df.mt.dart$3aio._InotifyFileSystemWatcher() {
b0:
  ret ptr @df.mt.dart$3aio._InotifyFileSystemWatcher$d
}
@df.mt.dart$3aio._Win32FileSystemWatcher$d = private unnamed_addr constant { i64, i64 } { i64 903, i64 0 }
define ptr @df.mt.dart$3aio._Win32FileSystemWatcher() {
b0:
  ret ptr @df.mt.dart$3aio._Win32FileSystemWatcher$d
}
@df.mt.dart$3aio._FSEventStreamFileSystemWatcher$d = private unnamed_addr constant { i64, i64 } { i64 838, i64 0 }
define ptr @df.mt.dart$3aio._FSEventStreamFileSystemWatcher() {
b0:
  ret ptr @df.mt.dart$3aio._FSEventStreamFileSystemWatcher$d
}
@df.mt.dart$3aio._FilterImpl$d = private unnamed_addr constant { i64, i64 } { i64 844, i64 0 }
define ptr @df.mt.dart$3aio._FilterImpl() {
b0:
  ret ptr @df.mt.dart$3aio._FilterImpl$d
}
@df.mt.dart$3aio._ZLibInflateFilter$d = private unnamed_addr constant { i64, i64 } { i64 913, i64 0 }
define ptr @df.mt.dart$3aio._ZLibInflateFilter() {
b0:
  ret ptr @df.mt.dart$3aio._ZLibInflateFilter$d
}
@df.mt.dart$3aio._ZLibDeflateFilter$d = private unnamed_addr constant { i64, i64 } { i64 911, i64 0 }
define ptr @df.mt.dart$3aio._ZLibDeflateFilter() {
b0:
  ret ptr @df.mt.dart$3aio._ZLibDeflateFilter$d
}
@df.mt.dart$3aio._NamespaceImpl$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 856, i64 7, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aio._NamespaceImpl() {
b0:
  ret ptr @df.mt.dart$3aio._NamespaceImpl$d
}
@df.mt.dart$3aio._SignalController$d = private unnamed_addr constant { i64, i64 } { i64 889, i64 0 }
define ptr @df.mt.dart$3aio._SignalController() {
b0:
  ret ptr @df.mt.dart$3aio._SignalController$d
}
@df.mt.dart$3aio._ProcessStartStatus$d = private unnamed_addr constant { i64, i64 } { i64 868, i64 0 }
define ptr @df.mt.dart$3aio._ProcessStartStatus() {
b0:
  ret ptr @df.mt.dart$3aio._ProcessStartStatus$d
}
@df.mt.dart$3aio._ProcessImplNativeWrapper$d = private unnamed_addr constant { i64, i64 } { i64 867, i64 0 }
define ptr @df.mt.dart$3aio._ProcessImplNativeWrapper() {
b0:
  ret ptr @df.mt.dart$3aio._ProcessImplNativeWrapper$d
}
@df.mt.dart$3aio._ProcessImpl$d = private unnamed_addr constant { i64, i64 } { i64 866, i64 0 }
define ptr @df.mt.dart$3aio._ProcessImpl() {
b0:
  ret ptr @df.mt.dart$3aio._ProcessImpl$d
}
@df.mt.dart$3aio._InternetAddress$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 853, i64 8, i64 -9163797671095228218, ptr @df.dart$3aio._InternetAddress.$3d$3d$c, i64 -6456075568128440506, ptr @df.dart$3aio._InternetAddress.host$g, i64 -3445551396850951156, ptr @df.dart$3aio._InternetAddress.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3aio._InternetAddress.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aio._InternetAddress() {
b0:
  ret ptr @df.mt.dart$3aio._InternetAddress$d
}
@df.mt.dart$3aio._NetworkInterface$d = private unnamed_addr constant { i64, i64 } { i64 861, i64 0 }
define ptr @df.mt.dart$3aio._NetworkInterface() {
b0:
  ret ptr @df.mt.dart$3aio._NetworkInterface$d
}
@df.mt.dart$3aio._NativeSocketNativeWrapper$d = private unnamed_addr constant { i64, i64 } { i64 858, i64 0 }
define ptr @df.mt.dart$3aio._NativeSocketNativeWrapper() {
b0:
  ret ptr @df.mt.dart$3aio._NativeSocketNativeWrapper$d
}
@df.mt.dart$3aio._NativeSocket$d = private unnamed_addr constant { i64, i64 } { i64 857, i64 0 }
define ptr @df.mt.dart$3aio._NativeSocket() {
b0:
  ret ptr @df.mt.dart$3aio._NativeSocket$d
}
@df.mt.dart$3aio._RawServerSocket$d = private unnamed_addr constant { i64, i64 } { i64 875, i64 0 }
define ptr @df.mt.dart$3aio._RawServerSocket() {
b0:
  ret ptr @df.mt.dart$3aio._RawServerSocket$d
}
@df.mt.dart$3aio._RawSocket$d = private unnamed_addr constant { i64, i64 } { i64 876, i64 0 }
define ptr @df.mt.dart$3aio._RawSocket() {
b0:
  ret ptr @df.mt.dart$3aio._RawSocket$d
}
@df.mt.dart$3aio._ServerSocket$d = private unnamed_addr constant { i64, i64 } { i64 887, i64 0 }
define ptr @df.mt.dart$3aio._ServerSocket() {
b0:
  ret ptr @df.mt.dart$3aio._ServerSocket$d
}
@df.mt.dart$3aio._SocketStreamConsumer$d = private unnamed_addr constant { i64, i64 } { i64 895, i64 0 }
define ptr @df.mt.dart$3aio._SocketStreamConsumer() {
b0:
  ret ptr @df.mt.dart$3aio._SocketStreamConsumer$d
}
@df.mt.dart$3aio._Socket$d = private unnamed_addr constant { i64, i64 } { i64 890, i64 0 }
define ptr @df.mt.dart$3aio._Socket() {
b0:
  ret ptr @df.mt.dart$3aio._Socket$d
}
@df.mt.dart$3aio._RawDatagramSocket$d = private unnamed_addr constant { i64, i64 } { i64 873, i64 0 }
define ptr @df.mt.dart$3aio._RawDatagramSocket() {
b0:
  ret ptr @df.mt.dart$3aio._RawDatagramSocket$d
}
@df.mt.dart$3aio._ResourceHandleImpl$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 882, i64 7, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aio._ResourceHandleImpl() {
b0:
  ret ptr @df.mt.dart$3aio._ResourceHandleImpl$d
}
@df.mt.dart$3aio._SocketControlMessageImpl$d = private unnamed_addr constant { i64, i64, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr } { i64 891, i64 7, i64 -9163797671095228218, ptr @df.dart$3acore.Object.$3d$3d$c, i64 -3445551396850951156, ptr @df.dart$3acore.Object.toString$c, i64 -1301464018035317077, ptr @df.dart$3acore.Object.noSuchMethod$tc, i64 3599887816169301665, ptr @df.dart$3acore.Object.noSuchMethod$c, i64 4031450617872922849, ptr @df.dart$3acore.Object.hashCode$g, i64 5306504273795186908, ptr @df.dart$3acore.Object._identityHashCode$g, i64 7093520068988870176, ptr @df.dart$3acore.Object.runtimeType$g }
define ptr @df.mt.dart$3aio._SocketControlMessageImpl() {
b0:
  ret ptr @df.mt.dart$3aio._SocketControlMessageImpl$d
}
@df.mt.dart$3aio._SecureSocket$d = private unnamed_addr constant { i64, i64 } { i64 885, i64 0 }
define ptr @df.mt.dart$3aio._SecureSocket() {
b0:
  ret ptr @df.mt.dart$3aio._SecureSocket$d
}
@df.mt.dart$3aio._SecureFilterImpl$d = private unnamed_addr constant { i64, i64 } { i64 884, i64 0 }
define ptr @df.mt.dart$3aio._SecureFilterImpl() {
b0:
  ret ptr @df.mt.dart$3aio._SecureFilterImpl$d
}
@df.mt.dart$3aio._SecurityContext$d = private unnamed_addr constant { i64, i64 } { i64 886, i64 0 }
define ptr @df.mt.dart$3aio._SecurityContext() {
b0:
  ret ptr @df.mt.dart$3aio._SecurityContext$d
}
@df.mt.dart$3aio._X509CertificateImpl$d = private unnamed_addr constant { i64, i64 } { i64 909, i64 0 }
define ptr @df.mt.dart$3aio._X509CertificateImpl() {
b0:
  ret ptr @df.mt.dart$3aio._X509CertificateImpl$d
}
@df.mt.dart$3aio._RawSynchronousSocket$d = private unnamed_addr constant { i64, i64 } { i64 879, i64 0 }
define ptr @df.mt.dart$3aio._RawSynchronousSocket() {
b0:
  ret ptr @df.mt.dart$3aio._RawSynchronousSocket$d
}
@df.mt.dart$3aio._NativeSynchronousSocketNativeWrapper$d = private unnamed_addr constant { i64, i64 } { i64 860, i64 0 }
define ptr @df.mt.dart$3aio._NativeSynchronousSocketNativeWrapper() {
b0:
  ret ptr @df.mt.dart$3aio._NativeSynchronousSocketNativeWrapper$d
}
@df.mt.dart$3aio._NativeSynchronousSocket$d = private unnamed_addr constant { i64, i64 } { i64 859, i64 0 }
define ptr @df.mt.dart$3aio._NativeSynchronousSocket() {
b0:
  ret ptr @df.mt.dart$3aio._NativeSynchronousSocket$d
}
@df.mt.dart$3amirrors.AbstractClassInstantiationError$d = private unnamed_addr constant { i64, i64 } { i64 933, i64 0 }
define ptr @df.mt.dart$3amirrors.AbstractClassInstantiationError() {
b0:
  ret ptr @df.mt.dart$3amirrors.AbstractClassInstantiationError$d
}
@df.mt.dart$3amirrors._LibraryMirrorDf$d = private unnamed_addr constant { i64, i64 } { i64 955, i64 0 }
define ptr @df.mt.dart$3amirrors._LibraryMirrorDf() {
b0:
  ret ptr @df.mt.dart$3amirrors._LibraryMirrorDf$d
}
@df.mt.dart$3amirrors._ClassMirrorDf$d = private unnamed_addr constant { i64, i64 } { i64 953, i64 0 }
define ptr @df.mt.dart$3amirrors._ClassMirrorDf() {
b0:
  ret ptr @df.mt.dart$3amirrors._ClassMirrorDf$d
}
@df.mt.dart$3amirrors._InstanceMirrorDf$d = private unnamed_addr constant { i64, i64 } { i64 954, i64 0 }
define ptr @df.mt.dart$3amirrors._InstanceMirrorDf() {
b0:
  ret ptr @df.mt.dart$3amirrors._InstanceMirrorDf$d
}
declare i64 @df.dart$3acore.Error.stackTrace$g(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.NotNullableError.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.Error._stackTrace$g(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.TypeTest.test$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.LateError.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.ListIterable.last$g(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.SubListIterable.toList$tc(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.SubListIterable.skip$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.SubListIterable.length$g(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.SubListIterable.take$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.ListIterable.iterator$g(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.ListIterable.join$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore.Iterable.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.ListIterable.isEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.SubListIterable.elementAt$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.SubListIterable.skip$tc(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.SubListIterable.elementAt$tc(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.SubListIterable.take$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore.Iterable.isNotEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.SubListIterable.toList$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.ListIterable.map$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.ListIterable.forEach$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.ListIterable.contains$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.ListIterable.join$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.ListIterator.moveNext$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.ListIterator.current$g(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.MappedIterable.last$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.Iterable.toList$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore.Iterable.skip$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.MappedIterable.length$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.Iterable.take$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.MappedIterable.iterator$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.Iterable.join$tc(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.MappedIterable.isEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.MappedIterable.elementAt$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.Iterable.skip$tc(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.MappedIterable.elementAt$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore.Iterable.take$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore.Iterable.toList$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.Iterable.map$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.Iterable.forEach$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.Iterable.contains$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.Iterable.join$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.MappedIterator.moveNext$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.MappedIterator.current$g(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.ListIterable.toList$tc(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.ListIterable.skip$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.MappedListIterable.length$g(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.ListIterable.take$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.MappedListIterable.elementAt$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.ListIterable.skip$tc(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.MappedListIterable.elementAt$tc(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.ListIterable.take$tc(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.ListIterable.toList$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.Iterable.last$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.Iterable.length$g(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.TakeIterable.iterator$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.Iterable.isEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.Iterable.elementAt$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.Iterable.elementAt$tc(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.EfficientLengthTakeIterable.length$g(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.TakeIterator.moveNext$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.TakeIterator.current$g(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.SkipIterable.skip$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.SkipIterable.iterator$g(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.SkipIterable.skip$tc(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.EfficientLengthSkipIterable.skip$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.EfficientLengthSkipIterable.length$g(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.EfficientLengthSkipIterable.skip$tc(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.SkipIterator.moveNext$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.SkipIterator.current$g(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.EmptyIterable.last$g(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.EmptyIterable.toList$tc(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.EmptyIterable.skip$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.EmptyIterable.length$g(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.EmptyIterable.take$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.EmptyIterable.iterator$g(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.EmptyIterable.join$tc(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.EmptyIterable.isEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.EmptyIterable.elementAt$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.EmptyIterable.skip$tc(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.EmptyIterable.elementAt$tc(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.EmptyIterable.take$tc(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.EmptyIterable.toList$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.EmptyIterable.map$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.EmptyIterable.forEach$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.EmptyIterable.contains$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.EmptyIterable.join$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.EmptyIterator.moveNext$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.EmptyIterator.current$g(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.Symbol.$3d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.Symbol.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.Symbol.hashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.bool.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.bool.hashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.bool._identityHashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.Duration.$3d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.Duration.inMilliseconds$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.Duration.inMicroseconds$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.Duration.isNegative$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.Duration.$2d$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore.Duration.$2a$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore.Duration.$2b$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore.Duration.$3e$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore.Duration.$3c$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore.Duration.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.Duration.$3c$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.Duration.$3e$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.Duration.$2a$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.Duration.$2b$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.Duration.$2d$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.Duration.$7e$2f$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore.Duration.hashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.Duration.$7e$2f$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.AssertionError.message$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.AssertionError.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.ArgumentError.message$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.ArgumentError._errorExplanation$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.ArgumentError.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.ArgumentError._errorName$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.ArgumentError.invalidValue$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.ArgumentError.name$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.RangeError._errorExplanation$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.RangeError._errorName$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.RangeError.invalidValue$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.RangeError.start$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.RangeError.end$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.IndexError.length$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.IndexError._errorExplanation$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.IndexError._errorName$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.IndexError.invalidValue$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.IndexError.start$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.IndexError.end$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.NoSuchMethodError._receiver$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.NoSuchMethodError.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.NoSuchMethodError._invocation$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.UnsupportedError.message$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.UnsupportedError.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.StateError.message$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.StateError.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.ConcurrentModificationError.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.ConcurrentModificationError.modifiedObject$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.StackOverflowError.stackTrace$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.StackOverflowError.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.StackOverflowError._stackTrace$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.FormatException.source$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.FormatException.message$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.FormatException.offset$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.FormatException.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.IntegerDivisionByZeroException.message$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.IntegerDivisionByZeroException.stackTrace$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.IntegerDivisionByZeroException.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.IntegerDivisionByZeroException._stackTrace$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Invocation.memberName$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Invocation.typeArguments$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Invocation.positionalArguments$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Invocation.namedArguments$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Invocation.isGetter$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Invocation.isAccessor$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.Null.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.Null.hashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.Null._identityHashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringStackTrace.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.StringBuffer.writeAll$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore.StringBuffer.write$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.StringBuffer.writeCharCode$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.StringBuffer.length$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.StringBuffer.writeCharCode$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore.StringBuffer.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.StringBuffer.isEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.StringBuffer.writeAll$c(i64, ptr, ptr)
declare i64 @df.dart$3acore.StringBuffer.isNotEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Uri.$3d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Uri.isScheme$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Uri.hasFragment$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Uri.replace$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._Uri.resolveUri$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Uri.userInfo$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Uri.host$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Uri.port$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Uri.replace$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Uri.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Uri.hasPort$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Uri.hasEmptyPath$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Uri.scheme$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Uri.hasAuthority$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Uri.hasAbsolutePath$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Uri.path$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Uri.isScheme$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._Uri.hashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Uri.hasQuery$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Uri.query$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Uri.fragment$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Uri.resolveUri$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore.UriData.uri$g(i64, ptr, ptr)
declare i64 @df.dart$3acore.UriData.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._SimpleUri.$3d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._SimpleUri.hasFragment$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._SimpleUri.replace$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._SimpleUri.resolveUri$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._SimpleUri.userInfo$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._SimpleUri.host$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._SimpleUri.port$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._SimpleUri.replace$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._SimpleUri.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._SimpleUri.hasPort$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._SimpleUri.hasEmptyPath$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._SimpleUri.scheme$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._SimpleUri.hasAuthority$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._SimpleUri.hasAbsolutePath$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._SimpleUri.path$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._SimpleUri.hashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._SimpleUri.hasQuery$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._SimpleUri.query$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._SimpleUri.fragment$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._SimpleUri.resolveUri$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._List.$5b$5d$3d$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._Array.last$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Array.toList$tc(i64, ptr, ptr)
declare i64 @df.dart$3acollection.ListBase.skip$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Array.length$g(i64, ptr, ptr)
declare i64 @df.dart$3acollection.ListBase.take$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Array.iterator$g(i64, ptr, ptr)
declare i64 @df.dart$3acollection.ListBase.join$tc(i64, ptr, ptr)
declare i64 @df.dart$3acollection.ListBase.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection.ListBase.isEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3acollection.ListBase.elementAt$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection.ListBase.indexOf$tc(i64, ptr, ptr)
declare i64 @df.dart$3acollection.ListBase.skip$tc(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.FixedLengthListMixin.remove$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.FixedLengthListMixin.removeLast$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection.ListBase.elementAt$tc(i64, ptr, ptr)
declare i64 @df.dart$3acollection.ListBase.$2b$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection.ListBase.fillRange$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection.ListBase.take$tc(i64, ptr, ptr)
declare i64 @df.dart$3acollection.ListBase.isNotEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Array.toList$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection.ListBase.map$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Array.$5b$5d$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._Array.forEach$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.FixedLengthListMixin.add$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection.ListBase.contains$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection.ListBase.join$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection.ListBase.fillRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._List.setRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._List.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._List.setRange$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection.ListBase.indexOf$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Array.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.UnmodifiableListMixin.$5b$5d$3d$tc(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.UnmodifiableListMixin.remove$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.UnmodifiableListMixin.removeLast$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.UnmodifiableListMixin.fillRange$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.UnmodifiableListMixin.add$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.UnmodifiableListMixin.fillRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.UnmodifiableListMixin.setRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.UnmodifiableListMixin.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3a_internal.UnmodifiableListMixin.setRange$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._ArrayIterator.moveNext$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._ArrayIterator.current$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.$3d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double._addFromInteger$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.isNegative$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double._remainderFromInteger$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.isFinite$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double._equalToInteger$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double._greaterThanFromInteger$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.truncate$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.$2f$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.$2d$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.$2a$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.$2b$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.$3e$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.$3c$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double._subFromInteger$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double._equalToInteger$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double._mulFromInteger$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.toDouble$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.round$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double._truncDivFromInteger$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.$3c$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.$3e$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.$2a$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.$2b$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.$2d$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.$2f$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double._truncDivFromInteger$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double._subFromInteger$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.isNaN$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.remainder$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double._remainderFromInteger$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.$7e$2f$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double._greaterThanFromInteger$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.hashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double._identityHashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.toInt$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.remainder$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double._addFromInteger$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double._mulFromInteger$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Double.$7e$2f$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._TypeError.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Closure.$3d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Closure.call$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Closure.hashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._GrowableList.$5b$5d$3d$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._GrowableList.last$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._GrowableList.toList$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._GrowableList.length$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._GrowableList.iterator$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._GrowableList.join$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._GrowableList.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._GrowableList.isEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._GrowableList.elementAt$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._GrowableList.remove$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._GrowableList.removeLast$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._GrowableList.elementAt$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._GrowableList.isNotEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._GrowableList.toList$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._GrowableList.$5b$5d$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._GrowableList.forEach$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._GrowableList.add$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._GrowableList.join$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection.ListBase.setRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._GrowableList.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection.ListBase.setRange$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._GrowableList.addAll$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._GrowableList.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.$3d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.unary$2d$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation._addFromInteger$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.isNegative$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation._remainderFromInteger$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.isFinite$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation._equalToInteger$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation._greaterThanFromInteger$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.truncate$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.$2f$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.$2d$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.$2a$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.$2b$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.$26$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.$3e$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.$3c$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation._subFromInteger$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._Smi.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation._equalToInteger$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation._mulFromInteger$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.toDouble$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.round$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation._truncDivFromInteger$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.$3c$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.$3e$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.$2a$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.$2b$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.$2d$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.$2f$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.$26$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation._truncDivFromInteger$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation._subFromInteger$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.isNaN$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.remainder$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation._remainderFromInteger$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._Smi.bitLength$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.$7e$2f$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation._greaterThanFromInteger$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Smi.hashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Smi._identityHashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.toInt$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.remainder$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation._addFromInteger$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation._mulFromInteger$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._IntegerImplementation.$7e$2f$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Mint.bitLength$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Mint.hashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Mint._identityHashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._Record.$3d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Record.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._Record.hashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._RegExpMatch.start$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._RegExpMatch.$5b$5d$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._RegExpMatch.end$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._RegExpMatch.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._RegExp.$3d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._RegExp.matchAsPrefix$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._RegExp.matchAsPrefix$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._RegExp.allMatches$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._RegExp.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._RegExp.allMatches$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._RegExp.hashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._RegExp._groupCount$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._AllMatchesIterable.iterator$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._AllMatchesIterator.moveNext$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._AllMatchesIterator.current$g(i64, ptr, ptr)
declare i64 @df.$stackTrace.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._OneByteString.$3d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._OneByteString.split$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase.matchAsPrefix$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._OneByteString.toUpperCase$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase.length$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._OneByteString._substringUncheckedNative$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase.matchAsPrefix$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._OneByteString.toLowerCase$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._OneByteString._isWhitespace$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._OneByteString.$2a$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase.$2b$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase.allMatches$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._OneByteString.split$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase.isEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._OneByteString.indexOf$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._OneByteString.padLeft$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase.allMatches$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._OneByteString.$2a$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase.$2b$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase.isNotEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase.$5b$5d$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._OneByteString._isWhitespace$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._OneByteString.hashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._OneByteString.contains$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase._identityHashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._OneByteString._substringUncheckedNative$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._OneByteString.contains$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._OneByteString.indexOf$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._OneByteString.padLeft$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._TwoByteString.$3d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase.split$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase.toUpperCase$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase._substringUncheckedNative$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase.toLowerCase$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._TwoByteString._isWhitespace$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._TwoByteString.$2a$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase.split$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase.indexOf$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase.padLeft$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._TwoByteString.$2a$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._TwoByteString._isWhitespace$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase.hashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase.contains$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase._substringUncheckedNative$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase.contains$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase.indexOf$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringBase.padLeft$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringMatch.start$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringMatch.$5b$5d$tc(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringMatch.end$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringMatch.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringAllMatchesIterable.iterator$g(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringAllMatchesIterator.moveNext$c(i64, ptr, ptr)
declare i64 @df.dart$3acore._StringAllMatchesIterator.current$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._OperatorEqualsAndHashCode._hashCode$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._HashVMBase._hashMask$s(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._HashVMBase._index$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._LinkedHashMapMixin.length$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._HashVMBase._data$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._HashVMBase._usedData$s(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._HashVMBase._index$3d$s(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._Map.containsKey$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection.MapBase.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._LinkedHashMapMixin.isEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._Map._init$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._LinkedHashMapMixin.remove$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._LinkedHashMapMixin.keys$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._HashVMBase._deletedKeys$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._Map._init$tc(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._HashVMBase._data$s(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._LinkedHashMapMixin.isNotEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._HashVMBase._hashMask$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._HashVMBase._deletedKeys$s(i64, ptr, ptr)
declare i64 @df.dart$3acollection.MapBase.map$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._LinkedHashMapMixin.forEach$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._LinkedHashMapMixin.values$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._LinkedHashMapMixin._regenerateIndex$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._HashVMBase._usedData$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._Map.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._OperatorEqualsAndHashCode._equals$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._Map.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._OperatorEqualsAndCanonicalHashCode._hashCode$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._HashVMImmutableBase._index$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._ImmutableLinkedHashMapMixin.containsKey$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._LinkedHashMapMixin._init$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._UnmodifiableMapMixin.remove$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._ImmutableLinkedHashMapMixin.keys$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._LinkedHashMapMixin._init$tc(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._ImmutableLinkedHashMapMixin.values$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._UnmodifiableMapMixin.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._OperatorEqualsAndCanonicalHashCode._equals$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._HashVMImmutableBase._indexNullable$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._ImmutableLinkedHashMapMixin.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._IdenticalAndIdentityHashCode._hashCode$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._HashFieldBase._hashMask$s(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._HashFieldBase._index$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._HashFieldBase._data$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._HashFieldBase._usedData$s(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._HashFieldBase._index$3d$s(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._LinkedHashMapMixin.containsKey$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._HashFieldBase._deletedKeys$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._HashFieldBase._data$s(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._HashFieldBase._hashMask$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._HashFieldBase._deletedKeys$s(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._HashFieldBase._usedData$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._LinkedHashMapMixin.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._IdenticalAndIdentityHashCode._equals$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._LinkedHashMapMixin.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._CustomEqualsAndHashCode._hashCode$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash.CompactLinkedCustomHashMap._equality$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash.CompactLinkedCustomHashMap.containsKey$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash.CompactLinkedCustomHashMap.remove$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash.CompactLinkedCustomHashMap._hasher$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._CustomEqualsAndHashCode._equals$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash.CompactLinkedCustomHashMap.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._CompactIterable.length$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._CompactIterable.iterator$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._CompactIterable.isEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._CompactIterable.isNotEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._CompactIterator.moveNext$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._CompactIterator._data$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._CompactIterator.current$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._CompactIterableImmutable.length$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._CompactIterableImmutable.iterator$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._CompactIterableImmutable._data$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._CompactIterableImmutable.isEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._CompactIterableImmutable.isNotEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._CompactIteratorImmutable.moveNext$c(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._CompactIteratorImmutable._data$g(i64, ptr, ptr)
declare i64 @df.dart$3a_compact_hash._CompactIteratorImmutable.current$g(i64, ptr, ptr)
declare i64 @df.dart$3acollection.MapView.length$g(i64, ptr, ptr)
declare i64 @df.dart$3acollection.MapView.containsKey$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection.MapView.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection.MapView.isEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3acollection._UnmodifiableMapMixin.remove$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection.MapView.keys$g(i64, ptr, ptr)
declare i64 @df.dart$3acollection.MapView.isNotEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3acollection.MapView.map$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection.MapView.forEach$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection.MapView.values$g(i64, ptr, ptr)
declare i64 @df.dart$3acollection._UnmodifiableMapMixin.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection.MapView.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection._HashMap.length$g(i64, ptr, ptr)
declare i64 @df.dart$3acollection._HashMap.containsKey$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection._HashMap.isEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3acollection._HashMap.remove$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection._HashMap.keys$g(i64, ptr, ptr)
declare i64 @df.dart$3acollection._HashMap.isNotEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3acollection._HashMap.forEach$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection._HashMap.values$g(i64, ptr, ptr)
declare i64 @df.dart$3acollection._HashMap.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection._HashMap.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection._CustomHashMap.containsKey$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection._CustomHashMap.remove$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection._CustomHashMap.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection._CustomHashMap.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection._IdentityHashMap.containsKey$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection._IdentityHashMap.remove$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection._IdentityHashMap.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection._IdentityHashMap.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection._HashMapEntry.hashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3acollection._HashMapIterable.length$g(i64, ptr, ptr)
declare i64 @df.dart$3acollection._HashMapKeyIterable.iterator$g(i64, ptr, ptr)
declare i64 @df.dart$3acollection._HashMapIterable.isEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3acollection._HashMapIterable.isNotEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3acollection._HashMapKeyIterable.forEach$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection._HashMapKeyIterable.contains$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection._HashMapValueIterable.iterator$g(i64, ptr, ptr)
declare i64 @df.dart$3acollection._HashMapValueIterable.forEach$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection._HashMapValueIterable.contains$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection._HashMapIterator.moveNext$c(i64, ptr, ptr)
declare i64 @df.dart$3acollection._HashMapKeyIterator.current$g(i64, ptr, ptr)
declare i64 @df.dart$3acollection._HashMapValueIterator.current$g(i64, ptr, ptr)
declare i64 @df.dart$3aconvert.AsciiCodec.encoder$g(i64, ptr, ptr)
declare i64 @df.dart$3aconvert.AsciiCodec.encode$c(i64, ptr, ptr)
declare i64 @df.dart$3aconvert._UnicodeSubsetEncoder.convert$c(i64, ptr, ptr)
declare i64 @df.dart$3aconvert._UnicodeSubsetEncoder.convert$tc(i64, ptr, ptr)
declare i64 @df.dart$3aconvert.Base64Codec.encoder$g(i64, ptr, ptr)
declare i64 @df.dart$3aconvert.Codec.encode$c(i64, ptr, ptr)
declare i64 @df.dart$3aconvert.Base64Encoder.convert$c(i64, ptr, ptr)
declare i64 @df.dart$3aconvert._Base64Encoder.encode$c(i64, ptr, ptr)
declare i64 @df.dart$3aconvert._Base64Encoder.createBuffer$tc(i64, ptr, ptr)
declare i64 @df.dart$3aconvert._Base64Encoder.createBuffer$c(i64, ptr, ptr)
declare i64 @df.dart$3aconvert._Base64Encoder.encode$tc(i64, ptr, ptr)
declare i64 @df.dart$3aconvert.JsonUnsupportedObjectError.unsupportedObject$g(i64, ptr, ptr)
declare i64 @df.dart$3aconvert.JsonUnsupportedObjectError.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3aconvert.JsonUnsupportedObjectError.cause$g(i64, ptr, ptr)
declare i64 @df.dart$3aconvert.JsonCyclicError.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3aconvert.JsonCodec.encoder$g(i64, ptr, ptr)
declare i64 @df.dart$3aconvert.JsonCodec.encode$c(i64, ptr, ptr)
declare i64 @df.dart$3aconvert.JsonEncoder.convert$c(i64, ptr, ptr)
declare i64 @df.dart$3aconvert._JsonStringStringifier.writeStringSlice$tc(i64, ptr, ptr)
declare i64 @df.dart$3aconvert._JsonStringStringifier.writeCharCode$c(i64, ptr, ptr)
declare i64 @df.dart$3aconvert._JsonStringStringifier.writeCharCode$tc(i64, ptr, ptr)
declare i64 @df.dart$3aconvert._JsonStringifier.writeList$c(i64, ptr, ptr)
declare i64 @df.dart$3aconvert._JsonStringifier.writeList$tc(i64, ptr, ptr)
declare i64 @df.dart$3aconvert._JsonStringStringifier.writeString$c(i64, ptr, ptr)
declare i64 @df.dart$3aconvert._JsonStringStringifier._partialResult$g(i64, ptr, ptr)
declare i64 @df.dart$3aconvert._JsonStringifier.writeMap$c(i64, ptr, ptr)
declare i64 @df.dart$3aconvert._JsonStringStringifier.writeNumber$tc(i64, ptr, ptr)
declare i64 @df.dart$3aconvert._JsonStringStringifier.writeStringSlice$c(i64, ptr, ptr)
declare i64 @df.dart$3aconvert._JsonStringifier.writeMap$tc(i64, ptr, ptr)
declare i64 @df.dart$3aconvert._JsonStringStringifier.writeString$tc(i64, ptr, ptr)
declare i64 @df.dart$3aconvert._JsonStringStringifier.writeNumber$c(i64, ptr, ptr)
declare i64 @df.dart$3aconvert._JsonPrettyPrintMixin.writeList$c(i64, ptr, ptr)
declare i64 @df.dart$3aconvert._JsonPrettyPrintMixin.writeList$tc(i64, ptr, ptr)
declare i64 @df.dart$3aconvert._JsonStringStringifierPretty.writeIndentation$c(i64, ptr, ptr)
declare i64 @df.dart$3aconvert._JsonPrettyPrintMixin.writeMap$c(i64, ptr, ptr)
declare i64 @df.dart$3aconvert._JsonStringStringifierPretty.writeIndentation$tc(i64, ptr, ptr)
declare i64 @df.dart$3aconvert._JsonPrettyPrintMixin.writeMap$tc(i64, ptr, ptr)
declare i64 @df.dart$3aconvert.Latin1Codec.encoder$g(i64, ptr, ptr)
declare i64 @df.dart$3aconvert.Latin1Codec.encode$c(i64, ptr, ptr)
declare i64 @df.dart$3aconvert.Utf8Codec.encoder$g(i64, ptr, ptr)
declare i64 @df.dart$3aconvert.Utf8Codec.encode$c(i64, ptr, ptr)
declare i64 @df.dart$3aconvert.Utf8Encoder.convert$c(i64, ptr, ptr)
declare i64 @df.dart$3aconvert.Utf8Encoder.convert$tc(i64, ptr, ptr)
declare i64 @df.dart$3aconvert.Utf8Decoder.convert$c(i64, ptr, ptr)
declare i64 @df.dart$3aconvert.Utf8Decoder.convert$tc(i64, ptr, ptr)
declare i64 @df.dart$3aasync.AsyncError.stackTrace$g(i64, ptr, ptr)
declare i64 @df.dart$3aasync.AsyncError.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._Completer.future$g(i64, ptr, ptr)
declare i64 @df.dart$3aasync._AsyncCompleter.complete$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._FutureListener.errorCallback$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._Future.then$tc(i64, ptr, ptr)
declare i64 @df.dart$3aasync._Future.then$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._Future.whenComplete$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._ZoneDelegate.scheduleMicrotask$tc(i64, ptr, ptr)
declare i64 @df.dart$3aasync._ZoneDelegate.registerBinaryCallback$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._ZoneDelegate.runBinary$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._ZoneDelegate.runBinary$tc(i64, ptr, ptr)
declare i64 @df.dart$3aasync._ZoneDelegate.registerBinaryCallback$tc(i64, ptr, ptr)
declare i64 @df.dart$3aasync._ZoneDelegate.errorCallback$tc(i64, ptr, ptr)
declare i64 @df.dart$3aasync._ZoneDelegate.runUnary$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._ZoneDelegate.run$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._ZoneDelegate.createTimer$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._ZoneDelegate.registerCallback$tc(i64, ptr, ptr)
declare i64 @df.dart$3aasync._ZoneDelegate.runUnary$tc(i64, ptr, ptr)
declare i64 @df.dart$3aasync._ZoneDelegate.handleUncaughtError$tc(i64, ptr, ptr)
declare i64 @df.dart$3aasync._ZoneDelegate.run$tc(i64, ptr, ptr)
declare i64 @df.dart$3aasync._ZoneDelegate.handleUncaughtError$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._ZoneDelegate.errorCallback$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._ZoneDelegate.registerUnaryCallback$tc(i64, ptr, ptr)
declare i64 @df.dart$3aasync._ZoneDelegate.createTimer$tc(i64, ptr, ptr)
declare i64 @df.dart$3aasync._ZoneDelegate.registerCallback$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._ZoneDelegate.scheduleMicrotask$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._ZoneDelegate.registerUnaryCallback$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone.parent$g(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone.registerBinaryCallback$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone.runBinary$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone.bindUnaryCallbackGuarded$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone._createTimer$g(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone._registerBinaryCallback$g(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone.bindCallbackGuarded$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone.errorCallback$tc(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone.runUnary$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone.run$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone._run$g(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone._runBinary$g(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone.createTimer$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone.handleUncaughtError$tc(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone.handleUncaughtError$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone._runUnary$g(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone.errorCallback$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone._handleUncaughtError$g(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone._delegate$g(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone._errorCallback$g(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone.errorZone$g(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone._scheduleMicrotask$g(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone.bindCallback$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone.createTimer$tc(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone._registerCallback$g(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone.bindBinaryCallback$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone._parentDelegate$g(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone._registerUnaryCallback$g(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone.registerCallback$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone.scheduleMicrotask$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone.registerUnaryCallback$c(i64, ptr, ptr)
declare i64 @df.dart$3aasync._RootZone.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._ByteBuffer.$3d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._ByteBuffer.asByteData$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._ByteBuffer.asUint8List$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._ByteBuffer.asByteData$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._ByteBuffer.hashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._ByteBuffer.lengthInBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._ByteBuffer.asUint8List$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int8List.$5b$5d$3d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int8List._createList$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int8List.elementSizeInBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._IntListMixin.last$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._IntListMixin.toList$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._IntListMixin.skip$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._TypedListBase.length$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._IntListMixin.take$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._IntListMixin.iterator$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._TypedListBase.join$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int8List._fastSetRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._TypedListBase.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._TypedListBase.isEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._IntListMixin.elementAt$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._IntListMixin.indexOf$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._IntListMixin.skip$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._TypedIntListMixin._slowSetRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._TypedList.buffer$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._TypedListBase.remove$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._IntListMixin.removeLast$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._IntListMixin.elementAt$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._IntListMixin.$2b$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._IntListMixin.fillRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._TypedList.offsetInBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._IntListMixin.take$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._TypedListBase.isNotEmpty$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._IntListMixin.toList$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._IntListMixin.map$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int8List.$5b$5d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._IntListMixin.forEach$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._TypedListBase._containsUnsignedBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int8List._createList$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._IntListMixin.add$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._IntListMixin.contains$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._TypedList._typedData$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._TypedListBase.join$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._IntListMixin.fillRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._TypedList.lengthInBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int8List._fastSetRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._IntListMixin.setRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int8List.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._IntListMixin.setRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._IntListMixin.indexOf$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._TypedIntListMixin._slowSetRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int8List.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8List.$5b$5d$3d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8List._createList$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8List.elementSizeInBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8List._fastSetRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8List.$5b$5d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8List._containsUnsignedBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8List._createList$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8List._fastSetRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8List.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8List.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8ClampedList.$5b$5d$3d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8ClampedList._createList$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8ClampedList.elementSizeInBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8ClampedList._fastSetRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8ClampedList.$5b$5d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8ClampedList._containsUnsignedBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8ClampedList._createList$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8ClampedList._fastSetRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8ClampedList.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8ClampedList.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int16List.$5b$5d$3d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int16List._createList$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int16List.elementSizeInBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int16List._fastSetRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int16List.$5b$5d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int16List._createList$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int16List._fastSetRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int16List.setRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int16List.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int16List.setRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int16List.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint16List.$5b$5d$3d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint16List._createList$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint16List.elementSizeInBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint16List._fastSetRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint16List.$5b$5d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint16List._createList$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint16List._fastSetRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint16List.setRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint16List.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint16List.setRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint16List.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32List.$5b$5d$3d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32List._createList$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32List.elementSizeInBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32List._fastSetRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32List.$5b$5d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32List._createList$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32List._fastSetRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32List.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32List.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint32List.$5b$5d$3d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint32List._createList$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint32List.elementSizeInBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint32List._fastSetRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint32List.$5b$5d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint32List._createList$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint32List._fastSetRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint32List.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint32List.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int64List.$5b$5d$3d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int64List._createList$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int64List.elementSizeInBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int64List._fastSetRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int64List.$5b$5d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int64List._createList$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int64List._fastSetRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int64List.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int64List.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint64List.$5b$5d$3d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint64List._createList$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint64List.elementSizeInBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint64List._fastSetRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint64List.$5b$5d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint64List._createList$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint64List._fastSetRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint64List.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint64List.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32List.$5b$5d$3d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32List._createList$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32List.elementSizeInBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._DoubleListMixin.last$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._DoubleListMixin.toList$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._DoubleListMixin.skip$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._DoubleListMixin.take$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._DoubleListMixin.iterator$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32List._fastSetRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._DoubleListMixin.elementAt$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._DoubleListMixin.indexOf$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._DoubleListMixin.skip$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._TypedDoubleListMixin._slowSetRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._DoubleListMixin.removeLast$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._DoubleListMixin.elementAt$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._DoubleListMixin.$2b$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._DoubleListMixin.fillRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._DoubleListMixin.take$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._DoubleListMixin.toList$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._DoubleListMixin.map$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32List.$5b$5d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._DoubleListMixin.forEach$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32List._createList$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._DoubleListMixin.add$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._DoubleListMixin.contains$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._DoubleListMixin.fillRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32List._fastSetRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._DoubleListMixin.setRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32List.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._DoubleListMixin.setRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._DoubleListMixin.indexOf$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._TypedDoubleListMixin._slowSetRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32List.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64List.$5b$5d$3d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64List._createList$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64List.elementSizeInBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64List._fastSetRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64List.$5b$5d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64List._createList$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64List._fastSetRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64List.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64List.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4List.$5b$5d$3d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4List._createList$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4List.elementSizeInBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4ListMixin.last$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4ListMixin.toList$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4ListMixin.skip$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4ListMixin.take$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4ListMixin.iterator$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4List._fastSetRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4ListMixin.elementAt$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4ListMixin.indexOf$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4ListMixin.skip$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4ListMixin._slowSetRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4ListMixin.removeLast$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4ListMixin.elementAt$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4ListMixin.$2b$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4ListMixin.fillRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4ListMixin.take$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4ListMixin.toList$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4ListMixin.map$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4List.$5b$5d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4ListMixin.forEach$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4List._createList$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4ListMixin.add$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4ListMixin.contains$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4ListMixin.fillRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4List._fastSetRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4ListMixin.setRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4List.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4ListMixin.setRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4ListMixin.indexOf$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4ListMixin._slowSetRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4List.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4List.$5b$5d$3d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4List._createList$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4List.elementSizeInBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4ListMixin.last$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4ListMixin.toList$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4ListMixin.skip$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4ListMixin.take$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4ListMixin.iterator$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4List._fastSetRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4ListMixin.elementAt$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4ListMixin.indexOf$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4ListMixin.skip$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4ListMixin._slowSetRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4ListMixin.removeLast$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4ListMixin.elementAt$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4ListMixin.$2b$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4ListMixin.fillRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4ListMixin.take$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4ListMixin.toList$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4ListMixin.map$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4List.$5b$5d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4ListMixin.forEach$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4List._createList$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4ListMixin.add$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4ListMixin.contains$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4ListMixin.fillRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4List._fastSetRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4ListMixin.setRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4List.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4ListMixin.setRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4ListMixin.indexOf$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4ListMixin._slowSetRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4List.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2List.$5b$5d$3d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2List._createList$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2List.elementSizeInBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2ListMixin.last$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2ListMixin.toList$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2ListMixin.skip$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2ListMixin.take$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2ListMixin.iterator$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2List._fastSetRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2ListMixin.elementAt$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2ListMixin.indexOf$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2ListMixin.skip$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2ListMixin._slowSetRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2ListMixin.removeLast$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2ListMixin.elementAt$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2ListMixin.$2b$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2ListMixin.fillRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2ListMixin.take$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2ListMixin.toList$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2ListMixin.map$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2List.$5b$5d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2ListMixin.forEach$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2List._createList$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2ListMixin.add$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2ListMixin.contains$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2ListMixin.fillRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2List._fastSetRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2ListMixin.setRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2List.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2ListMixin.setRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2ListMixin.indexOf$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2ListMixin._slowSetRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2List.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4.$2f$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4.$2d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4.$2a$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4.$2b$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4.$2a$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4.$2b$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4.$2d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float32x4.$2f$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4.$2d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4.$2b$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4.$2b$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Int32x4.$2d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2.$2f$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2.$2d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2.$2a$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2.$2b$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2.$2a$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2.$2b$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2.$2d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Float64x2.$2f$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._TypedListIterator.moveNext$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._TypedListIterator.current$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8ArrayView.$5b$5d$3d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8ArrayView._createList$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8ArrayView.elementSizeInBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8ArrayView._fastSetRange$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._TypedListView.buffer$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._TypedListView.offsetInBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8ArrayView.$5b$5d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8ArrayView._containsUnsignedBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8ArrayView._createList$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._TypedListView._typedData$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._TypedListView.lengthInBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8ArrayView._fastSetRange$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8ArrayView.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._Uint8ArrayView.$5b$5d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._ByteDataView.setInt32$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._ByteDataView.elementSizeInBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._ByteDataView.length$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._ByteDataView.buffer$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._ByteDataView.offsetInBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._ByteDataView.setInt32$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._ByteDataView._typedData$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._ByteDataView.lengthInBytes$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._UnmodifiableUint8ArrayView.$5b$5d$3d$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._UnmodifiableUint8ArrayView.buffer$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._UnmodifiableUint8ArrayView.$5b$5d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._UnmodifiableByteDataView.setInt32$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._UnmodifiableByteDataView.buffer$g(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._UnmodifiableByteDataView.setInt32$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._UnmodifiableByteBufferView.asByteData$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._UnmodifiableByteBufferView.asUint8List$c(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._UnmodifiableByteBufferView.asByteData$tc(i64, ptr, ptr)
declare i64 @df.dart$3atyped_data._UnmodifiableByteBufferView.asUint8List$tc(i64, ptr, ptr)
declare i64 @df.dart$3aisolate._Capability.$3d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3aisolate._Capability.hashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3aisolate._RawReceivePort.$3d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3aisolate._RawReceivePort.close$c(i64, ptr, ptr)
declare i64 @df.dart$3aisolate._RawReceivePort.handler$3d$s(i64, ptr, ptr)
declare i64 @df.dart$3aisolate._RawReceivePort.sendPort$g(i64, ptr, ptr)
declare i64 @df.dart$3aisolate._RawReceivePort.hashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3aisolate._SendPort.$3d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3aisolate._SendPort.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3aisolate._SendPort.hashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3aisolate._SendPort.send$c(i64, ptr, ptr)
declare i64 @df.dart$3adeveloper.ServiceExtensionResponse.errorCode$g(i64, ptr, ptr)
declare i64 @df.dart$3affi.Pointer.$3d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3affi.Pointer.hashCode$g(i64, ptr, ptr)
declare i64 @df.dart$3affi._NativeCallableBase.close$c(i64, ptr, ptr)
declare i64 @df.dart$3affi._NativeCallableIsolateLocal._close$c(i64, ptr, ptr)
declare i64 @df.dart$3affi._NativeCallableListener._close$c(i64, ptr, ptr)
declare i64 @df.dart$3affi._NativeCallableSync._close$c(i64, ptr, ptr)
declare i64 @df.dart$3aio.OSError.message$g(i64, ptr, ptr)
declare i64 @df.dart$3aio.OSError.errorCode$g(i64, ptr, ptr)
declare i64 @df.dart$3aio.OSError.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3aio.FileSystemEntity.parent$g(i64, ptr, ptr)
declare i64 @df.dart$3aio._Directory.uri$g(i64, ptr, ptr)
declare i64 @df.dart$3aio._Directory.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3aio._Directory._path$g(i64, ptr, ptr)
declare i64 @df.dart$3aio._Directory.path$g(i64, ptr, ptr)
declare i64 @df.dart$3aio.FileSystemException.message$g(i64, ptr, ptr)
declare i64 @df.dart$3aio.FileSystemException.osError$g(i64, ptr, ptr)
declare i64 @df.dart$3aio.FileSystemException.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3aio.FileSystemException.path$g(i64, ptr, ptr)
declare i64 @df.dart$3aio.PathAccessException.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3aio.PathExistsException.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3aio.PathNotFoundException.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3aio._File.length$g(i64, ptr, ptr)
declare i64 @df.dart$3aio.FileSystemEntity.uri$g(i64, ptr, ptr)
declare i64 @df.dart$3aio._File.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3aio._File._path$g(i64, ptr, ptr)
declare i64 @df.dart$3aio._File.path$g(i64, ptr, ptr)
declare i64 @df.dart$3aio._RandomAccessFile.close$c(i64, ptr, ptr)
declare i64 @df.dart$3aio._RandomAccessFile.length$g(i64, ptr, ptr)
declare i64 @df.dart$3aio._RandomAccessFile.truncate$c(i64, ptr, ptr)
declare i64 @df.dart$3aio._RandomAccessFile.path$g(i64, ptr, ptr)
declare i64 @df.dart$3aio._FileResourceInfo.name$g(i64, ptr, ptr)
declare i64 @df.dart$3aio._Link.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3aio._Link._path$g(i64, ptr, ptr)
declare i64 @df.dart$3aio._Link.path$g(i64, ptr, ptr)
declare i64 @df.dart$3aio.InternetAddressType.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3aio.Datagram.port$g(i64, ptr, ptr)
declare i64 @df.dart$3aio._RandomAccessFileOpsImpl.close$c(i64, ptr, ptr)
declare i64 @df.dart$3aio._RandomAccessFileOpsImpl.length$g(i64, ptr, ptr)
declare i64 @df.dart$3aio._RandomAccessFileOpsImpl.truncate$c(i64, ptr, ptr)
declare i64 @df.dart$3aio._InternetAddress.$3d$3d$c(i64, ptr, ptr)
declare i64 @df.dart$3aio._InternetAddress.host$g(i64, ptr, ptr)
declare i64 @df.dart$3aio._InternetAddress.toString$c(i64, ptr, ptr)
declare i64 @df.dart$3aio._InternetAddress.hashCode$g(i64, ptr, ptr)
